# Verification record

Target: Paper **1.21.11**, Java **25**, resource pack **75.0**. These results distinguish compiler/asset checks from live Minecraft acceptance.

## Completed checks

- Real Gradle 9.2.1 build using a verified Java 25 JDK and the project's Java 25 toolchain/release target.
- Actual plugin Java compilation against the official Paper `ver/1.21.11` API source at commit `c5eb0790f199da6c38d0a650e1e5cd5415b28185`, substituted through an isolated Gradle composite build. The project still declares the requested `1.21.11-R0.1-SNAPSHOT` Maven dependency.
- The verification composite compiles official Mojang Brigadier sources and uses official Central BungeeCord chat 1.21-R0.2 in place of Paper's deprecated fork. It does not use fabricated API stubs. See [build provenance](../tools/BUILD-VERIFICATION.md) and `tools/verify-official-api.sh` for exact versions and commands.
- Final JAR: **62 Java 25 class files** (class version 69), plugin descriptor and all **8 YAML resources**. No Bukkit/Paper API classes are bundled. All YAML resources parsed successfully.
- Final full Gradle build and a subsequent incremental verification completed after the last code changes; no compiler errors remain.
- Real JUnit tests for crater/trajectory math, shared easing/force falloff, storm/fault/flood geometry, and durable journal encoding/order/interrupted-write recovery. Final build: **19 distinct tests passed, 0 failed, 0 errors, 0 skipped**. Both `test` and `coreTest` executed those same 19 cases (not 38 unique tests). Four cover the integrated animation timeline, including all-channel interpolation, easing, skipped-tick sound cues and validation.
- Resource pack validator: **51 JSON/metadata files**, **23 models**, **431 cuboid elements**, **23 modern item definitions**, **21 decoded Vorbis sound assets**, PNG validity, texture/model/sound references, animation metadata, item atlas, ZIP root layout and SHA-1.
- Asset generation repeated with identical resource-pack ZIP hash: `19363314dbb1aa8b619ccd74f439fefc80dba3e6`.

## Blocked or unrun checks

The ordinary published-API Maven build was attempted. The environment's proxy returned HTTP 403 for Paper's Maven and server-download hosts before dependency resolution. Network domain additions were saved in the cloud configuration draft; saving that draft does not prove the running policy changed or that publication occurred. The source-API composite provides genuine compiler evidence but does not establish the official Maven binary resolved.

No Paper server binary could be obtained from the official download service under the current policy. **Actual Paper 1.21.11 server startup and plugin loading were not run.** No Minecraft client was attached, so **appearance, animation smoothness, audio quality, pack acceptance/retry and GUI behavior have not been client-tested**.

The requested per-disaster end-to-end, WorldGuard interoperability, multiplayer join/leave/multiple-world behavior, abrupt server crash/restore, low-TPS degradation and 10–100 player capacity tests are **unrun**, not passing tests. The journal unit tests exercise storage behavior rather than a crashed Minecraft world's complete durability semantics.

## Reproduction

With Java 25 and network access to the ordinary repositories:

```bash
./gradlew --no-daemon clean build coreTest
python3 tools/generate_assets.py
python3 tools/validate_assets.py
```

When only Paper's official GitHub source and Maven Central are reachable:

```bash
export JAVA_HOME=/path/to/jdk-25
export PATH="$JAVA_HOME/bin:$PATH"
./tools/verify-official-api.sh
python3 tools/validate_assets.py
```

The latter is a source-backed compile, not a server emulator. `build/test-results/test` and `build/test-results/coreTest` are the actual JUnit XML outputs. The two tasks run the same core cases; do not add their counts together as unique coverage.

Before production, perform the acceptance checklist in [REQUIREMENTS.md](REQUIREMENTS.md). Structural asset validation cannot establish premium visual quality. Known implementation limits are documented there, including block-entity exclusion and conservative claim-plugin handling.
