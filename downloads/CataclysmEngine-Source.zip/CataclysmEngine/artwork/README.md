# Editable Cataclysm artwork

The `.bbmodel` files are editable Blockbench Java block/item models with embedded
textures. They accompany the generated Minecraft model JSON. A model is built from
several rotated cuboids, never a billboard masquerading as the meteor. The four
meteor variants use different geometry, distributions, random seeds and detail
counts: 16, 30, 47 and 69 cuboids. Shapes are centered on `(8, 8, 8)` in Minecraft's
16 model-units-per-block coordinate system. The plugin assembles, scales and
animates these models with `ItemDisplay` entities.

Run `python3 tools/generate_assets.py` from any directory to regenerate artwork,
the complete resource pack and its ZIP. This overwrites generated files, including
these editable projects: save manual edits separately or update the generator.
Python 3.10+, Pillow and `ffmpeg` with `libvorbis` are required. Run
`python3 tools/validate_assets.py` afterwards to validate JSON, geometry, every
texture/model reference, animation frame ranges, fully decode every OGG, inspect
the ZIP's root and check its SHA-1. Texture generation, geometry, sound synthesis
and ZIP timestamps are deterministic.

All artwork and sound samples were generated originally for this project. No
external textures, recorded samples, fonts or audio libraries are embedded.
The generated assets can be used, edited and redistributed with this project.

## Technical choices

- All geometry references `cataclysm:item/...` textures. The pack contributes the
  `item` directory to the separate 1.21.11 item atlas. The baked model is selected
  through the `cataclysm:...` item model component and modern `items/*.json` files.
- The 128×128 rock surfaces combine layered random fields, sharp grain, edge
  shading, branching fissures and orange/yellow crack highlights. Three rock
  variations prevent uniform repeated surfaces. Molten and water textures have
  eight animation frames and valid `.png.mcmeta` metadata.
- Brightness is controlled by display entities. Textures alone do not light the
  world. A standard resource pack cannot introduce real dynamic lighting,
  volumetric smoke, shader refraction or camera control.
- `heat_haze` is a deliberately sparse cutout veil. It suggests moving heated air;
  it does not refract the scene. Wave and cloud models are stylized layered
  geometry with native particles supplying foam, mist and softer edges.
- Twenty-one distinct mono Vorbis sound assets use filtered broadband noise,
  subharmonics, periodic modulation, impulses and envelope fades. They are original
  synthesized sound design, not recordings. All use the `cataclysm` namespace;
  see `resource-pack/assets/cataclysm/sounds.json` for exact keys.

The asset validator confirms file integrity and references. Appearance, resource
reload warnings, perceived audio quality and client frame rate still need a real
Minecraft 1.21.11 client review; a server build cannot verify those properties.
