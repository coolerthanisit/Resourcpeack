plugins { java }

group = "com.cataclysmengine"
version = "1.0.0"

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    compileOnly("io.papermc.paper:paper-api:1.21.11-R0.1-SNAPSHOT")
    testImplementation("io.papermc.paper:paper-api:1.21.11-R0.1-SNAPSHOT")
    testImplementation(platform("org.junit:junit-bom:5.12.2"))
    testImplementation("org.junit.jupiter:junit-jupiter")
    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
}

java { toolchain.languageVersion.set(JavaLanguageVersion.of(25)) }
tasks.withType<JavaCompile>().configureEach {
    options.encoding = "UTF-8"
    options.release.set(25)
}
tasks.test { useJUnitPlatform() }
tasks.jar {
    archiveFileName.set("CataclysmEngine.jar")
    manifest { attributes("Implementation-Version" to project.version) }
}
tasks.wrapper {
    gradleVersion = "9.2.1"
    distributionType = Wrapper.DistributionType.BIN
    distributionSha256Sum = "72f44c9f8ebcb1af43838f45ee5c4aa9c5444898b3468ab3f4af7b6076c5bc3f"
}

// Pure deterministic simulation/persistence tests remain runnable without a live server.
val core by sourceSets.creating {
    java.setSrcDirs(listOf("src/main/java"))
    java.include("com/cataclysmengine/rollback/TerrainJournal.java")
    java.include("com/cataclysmengine/disaster/meteor/MeteorMath.java")
    java.include("com/cataclysmengine/physics/SimulationMath.java")
    java.include("com/cataclysmengine/disaster/environment/StormMath.java")
    java.include("com/cataclysmengine/vfx/animation/*.java")
}
val coreTest by sourceSets.creating {
    java.setSrcDirs(listOf("src/test/java"))
    java.include("com/cataclysmengine/rollback/TerrainJournalTest.java")
    java.include("com/cataclysmengine/disaster/meteor/MeteorMathTest.java")
    java.include("com/cataclysmengine/physics/SimulationMathTest.java")
    java.include("com/cataclysmengine/disaster/environment/StormMathTest.java")
    java.include("com/cataclysmengine/vfx/animation/*.java")
    compileClasspath += core.output
    runtimeClasspath += core.output
}
dependencies {
    add(coreTest.implementationConfigurationName, platform("org.junit:junit-bom:5.12.2"))
    add(coreTest.implementationConfigurationName, "org.junit.jupiter:junit-jupiter")
    add(coreTest.runtimeOnlyConfigurationName, "org.junit.platform:junit-platform-launcher")
}
tasks.register<Test>("coreTest") {
    description = "Runs actual Java 25 geometry and write-ahead persistence tests without Paper."
    group = "verification"
    testClassesDirs = coreTest.output.classesDirs
    classpath = coreTest.runtimeClasspath
    useJUnitPlatform()
}
