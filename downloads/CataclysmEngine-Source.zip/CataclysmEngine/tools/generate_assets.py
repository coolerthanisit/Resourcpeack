#!/usr/bin/env python3
"""Reproducibly generate original Cataclysm artwork, model geometry and audio.

Requires Python 3.10+, Pillow and ffmpeg (Vorbis encoder). No downloaded assets.
Run from any directory. Generated PNGs and sounds are redistributable with this project.
"""
from __future__ import annotations
import base64
import hashlib
import io
import json
import math
from pathlib import Path
import random
import shutil
import struct
import subprocess
import tempfile
import uuid
import wave
import zipfile

from PIL import Image, ImageDraw, ImageFilter

ROOT = Path(__file__).resolve().parents[1]
PACK = ROOT / "resource-pack"
NS = PACK / "assets/cataclysm"
SEED = 8211125


def write_json(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def clamp(n, a=0, b=255):
    return max(a, min(b, n))


def texture(name: str, seed: int, molten=False, frames=1, material="rock"):
    rng = random.Random(seed)
    size = 128
    crack = Image.new("L", (size, size))
    pen = ImageDraw.Draw(crack)
    for _ in range(13):
        x, y = rng.randrange(size), rng.randrange(size)
        for _ in range(rng.randrange(5, 15)):
            nx, ny = x+rng.randrange(-17, 18), y+rng.randrange(-14, 15)
            pen.line((x, y, nx, ny), fill=rng.randrange(140, 256), width=rng.choice((1, 1, 2)))
            if rng.random() < .2:
                pen.line((x, y, x+rng.randrange(-12, 13), y+rng.randrange(-12, 13)), fill=180)
            x, y = nx, ny
    glow = crack.filter(ImageFilter.GaussianBlur(3))
    coarse = Image.new("L", (16, 16))
    coarse.putdata([rng.randrange(256) for _ in range(256)])
    coarse = coarse.resize((size, size), Image.Resampling.BICUBIC)
    medium = Image.new("L", (32, 32))
    medium.putdata([rng.randrange(256) for _ in range(1024)])
    medium = medium.resize((size, size), Image.Resampling.BILINEAR)
    atlas = Image.new("RGBA", (size, size*frames))
    palettes = {"rock": (39, 38, 42), "ice": (112, 184, 216),
                "wood": (96, 61, 34), "water": (22, 95, 153),
                "cloud": (53, 60, 71), "haze": (140, 119, 104)}
    base = palettes[material]
    for frame in range(frames):
        image = Image.new("RGBA", (size, size))
        pix = image.load()
        pulse = .65 + .35*math.sin(frame/max(frames, 1)*math.tau)
        for y in range(size):
            for x in range(size):
                grain = rng.randrange(-9, 10)
                shade = (coarse.getpixel((x, y))-128)*.2 + (medium.getpixel((x, y))-128)*.12 + grain
                # directional edge lighting and grain stay recognizable at distance
                shade += 9*math.sin(x*.21 + y*.06)
                c = crack.getpixel((x, y))/255
                g = glow.getpixel((x, y))/255
                if material == "rock":
                    if molten:
                        heat = max(c, .38 + .3*math.sin(x*.1+y*.07+frame*.5))
                        rgb = (130+125*heat, 20+190*heat*pulse, 3+64*heat*heat)
                    else:
                        rgb = (base[0]+shade+g*120+c*174, base[1]+shade+g*27+c*74, base[2]+shade-g*8+c*6)
                elif material == "wood":
                    streak = math.sin(x*.52 + math.sin(y*.06)*2)*12
                    rgb = tuple(b+shade+streak-c*18 for b in base)
                elif material == "ice":
                    rgb = tuple(b+shade+c*70 for b in base)
                elif material == "water":
                    ripple = math.sin(x*.15+y*.07+frame*math.tau/max(frames, 1))*17
                    rgb = tuple(b+shade*.3+ripple for b in base)
                else:
                    rgb = tuple(b+shade*.4 for b in base)
                alpha = 255
                if material == "haze":
                    # Cutout veil: no unsupported shader distortion or translucent render type.
                    alpha = 255 if (x//4+y//4)%5 == 0 else 0
                pix[x, y] = (*[int(clamp(v)) for v in rgb], alpha)
        atlas.paste(image, (0, frame*size))
    out = NS / f"textures/item/{name}.png"
    out.parent.mkdir(parents=True, exist_ok=True)
    atlas.save(out)
    if frames > 1:
        write_json(Path(str(out)+".mcmeta"), {"animation": {"frametime": 3, "interpolate": True, "width": size, "height": size, "frames": list(range(frames))}})


def cuboid(cx, cy, cz, sx, sy, sz, tex, rng, rotation=True):
    uvx, uvy = rng.randrange(0, 8), rng.randrange(0, 8)
    e = {"from": [round(cx-sx/2, 3), round(cy-sy/2, 3), round(cz-sz/2, 3)],
         "to": [round(cx+sx/2, 3), round(cy+sy/2, 3), round(cz+sz/2, 3)],
         "shade": True,
         "faces": {face: {"uv": [uvx, uvy, uvx+8, uvy+8], "texture": "#"+tex}
                   for face in ("north", "east", "south", "west", "up", "down")}}
    if rotation:
        e["rotation"] = {"origin": [cx, cy, cz], "axis": rng.choice(("x", "y", "z")),
                         "angle": rng.choice((-22.5, 0, 22.5, 45)), "rescale": False}
    return e


def rock_geometry(name, count, seed, kind="rock"):
    rng = random.Random(seed)
    parts = []
    if name == "shockwave":
        for i in range(24):
            a = i*math.tau/24
            parts.append(cuboid(8+6*math.cos(a), 8+math.sin(a*3)*.25, 8+6*math.sin(a),
                                 2.1, .45, 1.8, "hot", rng))
    elif name == "wave":
        for i in range(7):
            # Side-view breaking crest with an overhang, full width segments.
            t = i/6
            for j in range(3):
                parts.append(cuboid(2+j*6, 1+t*12, 5+math.sin(t*math.pi*.8)*5,
                                     6.2, 2.6, 2.7, "ice" if i==6 else "water", rng, False))
    elif name == "heat_haze":
        for i in range(5):
            parts.append(cuboid(8+math.sin(i)*2, 2+i*2.7, 8+math.cos(i)*2,
                                 9-i*.8, 2.8, 1.1, "haze", rng))
    else:
        parts.append(cuboid(8, 8, 8, 8.4, 7.7, 8.8, "hot" if kind=="molten" else "rock0", rng))
        for i in range(count):
            # Fibonacci-shell distribution, perturbed by independent radial noise.
            a = i*2.399963229728653 + rng.random()*.5
            yy = 1-2*(i+.5)/count
            r = math.sqrt(max(0, 1-yy*yy))
            rad = rng.uniform(3.6, 6.2)
            cx, cy, cz = 8+math.cos(a)*r*rad, 8+yy*rad, 8+math.sin(a)*r*rad
            sx, sy, sz = (rng.uniform(2.2, 5.0) for _ in range(3))
            tex = "hot" if kind=="molten" or rng.random()<.16 else rng.choice(("rock0", "rock1", "rock2"))
            if kind in ("wood", "ice", "cloud"):
                tex = kind
            if kind == "wood":
                sx, sy, sz = sx*.45, sy*1.5, sz*.6
            parts.append(cuboid(cx, cy, cz, sx, sy, sz, tex, rng))
    return parts


MODELS = {
    "meteor_small": (15, "rock"), "meteor_medium": (29, "rock"),
    "meteor_large": (46, "rock"), "meteor_colossal": (68, "rock"),
    "meteor_fragment": (8, "rock"), "molten_core": (17, "molten"),
    "burning_shell": (35, "rock"), "meteorite_debris": (7, "rock"),
    "lava_fragment": (7, "molten"), "volcanic_rock": (14, "rock"),
    "magma_bomb": (20, "molten"), "cooling_rock": (13, "rock"),
    "wooden_debris": (6, "wood"), "stone_debris": (7, "rock"),
    "rotating_debris": (9, "rock"), "shockwave": (24, "molten"),
    "impact_debris": (9, "rock"), "scorched_rock": (12, "rock"),
    "ice_fragment": (8, "ice"), "storm_debris": (11, "wood"),
    "wave": (21, "water"), "cloud": (20, "cloud"), "heat_haze": (5, "haze")}


def blockbench(name, model):
    textures = []
    texture_ids = {}
    for i, (key, ref) in enumerate(model["textures"].items()):
        path = NS / ("textures/"+ref.split(":", 1)[1]+".png")
        texture_ids[key] = str(i)
        im = Image.open(path)
        textures.append({"path": str(path.relative_to(ROOT)), "name": path.name,
                         "id": str(i), "width": im.width, "height": im.height,
                         "uuid": str(uuid.uuid5(uuid.NAMESPACE_DNS, name+key)),
                         "source": "data:image/png;base64,"+base64.b64encode(path.read_bytes()).decode()})
    elements = []
    for i, el in enumerate(model["elements"]):
        rot = [0, 0, 0]
        if "rotation" in el:
            rot["xyz".index(el["rotation"]["axis"])] = el["rotation"]["angle"]
        elements.append({"name": f"rock_section_{i}", "type": "cube", "from": el["from"], "to": el["to"],
                         "origin": el.get("rotation", {}).get("origin", [8, 8, 8]), "rotation": rot,
                         "uuid": str(uuid.uuid5(uuid.NAMESPACE_DNS, name+str(i))),
                         "faces": {f: {"uv": d["uv"], "texture": texture_ids[d["texture"][1:]]}
                                   for f, d in el["faces"].items()}})
    write_json(ROOT / f"artwork/{name}.bbmodel", {"meta": {"format_version": "4.10", "model_format": "java_block", "box_uv": False},
               "name": name, "resolution": {"width": 16, "height": 16}, "elements": elements,
               "outliner": [e["uuid"] for e in elements], "textures": textures})


def models():
    refs = {"rock0": "cataclysm:item/rock_charcoal", "rock1": "cataclysm:item/rock_slate",
            "rock2": "cataclysm:item/rock_burned", "hot": "cataclysm:item/molten",
            "ice": "cataclysm:item/ice", "wood": "cataclysm:item/wood",
            "water": "cataclysm:item/water", "cloud": "cataclysm:item/cloud", "haze": "cataclysm:item/haze"}
    for index, (name, (count, kind)) in enumerate(MODELS.items()):
        geometry = rock_geometry(name, count, SEED+index*31, kind)
        used = {f["texture"][1:] for e in geometry for f in e["faces"].values()}
        model = {"ambientocclusion": False, "textures": {k: v for k, v in refs.items() if k in used},
                 "display": {"fixed": {"rotation": [0, 0, 0], "translation": [0, 0, 0], "scale": [1, 1, 1]},
                             "gui": {"rotation": [25, 35, 0], "translation": [0, 0, 0], "scale": [.65, .65, .65]}},
                 "elements": geometry}
        write_json(NS / f"models/item/{name}.json", model)
        write_json(NS / f"items/{name}.json", {"model": {"type": "minecraft:model", "model": f"cataclysm:item/{name}"}})
        if name.startswith("meteor_") or name in ("wave", "molten_core", "burning_shell"):
            blockbench(name, model)


# Every sound is an original distinct deterministic PCM composition, encoded with libvorbis.
# Parameter tuple: seconds, low-tone Hz, high noise mix, impulse decay, periodic modulation.
SOUNDS = {
    "warning": (2.4, 180, .12, .08, 2), "meteor_entry": (5, 41, .75, 0, 3),
    "meteor_crack": (1.2, 92, .95, 7, 19), "meteor_impact": (5, 28, 1, 1.7, 0),
    "rumble": (4, 34, .32, .3, 1), "tornado_wind": (5, 61, .82, 0, .7),
    "debris": (2, 100, .78, 1.1, 17), "earthquake_rumble": (5, 27, .6, 0, 2.4),
    "rock_crack": (1.8, 130, .95, 3.8, 13), "water_roar": (5, 68, .9, 0, .6),
    "wave_crash": (4, 48, 1, 1, 1.4), "volcano_pressure": (4, 32, .45, 0, 1.7),
    "volcano_eruption": (5, 26, 1, 1.4, .4), "lava_bubble": (3, 80, .3, .4, 7),
    "blizzard_wind": (5, 150, .72, 0, .9), "sandstorm_wind": (5, 110, .95, 0, 1.2),
    "fire_crackle": (4, 88, .8, 0, 24), "thunder": (5, 25, .85, 1, .5),
    "rain": (5, 240, 1, 0, 4), "lightning_crack": (2.2, 43, 1, 4, 15),
    "flood_rush": (5, 74, .87, 0, 1.8)}


def audio():
    encoder = shutil.which("ffmpeg")
    if not encoder:
        raise SystemExit("ffmpeg is required to encode original Vorbis audio")
    outdir = NS / "sounds"
    outdir.mkdir(parents=True, exist_ok=True)
    definitions = {}
    rate = 22050
    with tempfile.TemporaryDirectory(prefix="cataclysm-audio-") as temp:
        for index, (name, (duration, hz, noise_mix, decay, modulation)) in enumerate(SOUNDS.items()):
            rng = random.Random(SEED+index*67)
            count = int(duration*rate)
            samples = []
            low = 0.0
            mid = 0.0
            for n in range(count):
                t = n/rate
                white = rng.uniform(-1, 1)
                low += .018*(white-low)
                mid += .17*(white-mid)
                tone = (math.sin(math.tau*hz*t+math.sin(t*.7)*.9)*.4
                        + math.sin(math.tau*hz*.503*t)*.24)
                if name == "warning":
                    tone = math.sin(math.tau*(hz+35*math.sin(t*4))*t)*.65
                noise = low*3.5 + mid*.5 + white*.13
                if name in ("rain", "fire_crackle", "rock_crack", "meteor_crack"):
                    noise += white*.4
                if name == "fire_crackle" and rng.random() < .002:
                    noise += rng.uniform(-2.4, 2.4)
                env = min(1, t/.08)*min(1, (duration-t)/.45)
                env *= math.exp(-decay*t) if decay else .7+.3*math.sin(t*modulation*math.tau)**2
                if name in ("meteor_entry", "volcano_pressure"):
                    env *= .2+.8*t/duration
                signal = math.tanh((tone*(1-noise_mix*.65) + noise*noise_mix)*env)*.82
                samples.append(int(signal*32767))
            wav = Path(temp) / f"{name}.wav"
            with wave.open(str(wav), "wb") as writer:
                writer.setnchannels(1)
                writer.setsampwidth(2)
                writer.setframerate(rate)
                writer.writeframes(struct.pack("<"+"h"*len(samples), *samples))
            subprocess.run([encoder, "-v", "error", "-nostdin", "-y", "-i", str(wav),
                            "-c:a", "libvorbis", "-q:a", "4", "-fflags", "+bitexact", "-flags:a", "+bitexact", "-map_metadata", "-1", str(outdir / f"{name}.ogg")], check=True)
            definitions[name] = {"sounds": [{"name": f"cataclysm:{name}", "stream": False, "attenuation_distance": 96}]}
    write_json(NS / "sounds.json", definitions)


def icon():
    image = Image.new("RGBA", (128, 128), (11, 14, 23, 255))
    d = ImageDraw.Draw(image)
    for r in range(60, 0, -1):
        d.ellipse((64-r, 64-r, 64+r, 64+r), fill=(int(12+(60-r)*1.2), 15, 23))
    rng = random.Random(SEED)
    for _ in range(95):
        x, y = rng.randrange(128), rng.randrange(128)
        d.point((x, y), fill=(140, 160, 185))
    d.polygon([(22, 10), (87, 46), (105, 80), (75, 105), (45, 83)], fill=(255, 103, 17))
    d.polygon([(65, 43), (88, 48), (104, 68), (96, 88), (76, 103), (55, 86), (51, 64)], fill=(49, 46, 53))
    d.line([(65, 48), (77, 65), (67, 77), (83, 88), (89, 99)], fill=(255, 190, 55), width=3)
    image.save(PACK / "pack.png")


def package():
    dist = ROOT / "dist"
    dist.mkdir(exist_ok=True)
    output = dist / "CataclysmEngine-ResourcePack.zip"
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in sorted(PACK.rglob("*")):
            if path.is_file():
                info = zipfile.ZipInfo(path.relative_to(PACK).as_posix(), date_time=(2026, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o644 << 16
                z.writestr(info, path.read_bytes())
    digest = hashlib.sha1(output.read_bytes()).hexdigest()
    (dist / "CataclysmEngine-ResourcePack.sha1").write_text(digest+"\n")
    print(f"Generated {len(MODELS)} models, {len(SOUNDS)} sounds; {output.name} ({output.stat().st_size:,} bytes)")
    print(f"SHA-1: {digest}")


def main():
    PACK.mkdir(parents=True, exist_ok=True)
    write_json(PACK / "pack.mcmeta", {"pack": {"description": "Cataclysm Engine | Original cinematic disaster assets | Java 1.21.11", "min_format": [75, 0], "max_format": [75, 0]}})
    # Explicitly register our item-only textures in 1.21.11's item atlas.
    write_json(PACK / "assets/minecraft/atlases/items.json", {"sources": [{"type": "minecraft:directory", "source": "item", "prefix": "item/"}]})
    for index, name in enumerate(("rock_charcoal", "rock_slate", "rock_burned")):
        texture(name, SEED+index)
    texture("molten", SEED+44, molten=True, frames=8)
    for index, name in enumerate(("ice", "wood", "water", "cloud", "haze")):
        texture(name, SEED+70+index, material=name, frames=8 if name=="water" else 1)
    icon()
    models()
    audio()
    package()


if __name__ == "__main__":
    main()
