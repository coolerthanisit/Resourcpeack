#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ -z "${JAVA_HOME:-}" && -d /workspace/tooling/jdk-25.0.5+8 ]]; then
  export JAVA_HOME='/workspace/tooling/jdk-25.0.5+8'
fi
if [[ -n "${JAVA_HOME:-}" ]]; then export PATH="$JAVA_HOME/bin:$PATH"; fi
if ! java -version 2>&1 | head -n 1 | grep -Eq 'version "25[."]'; then
  echo 'Set JAVA_HOME to a Java 25 JDK before building.' >&2
  exit 1
fi
export GRADLE_USER_HOME="${GRADLE_USER_HOME:-$HOME/.gradle}"
./gradlew --no-daemon clean build
python3 tools/generate_assets.py
python3 tools/validate_assets.py
mkdir -p dist
cp build/libs/CataclysmEngine.jar dist/CataclysmEngine.jar
