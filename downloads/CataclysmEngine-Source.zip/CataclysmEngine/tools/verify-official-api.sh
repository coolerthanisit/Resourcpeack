#!/usr/bin/env bash
# Alternative verification when the official Maven host is unavailable.
# This compiles the real pinned Paper API sources; it does not emulate a server.
set -euo pipefail
cd "$(dirname "$0")/.."
project_root="$PWD"
cache="${CATACLYSM_TOOL_CACHE:-${XDG_CACHE_HOME:-$HOME/.cache}/cataclysm}"
mkdir -p "$cache"
fetch_source() {
  local directory="$1" url="$2" commit="$3"
  if [[ ! -d "$directory/.git" ]]; then
    git init -q "$directory"
    git -C "$directory" remote add origin "$url"
    git -C "$directory" fetch --depth 1 origin "$commit"
    git -C "$directory" checkout -q --detach FETCH_HEAD
  fi
  if [[ "$(git -C "$directory" rev-parse HEAD)" != "$commit" ]]; then
    echo "Unexpected source commit in $directory. Use a new CATACLYSM_TOOL_CACHE." >&2
    exit 1
  fi
  if [[ -n "$(git -C "$directory" status --porcelain)" ]]; then
    echo "Source checkout has local changes: $directory. Use a new CATACLYSM_TOOL_CACHE." >&2
    exit 1
  fi
}
fetch_source "$cache/paper-source" https://github.com/PaperMC/Paper.git c5eb0790f199da6c38d0a650e1e5cd5415b28185
fetch_source "$cache/brigadier-source" https://github.com/Mojang/brigadier.git b5419b186e4882290a188d11d6e661d4f56bd8fd
mkdir -p "$cache/paper-verify/brigadier"
cp tools/api-verification/build.gradle.kts tools/api-verification/settings.gradle.kts "$cache/paper-verify/"
cp tools/api-verification/brigadier/build.gradle.kts "$cache/paper-verify/brigadier/"
"$project_root/gradlew" --no-daemon --include-build "$cache/paper-verify" clean build coreTest
mkdir -p dist
cp build/libs/CataclysmEngine.jar dist/CataclysmEngine.jar
