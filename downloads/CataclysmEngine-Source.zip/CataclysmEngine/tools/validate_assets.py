#!/usr/bin/env python3
"""Validate the generated pack, including geometry refs, animation frames and audio."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import zipfile
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
PACK = ROOT / "resource-pack"


def asset(ref, category, suffix):
    namespace, name = ref.split(":", 1)
    return PACK / "assets" / namespace / category / (name+suffix)


def validate():
    files = list(PACK.rglob("*.json")) + [PACK / "pack.mcmeta"] + list(PACK.rglob("*.png.mcmeta"))
    data = {p: json.loads(p.read_text()) for p in files}
    meta = data[PACK / "pack.mcmeta"]["pack"]
    assert meta["min_format"] == [75, 0] and meta["max_format"] == [75, 0]
    atlas = data[PACK / "assets/minecraft/atlases/items.json"]
    assert any(s.get("source") == "item" and s.get("prefix") == "item/" and
               s.get("type") == "minecraft:directory" for s in atlas["sources"])
    for path in PACK.rglob("*.png"):
        with Image.open(path) as image:
            image.verify()
        with Image.open(path) as image:
            assert image.width > 0 and image.height > 0
            if path.name != "pack.png":
                assert len(image.getcolors(image.width*image.height) or []) > 10, f"Flat texture: {path}"
            animation = data.get(Path(str(path)+".mcmeta"), {}).get("animation")
            if animation:
                size = animation.get("height", image.width)
                assert image.height % size == 0
                assert all(0 <= f < image.height//size for f in animation["frames"])
    model_count = 0
    element_count = 0
    for path in (PACK / "assets/cataclysm/models").rglob("*.json"):
        model = data[path]
        assert len(model["elements"]) >= 5, path
        for texture in model["textures"].values():
            assert texture.startswith("cataclysm:item/"), f"Wrong atlas: {texture}"
            assert asset(texture, "textures", ".png").is_file(), texture
        for el in model["elements"]:
            assert all(-16 <= n <= 32 for n in el["from"] + el["to"]), path
            assert all(a < b for a, b in zip(el["from"], el["to"])), path
            assert len(el["faces"]) == 6
            if "rotation" in el:
                assert el["rotation"]["axis"] in "xyz"
                assert el["rotation"]["angle"] in (-45, -22.5, 0, 22.5, 45)
            for face in el["faces"].values():
                assert face["texture"][1:] in model["textures"], path
                assert all(0 <= u <= 16 for u in face["uv"])
        model_count += 1
        element_count += len(model["elements"])
    definitions = list((PACK / "assets/cataclysm/items").glob("*.json"))
    for path in definitions:
        definition = data[path]["model"]
        assert definition["type"] == "minecraft:model"
        assert asset(definition["model"], "models", ".json").is_file()
    sounds = data[PACK / "assets/cataclysm/sounds.json"]
    config = ROOT / "src/main/resources/sounds.yml"
    if config.is_file():
        layers = set(re.findall(r"^  ([a-z_]+):", config.read_text(), re.MULTILINE))
        assert layers == set(sounds), f"Sound config/pack mismatch: {layers ^ set(sounds)}"
    # Check literal references from the actual disaster implementations. Dynamic
    # slot names are ignored; all four dynamically selected meteor variants are
    # checked explicitly below.
    available_models = {p.stem for p in definitions}
    for source in (ROOT / "src/main/java/com/cataclysmengine/disaster").rglob("*.java"):
        text = source.read_text()
        for line in text.splitlines():
            if ".sound(" in line or re.search(r"\bsound\(", line):
                keys = re.findall(r'"([a-z_]+)"', line)
                assert all(key in sounds for key in keys), (source, keys)
        for key in re.findall(r'\.model\([^;]+?,\s*"([a-z_]+)"\s*,', text):
            assert key in available_models, (source, key)
        for key in re.findall(r'\bmodel\(d,\s*"[^"\n]+"(?:\+[^,]+)?,\s*"([a-z_]+)"', text):
            assert key in available_models, (source, key)
    assert all("meteor_"+size in available_models for size in ("small", "medium", "large", "colossal"))
    for name, entry in sounds.items():
        for sound in entry["sounds"]:
            path = asset(sound["name"], "sounds", ".ogg")
            assert path.stat().st_size > 1000, name
            assert path.read_bytes().startswith(b"OggS"), path
            # Decode completely: catches truncated streams that still carry an Ogg header.
            subprocess.run([shutil.which("ffmpeg") or "ffmpeg", "-v", "error", "-nostdin", "-i", str(path), "-f", "null", "-"], check=True, capture_output=True)
    output = ROOT / "dist/CataclysmEngine-ResourcePack.zip"
    with zipfile.ZipFile(output) as z:
        assert z.testzip() is None
        assert "pack.mcmeta" in z.namelist() and "pack.png" in z.namelist()
        assert all(not p.startswith("resource-pack/") for p in z.namelist())
        for path in PACK.rglob("*"):
            if path.is_file():
                assert z.read(path.relative_to(PACK).as_posix()) == path.read_bytes()
    digest = hashlib.sha1(output.read_bytes()).hexdigest()
    assert digest == (ROOT / "dist/CataclysmEngine-ResourcePack.sha1").read_text().strip()
    print(f"PASS: {len(files)} JSON/metadata files, {model_count} geometry models ({element_count} cuboids), "
          f"{len(definitions)} item definitions, {len(sounds)} decoded Vorbis sounds, PNGs, animations, ZIP root and SHA-1")


if __name__ == "__main__":
    validate()
