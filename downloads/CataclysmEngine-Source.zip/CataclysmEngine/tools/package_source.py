#!/usr/bin/env python3
"""Package the actual source tree and write a checksummed delivery manifest.

Run after the final build/tests and docs updates:
    python3 tools/package_source.py

Only project files are included. Git metadata, build/dependency caches, generated
delivery archives, credentials, local settings and symlinks are excluded.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import stat
import struct
import zipfile

ROOT = Path(__file__).resolve().parents[1]
EXCLUDED_DIRS = {".git", ".gradle", "build", "dist", ".idea", ".vscode", ".venv",
                 "venv", "node_modules", "__pycache__", ".pytest_cache", ".mypy_cache",
                 ".tools", ".codex", ".agents", ".aws", "attachments", "logs"}
EXCLUDED_FILES = {".env", "local.properties", ".DS_Store"}


def sha(path, algorithm="sha256"):
    digest = hashlib.new(algorithm)
    with path.open("rb") as stream:
        while chunk := stream.read(1024*1024):
            digest.update(chunk)
    return digest.hexdigest()


def source_paths():
    # rglob is deterministic after sorting; directories are excluded by path parts.
    for path in sorted(ROOT.rglob("*")):
        rel = path.relative_to(ROOT)
        if any(p in EXCLUDED_DIRS for p in rel.parts) or path.name in EXCLUDED_FILES:
            continue
        if path.name.startswith(".env.") and path.name not in (".env.example", ".env.sample"):
            continue
        if path.suffix in (".log", ".pyc", ".hprof") or path.is_symlink() or not path.is_file():
            continue
        yield path


def package(output: Path):
    output.parent.mkdir(parents=True, exist_ok=True)
    included = []
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in source_paths():
            if path == output:
                continue
            rel = path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo("CataclysmEngine/"+rel, date_time=(2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            mode = 0o755 if path.stat().st_mode & stat.S_IXUSR else 0o644
            info.external_attr = mode << 16
            archive.writestr(info, path.read_bytes())
            included.append(rel)
    with zipfile.ZipFile(output) as archive:
        assert archive.testzip() is None
        names = set(archive.namelist())
        assert "CataclysmEngine/gradlew" in names
        assert "CataclysmEngine/build.gradle.kts" in names
        assert any(n.startswith("CataclysmEngine/src/main/java/") for n in names)
    return included


def manifest(dist: Path, source: Path, included):
    artifacts = {}
    for path in (dist / "CataclysmEngine.jar", dist / "CataclysmEngine-ResourcePack.zip", source):
        if path.is_file():
            artifacts[path.name] = {"bytes": path.stat().st_size, "sha256": sha(path), "sha1": sha(path, "sha1")}
    result = {"project": "CataclysmEngine", "minecraft": "1.21.11", "server": "Paper",
              "java_release": 25, "resource_pack_format": [75, 0],
              "artifacts": artifacts, "source_files": len(included),
              "validation_note": "Artifact integrity does not establish client rendering quality or multiplayer performance. See README and test-results documentation."}
    jar = dist / "CataclysmEngine.jar"
    if jar.is_file():
        with zipfile.ZipFile(jar) as archive:
            class_names = [n for n in archive.namelist() if n.endswith(".class")]
            versions = set()
            for name in class_names:
                data = archive.read(name)
                assert data[:4] == b"\xca\xfe\xba\xbe"
                versions.add(struct.unpack(">H", data[6:8])[0])
            result["compiled_class_versions"] = sorted(versions)
            assert versions == {69}, f"Expected Java 25 bytecode 69, got {versions}"
            assert "plugin.yml" in archive.namelist()
    (dist / "MANIFEST.json").write_text(json.dumps(result, indent=2)+"\n")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "dist/CataclysmEngine-Source.zip")
    args = parser.parse_args()
    included = package(args.output.resolve())
    result = manifest(ROOT / "dist", args.output.resolve(), included)
    print(f"Created {args.output.name}: {len(included)} files; SHA-256 {sha(args.output)}")
    print(f"Wrote dist/MANIFEST.json for {len(result['artifacts'])} artifacts")


if __name__ == "__main__":
    main()
