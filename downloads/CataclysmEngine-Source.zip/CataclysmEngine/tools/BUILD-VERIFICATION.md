# Build verification provenance

The required ordinary build is `./gradlew clean build` with a Java 25 JDK. It declares `io.papermc.paper:paper-api:1.21.11-R0.1-SNAPSHOT` from Paper's official Maven repository. Gradle 9.2.1 wrapper distributions enforce the official SHA-256 `72f44c9f8ebcb1af43838f45ee5c4aa9c5444898b3468ab3f4af7b6076c5bc3f`.

The supplied cloud's network proxy rejects connections to the official Paper Maven and download hosts with HTTP 403. The normal `compileJava` was attempted and failed at dependency resolution, before the Java compiler. No TLS or package-integrity checks were disabled.

An additional actual Gradle composite build compiles all official Paper API Java sources from the Paper `ver/1.21.11` branch at commit `c5eb0790f199da6c38d0a650e1e5cd5415b28185`. This is actual API source, not invented stubs. Reproduce this verification with Java 25 and `tools/verify-official-api.sh`. The default Maven dependency is unchanged; `--include-build` substitutes the source project only for that invocation.

The isolated verification API build uses:

- Official Mojang Brigadier source commit `b5419b186e4882290a188d11d6e661d4f56bd8fd`, prior to the July 2026 changes, compiled as a dependency.
- Official BungeeCord chat `1.21-R0.2` from Maven Central in place of Paper's `1.21-R0.2-deprecated+build.21` fork. The plugin uses Adventure, not BungeeCord chat. This dependency difference is disclosed; this is not claimed as the official published API binary.
- Paper's declared library versions from Maven Central, including Adventure 4.26.1, JOML 1.10.8, Gson 2.11.0, SnakeYAML 2.2, and Guava 33.3.1-jre.

The JDK used was Eclipse Temurin OpenJDK `25.0.5+8`; its downloaded archive SHA-256 was checked against the official Adoptium release checksum (`68982529869257d0ee6b824ec5aa270ff8b118bb438670da0b97ebdab178d7fb`). Gradle's archive checksum was also checked before running.

`coreTest` is an independent Gradle/JUnit task that compiles the actual deterministic geometry, easing/force falloff, and rollback journal implementations. Nineteen tests passed with zero failed, errored, or skipped tests. The tests check crater bounds and angular noise, animation easing, radial force falloff, complete journal record ordering, interrupted-write recovery, lossless record-safe block-data encoding, timeline keyframe/easing interpolation, and bounded playback duration. Reports are generated in `build/test-results/coreTest` and `build/reports/tests/coreTest`.

A real Paper 1.21.11 server boot, client resource-pack rendering, multiplayer behavior, WorldGuard interoperability, and TPS/load behavior require validation on an actual server. The official GitHub Paper releases page contains no binary release assets; no server could be downloaded through an official alternate GitHub release. API compilation and pure-Java tests do not prove server startup or visual quality.

The complete source-API composite command `tools/verify-official-api.sh` finished successfully on Java 25: `clean build coreTest`. Both the normal `test` task and isolated `coreTest` executed the same 19 distinct tests with zero failures/errors/skips. The compiled `dist/CataclysmEngine.jar` contains actual Java 25 class files (class version 69), all eight YAML resources, and a plugin descriptor. All eight YAML files parsed successfully. This verifies Java compilation and packaging, not Paper server loading.
