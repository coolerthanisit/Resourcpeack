rootProject.name = "paper-api"
include("brigadier")
