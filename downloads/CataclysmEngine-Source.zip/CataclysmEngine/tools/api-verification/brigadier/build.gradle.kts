plugins { `java-library` }
group="com.mojang"
version="1.3.10"
java { toolchain.languageVersion.set(JavaLanguageVersion.of(25)) }
sourceSets.main { java.setSrcDirs(listOf("../../brigadier-source/src/main/java")) }
