package com.cataclysmengine.vfx.animation;

import static com.cataclysmengine.vfx.animation.AnimationTimeline.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;

class AnimationTimelineTest {
  private Pose pose(double x) {
    return new Pose(x, x * 2, -x, x * 3, -x, x, x / 10, x * 4);
  }

  private AnimationTimeline timeline(Easing easing) {
    return new AnimationTimeline(
        List.of(new Keyframe(0, pose(0), easing), new Keyframe(10, pose(10), Easing.LINEAR)),
        List.of(new SoundCue(0, "start"), new SoundCue(3, "rumble"), new SoundCue(8, "impact")));
  }

  @Test
  void interpolatesAllPropertiesAndClampsOutsideTimeline() {
    var animation = timeline(Easing.LINEAR);
    assertEquals(pose(0), animation.sample(-10));
    assertEquals(pose(10), animation.sample(100));
    assertEquals(pose(5), animation.sample(5));
    assertEquals(10, animation.duration());
  }

  @Test
  void easingChangesProgressWithoutBreakingEndpoints() {
    assertEquals(2.5, timeline(Easing.EASE_IN).sample(5).x(), 1e-9);
    assertEquals(7.5, timeline(Easing.EASE_OUT).sample(5).x(), 1e-9);
    for (var easing : Easing.values()) {
      assertEquals(0, easing.apply(0));
      assertEquals(1, easing.apply(1));
      assertEquals(0, easing.apply(-2));
      assertEquals(1, easing.apply(2));
    }
  }

  @Test
  void skippedTicksKeepSoundCuesAndAdjacentRangesNeverDuplicateThem() {
    var heard = new ArrayList<String>();
    var animation = timeline(Easing.LINEAR);
    animation.soundCuesBetween(-1, 3, c -> heard.add(c.key()));
    animation.soundCuesBetween(3, 10, c -> heard.add(c.key()));
    assertEquals(List.of("start", "rumble", "impact"), heard);
    assertThrows(IllegalArgumentException.class, () -> animation.soundCuesBetween(10, 0, c -> {}));
  }

  @Test
  void rejectsDuplicateTicksAndInvalidPoses() {
    assertThrows(
        IllegalArgumentException.class,
        () ->
            new AnimationTimeline(
                List.of(
                    new Keyframe(0, pose(0), Easing.LINEAR),
                    new Keyframe(0, pose(1), Easing.LINEAR)),
                List.of()));
    assertThrows(IllegalArgumentException.class, () -> new Pose(0, 0, 0, 0, 0, 1, 2, 1));
    assertThrows(IllegalArgumentException.class, () -> timeline(Easing.LINEAR).sample(Double.NaN));
  }
}
