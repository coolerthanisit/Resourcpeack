package com.cataclysmengine.physics;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class SimulationMathTest {
  @Test
  void easingClampsToEndpointsAndRemainsMonotonic() {
    assertEquals(0, SimulationMath.smoothStep(-3));
    assertEquals(1, SimulationMath.smoothStep(4));
    double previous = 0;
    for (int i = 0; i <= 100; i++) {
      double value = SimulationMath.smoothStep(i / 100.0);
      assertTrue(value >= previous && value >= 0 && value <= 1);
      previous = value;
    }
    assertEquals(0.25, SimulationMath.easeIn(0.5), 1e-9);
    assertEquals(0.75, SimulationMath.easeOut(0.5), 1e-9);
  }

  @Test
  void shockwaveWeakensWithDistanceAndStopsOutsideRadius() {
    assertEquals(1, SimulationMath.shockwaveStrength(0, 20));
    assertEquals(0.5, SimulationMath.shockwaveStrength(10, 20));
    assertEquals(0, SimulationMath.shockwaveStrength(20, 20));
    assertEquals(0, SimulationMath.shockwaveStrength(100, 20));
    assertTrue(Double.isFinite(SimulationMath.shockwaveStrength(1, 0)));
  }

  @Test
  void angularNoiseHasContinuousSeamAndBoundedIrregularity() {
    for (int i = 0; i < 360; i++) {
      double radius = SimulationMath.noisyRadius(Math.toRadians(i), 20, 0.3);
      assertTrue(radius >= 14 && radius <= 26);
    }
    assertEquals(
        SimulationMath.noisyRadius(0, 20, 0.3),
        SimulationMath.noisyRadius(Math.PI * 2, 20, 0.3),
        1e-9);
  }
}
