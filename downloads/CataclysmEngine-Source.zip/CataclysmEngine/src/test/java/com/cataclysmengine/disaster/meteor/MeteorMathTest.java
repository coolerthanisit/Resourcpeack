package com.cataclysmengine.disaster.meteor;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MeteorMathTest {
  @Test
  void craterBowlHasFiniteCenterAndNoOutsideExcavation() {
    assertEquals(8, MeteorMath.craterDepth(0, 0, 20, 8, .2, 1.7), 1.3);
    assertEquals(0, MeteorMath.craterDepth(30, 0, 20, 8, .2, 1.7));
    for (int x = -30; x <= 30; x++)
      for (int z = -30; z <= 30; z++) {
        double d = MeteorMath.craterDepth(x, z, 20, 8, .2, 1.7);
        assertTrue(Double.isFinite(d) && d >= 0 && d < 10);
      }
  }

  @Test
  void noiseVariesRimByAngleRatherThanGeneratingUniformCylinder() {
    assertNotEquals(
        MeteorMath.craterDepth(16, 0, 20, 8, .3, 1.7),
        MeteorMath.craterDepth(0, 16, 20, 8, .3, 1.7));
  }

  @Test
  void easingHasClampedEndpointsAndMonotonicProgress() {
    assertEquals(0, MeteorMath.smoothStep(-1));
    assertEquals(1, MeteorMath.smoothStep(2));
    double previous = 0;
    for (int i = 0; i <= 100; i++) {
      double next = MeteorMath.smoothStep(i / 100.0);
      assertTrue(next >= previous);
      previous = next;
    }
  }
}
