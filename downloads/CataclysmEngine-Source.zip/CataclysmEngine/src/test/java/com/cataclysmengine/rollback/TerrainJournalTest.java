package com.cataclysmengine.rollback;

import static org.junit.jupiter.api.Assertions.*;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class TerrainJournalTest {
  @TempDir Path directory;

  @Test
  void journalPreservesCompleteWriteAheadOperationsInOrder() throws Exception {
    Path file = directory.resolve("rollback.journal");
    TerrainJournal.append(file, "META|TEMPORARY|1234");
    TerrainJournal.append(file, "EDIT|world|1|2|3|original|applied");
    TerrainJournal.append(file, "RESTORE|world|1|2|3");
    assertEquals(
        List.of("META|TEMPORARY|1234", "EDIT|world|1|2|3|original|applied", "RESTORE|world|1|2|3"),
        TerrainJournal.read(file));
  }

  @Test
  void interruptedRecordIsIgnoredAndRepairedBeforeNextAppend() throws Exception {
    Path file = directory.resolve("crash.journal");
    TerrainJournal.append(file, "META|TEMPORARY|1234");
    Files.writeString(file, "EDIT|incomplete", StandardOpenOption.APPEND);
    assertEquals(List.of("META|TEMPORARY|1234"), TerrainJournal.read(file));
    TerrainJournal.repairTail(file);
    TerrainJournal.append(file, "ROLLBACK");
    assertEquals(List.of("META|TEMPORARY|1234", "ROLLBACK"), TerrainJournal.read(file));
  }

  @Test
  void corruptedHeaderWithoutAnyCompleteRecordIsTruncated() throws Exception {
    Path file = directory.resolve("empty-crash.journal");
    Files.writeString(file, "META|TEMPO");
    assertTrue(TerrainJournal.read(file).isEmpty());
    TerrainJournal.repairTail(file);
    assertEquals(0, Files.size(file));
  }

  @Test
  void blockDataIsRoundTrippableAndCannotInjectRecords() {
    String block =
        "minecraft:oak_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]";
    assertEquals(block, TerrainJournal.decode(TerrainJournal.encode(block)));
    String untrusted = "state|field\nEDIT|not-a-record";
    assertFalse(TerrainJournal.encode(untrusted).contains("|"));
    assertFalse(TerrainJournal.encode(untrusted).contains("\n"));
    assertEquals(untrusted, TerrainJournal.decode(TerrainJournal.encode(untrusted)));
  }
}
