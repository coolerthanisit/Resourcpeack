package com.cataclysmengine.disaster.environment;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class StormMathTest {
  @Test
  void faultsStayInsideTheirConfiguredRegionForManySeedsAndScales() {
    for (long seed = 0; seed < 80; seed++)
      for (double radius : new double[] {4, 12, 32, 80}) {
        var faults = StormMath.faults(seed, radius);
        assertTrue(faults.size() > 60, "A complete fault graph must be generated");
        assertTrue(faults.stream().allMatch(p -> Math.hypot(p.x(), p.z()) < radius));
        assertTrue(faults.stream().allMatch(p -> p.depth() >= 1 && p.depth() <= 3));
        assertTrue(faults.stream().anyMatch(p -> p.x() > radius * .3));
        assertTrue(faults.stream().anyMatch(p -> p.x() < -radius * .3));
        assertTrue(faults.stream().anyMatch(p -> p.z() > radius * .3));
        assertTrue(faults.stream().anyMatch(p -> p.z() < -radius * .3));
      }
  }

  @Test
  void recoveryAndPreviewCanReuseIdenticalFaultGeometry() {
    assertEquals(StormMath.faults(142, 32), StormMath.faults(142, 32));
    assertNotEquals(StormMath.faults(142, 32), StormMath.faults(143, 32));
    assertThrows(IllegalArgumentException.class, () -> StormMath.faults(1, Double.NaN));
  }

  @Test
  void persistentStormsCannotEscapeTheirBoundedTravelEvenWithHugeDuration() {
    assertEquals(24, StormMath.boundedTravel(1e9, 200, 32));
    assertEquals(0, StormMath.boundedTravel(100, -5, 32));
    assertEquals(0, StormMath.boundedTravel(Double.POSITIVE_INFINITY, 1, 32));
    assertEquals(3, StormMath.boundedTravel(5, .6, 32), 1e-9);
  }

  @Test
  void funnelNarrowsAtGroundAndScalesContinuouslyWithStrength() {
    for (int intensity = 1; intensity <= 5; intensity++) {
      double last = 0;
      for (int i = 0; i <= 100; i++) {
        double r = StormMath.funnelRadius(i / 100.0, intensity, .8);
        assertTrue(r >= last);
        last = r;
      }
      assertEquals(0, StormMath.funnelRadius(.7, intensity, 0));
      assertEquals(.5, StormMath.funnelRadius(0, intensity, 1));
      assertTrue(
          StormMath.funnelRadius(1, intensity, 1) > StormMath.funnelRadius(0, intensity, 1) * 6);
    }
  }

  @Test
  void floodLevelRisesContinuouslyAndRecedesWithinBounds() {
    assertEquals(StormMath.floodFraction("FORMATION", 1), StormMath.floodFraction("ACTIVE", 0));
    assertEquals(StormMath.floodFraction("ACTIVE", 1), StormMath.floodFraction("DISSIPATION", 0));
    for (int i = 0; i < 100; i++) {
      double t = i / 100.0, next = (i + 1) / 100.0;
      assertTrue(StormMath.floodFraction("ACTIVE", next) >= StormMath.floodFraction("ACTIVE", t));
      assertTrue(
          StormMath.floodFraction("DISSIPATION", next)
              <= StormMath.floodFraction("DISSIPATION", t));
    }
    assertEquals(0, StormMath.floodFraction("AFTERMATH", 1));
  }
}
