package com.cataclysmengine.api;

import java.util.UUID;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.HandlerList;

public final class DisasterDamageEvent extends CataclysmEvent {
  private static final HandlerList HANDLERS = new HandlerList();
  private final LivingEntity entity;
  private final double damage;

  public DisasterDamageEvent(UUID id, LivingEntity entity, double damage) {
    super(id);
    this.entity = entity;
    this.damage = damage;
  }

  public LivingEntity getEntity() {
    return entity;
  }

  public double getDamage() {
    return damage;
  }

  public HandlerList getHandlers() {
    return HANDLERS;
  }

  public static HandlerList getHandlerList() {
    return HANDLERS;
  }
}
