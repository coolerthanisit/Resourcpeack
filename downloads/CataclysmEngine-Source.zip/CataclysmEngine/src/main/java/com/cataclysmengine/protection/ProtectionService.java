package com.cataclysmengine.protection;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.*;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

/** Main-thread protection checks. Unknown or failing protection adapters deny changes. */
public final class ProtectionService {
  private final JavaPlugin plugin;
  private final Map<String, Zone> regions = new LinkedHashMap<>();
  private final Map<UUID, Location[]> selections = new HashMap<>();
  private final File zonesFile;
  private YamlConfiguration settings;
  private boolean warned;

  public ProtectionService(JavaPlugin plugin) {
    this.plugin = plugin;
    this.zonesFile = new File(plugin.getDataFolder(), "protection-zones.yml");
    reload();
  }

  public void reload() {
    settings =
        YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "protection.yml"));
    regions.clear();
    var yaml = YamlConfiguration.loadConfiguration(zonesFile);
    var section = yaml.getConfigurationSection("zones");
    if (section != null)
      for (String name : section.getKeys(false)) {
        try {
          String p = "zones." + name + ".";
          regions.put(
              name,
              new Zone(
                  UUID.fromString(yaml.getString(p + "world", "")),
                  yaml.getInt(p + "min-x"),
                  yaml.getInt(p + "min-y"),
                  yaml.getInt(p + "min-z"),
                  yaml.getInt(p + "max-x"),
                  yaml.getInt(p + "max-y"),
                  yaml.getInt(p + "max-z")));
        } catch (IllegalArgumentException ex) {
          throw new IllegalStateException("Invalid saved safe zone: " + name, ex);
        }
      }
    warned = false;
  }

  public boolean allowed(Location location) {
    World world = location.getWorld();
    if (world == null || !world.isChunkLoaded(location.getBlockX() >> 4, location.getBlockZ() >> 4))
      return false;
    if (!world.getWorldBorder().isInside(location)) return false;
    for (Zone zone : regions.values()) if (zone.contains(location)) return false;
    if (settings.getBoolean("respect-spawn", true)) {
      Location spawn = world.getSpawnLocation();
      int radius = Math.max(Bukkit.getSpawnRadius(), settings.getInt("spawn-radius", 32));
      if (Math.abs(location.getBlockX() - spawn.getBlockX()) <= radius
          && Math.abs(location.getBlockZ() - spawn.getBlockZ()) <= radius) return false;
    }
    if (settings.getBoolean("respect-worldguard", true)
        && Bukkit.getPluginManager().getPlugin("WorldGuard") != null
        && !worldGuardAllowed(location)) return false;
    // No undocumented bypasses: unsupported installed claim systems are conservative by default.
    List<String> unsupported = settings.getStringList("fail-closed-plugins");
    if (unsupported.isEmpty())
      unsupported = List.of("GriefPrevention", "GriefDefender", "Lands", "Towny", "Residence");
    for (String name : unsupported)
      if (Bukkit.getPluginManager().getPlugin(name) != null) return false;
    return true;
  }

  private boolean worldGuardAllowed(Location location) {
    try {
      Plugin wgPlugin = Bukkit.getPluginManager().getPlugin("WorldGuard");
      if (wgPlugin == null || !wgPlugin.isEnabled()) return false;
      ClassLoader loader = wgPlugin.getClass().getClassLoader();
      Class<?> wg = Class.forName("com.sk89q.worldguard.WorldGuard", true, loader);
      Object singleton = wg.getMethod("getInstance").invoke(null);
      Object platform = wg.getMethod("getPlatform").invoke(singleton);
      Object container = platform.getClass().getMethod("getRegionContainer").invoke(platform);
      Object query = container.getClass().getMethod("createQuery").invoke(container);
      Class<?> adapter = Class.forName("com.sk89q.worldedit.bukkit.BukkitAdapter", true, loader);
      Object adapted = adapter.getMethod("adapt", Location.class).invoke(null, location);
      Class<?> state =
          Class.forName("com.sk89q.worldguard.protection.flags.StateFlag", true, loader);
      Class<?> flags = Class.forName("com.sk89q.worldguard.protection.flags.Flags", true, loader);
      Object array = Array.newInstance(state, 1);
      Array.set(array, 0, flags.getField("BUILD").get(null));
      Class<?> loc = Class.forName("com.sk89q.worldedit.util.Location", true, loader);
      Class<?> associable =
          Class.forName(
              "com.sk89q.worldguard.protection.association.RegionAssociable", true, loader);
      return (boolean)
          query
              .getClass()
              .getMethod("testState", loc, associable, array.getClass())
              .invoke(query, adapted, null, array);
    } catch (ReflectiveOperationException | RuntimeException | LinkageError ex) {
      if (!warned) {
        plugin
            .getLogger()
            .warning(
                "WorldGuard protection query unavailable; terrain changes denied: "
                    + ex.getClass().getSimpleName());
        warned = true;
      }
      return false;
    }
  }

  public void setPosition(UUID player, int index, Location location) {
    if (index < 1 || index > 2 || location.getWorld() == null)
      throw new IllegalArgumentException("Select position 1 or 2 in a world.");
    selections.computeIfAbsent(player, key -> new Location[2])[index - 1] = location.clone();
  }

  public void createZone(UUID player, String name) {
    if (!name.matches("[A-Za-z0-9_-]{1,48}"))
      throw new IllegalArgumentException(
          "Zone name must use 1–48 letters, numbers, underscores or dashes.");
    if (regions.containsKey(name))
      throw new IllegalArgumentException("A zone with that name already exists.");
    Location[] points = selections.get(player);
    if (points == null || points[0] == null || points[1] == null)
      throw new IllegalArgumentException("Select both positions first.");
    Location a = points[0], b = points[1];
    if (!Objects.equals(a.getWorld(), b.getWorld()))
      throw new IllegalArgumentException("Positions must be in the same world.");
    Zone zone =
        new Zone(
            a.getWorld().getUID(),
            Math.min(a.getBlockX(), b.getBlockX()),
            Math.min(a.getBlockY(), b.getBlockY()),
            Math.min(a.getBlockZ(), b.getBlockZ()),
            Math.max(a.getBlockX(), b.getBlockX()),
            Math.max(a.getBlockY(), b.getBlockY()),
            Math.max(a.getBlockZ(), b.getBlockZ()));
    regions.put(name, zone);
    try {
      save();
    } catch (RuntimeException ex) {
      regions.remove(name);
      throw ex;
    }
  }

  public void removeZone(String name) {
    Zone previous = regions.remove(name);
    if (previous == null) throw new IllegalArgumentException("Unknown zone: " + name);
    try {
      save();
    } catch (RuntimeException ex) {
      regions.put(name, previous);
      throw ex;
    }
  }

  public List<String> zones() {
    return List.copyOf(regions.keySet());
  }

  public void forgetSelection(UUID player) {
    selections.remove(player);
  }

  private void save() {
    YamlConfiguration yaml = new YamlConfiguration();
    regions.forEach(
        (name, zone) -> {
          String p = "zones." + name + ".";
          yaml.set(p + "world", zone.world().toString());
          yaml.set(p + "min-x", zone.minX());
          yaml.set(p + "min-y", zone.minY());
          yaml.set(p + "min-z", zone.minZ());
          yaml.set(p + "max-x", zone.maxX());
          yaml.set(p + "max-y", zone.maxY());
          yaml.set(p + "max-z", zone.maxZ());
        });
    try {
      java.nio.file.Files.createDirectories(zonesFile.toPath().getParent());
      File temp = new File(zonesFile.getParentFile(), "protection-zones.yml.tmp");
      yaml.save(temp);
      try {
        java.nio.file.Files.move(
            temp.toPath(),
            zonesFile.toPath(),
            java.nio.file.StandardCopyOption.ATOMIC_MOVE,
            java.nio.file.StandardCopyOption.REPLACE_EXISTING);
      } catch (java.nio.file.AtomicMoveNotSupportedException ex) {
        java.nio.file.Files.move(
            temp.toPath(), zonesFile.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
      }
    } catch (IOException ex) {
      throw new IllegalStateException("Cannot persist safe zones; operation cancelled.", ex);
    }
  }

  public record Zone(UUID world, int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
    public boolean contains(Location l) {
      return l.getWorld() != null
          && world.equals(l.getWorld().getUID())
          && l.getBlockX() >= minX
          && l.getBlockX() <= maxX
          && l.getBlockY() >= minY
          && l.getBlockY() <= maxY
          && l.getBlockZ() >= minZ
          && l.getBlockZ() <= maxZ;
    }
  }
}
