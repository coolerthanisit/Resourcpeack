package com.cataclysmengine.disaster.supercell;

import com.cataclysmengine.disaster.*;
import com.cataclysmengine.disaster.environment.EnvironmentBehavior;
import org.bukkit.*;
import org.bukkit.util.Vector;

/**
 * A moving mesocyclone cloud deck with rain curtains, gusts and finite branched lightning paths.
 */
public final class SupercellBehavior extends EnvironmentBehavior {
  private Location strike;
  private int strikeAt = -100;

  @Override
  public void tick(Disaster d) {
    if (d.phase() == Phase.AFTERMATH && !d.option("aftermath", true)) {
      hideAll(d);
      return;
    }
    if (d.age() % 3 != 0) return;
    Location center = movingCenter(d);
    double strength = d.strength();
    Vector wind = wind(d);
    sound(d, center, "rain", .2 + strength, .9);
    if (d.age() % 120 == 0) d.vfx().sound(d, center, "thunder", (float) (.2 + strength), .7f);
    if (d.phase() == Phase.AFTERMATH) {
      hideAll(d);
      particle(d, Particle.FALLING_WATER, center, 3, 5);
      return;
    }
    for (int i = 0; i < 12; i++) {
      double angle = i * Math.PI / 6 + d.age() * .005, r = 8 + (i % 3) * 4;
      Location cloud =
          center
              .clone()
              .add(
                  Math.cos(angle) * r,
                  25 + (i % 3) * 2 + Math.sin(d.age() * .02 + i),
                  Math.sin(angle) * r);
      model(
          d,
          "cloud" + i,
          "cloud",
          cloud,
          (3 + strength * 5) * strength,
          angle,
          Math.sin(angle) * .05,
          false);
      dust(d, cloud, Color.fromRGB(65, 66, 79), 2.5f, 2, 2);
    }
    for (var player : center.getWorld().getPlayers()) {
      if (player.getLocation().distanceSquared(center) > d.radius() * d.radius()) continue;
      for (int i = 0; i < 8; i++) {
        double f = (d.age() * .055 + i * .618) % 1;
        Location rain =
            player
                .getLocation()
                .add(Math.sin(i * 7.3) * 6, 10 - f * 10, Math.cos(i * 3.8) * 6)
                .add(wind.clone().multiply(f * 3));
        particle(d, Particle.FALLING_WATER, rain, 2, .4);
      }
      if (hazardous(d) && d.age() % 12 == 0)
        d.force(player, wind.clone().multiply(.025 * d.intensity()));
      if (d.age() % 12 == 0) particle(d, Particle.SPLASH, player.getLocation(), 2, .9);
    }
    if (d.phase() != Phase.ACTIVE) return;
    boolean reduced =
        d.option("reduced-flash", true)
            || d.plugin().settings().file("visuals").getBoolean("reduced-flash", true);
    int interval =
        (int)
            Math.clamp(
                d.value("lightning-interval", reduced ? 180 : 100), reduced ? 120 : 50, 1200);
    if (d.age() - strikeAt >= interval) {
      strike = sample(d, d.radius() * .8);
      if (strike != null && d.plugin().protection().allowed(strike)) {
        strikeAt = d.age();
        d.vfx().sound(d, strike, "lightning_crack", 1.4f, 1);
        // Vanilla visual lightning uses a real lightning entity, but its uncontrolled damage/fire
        // are disabled.
        // Gameplay damage remains inside the same cancellable/protected path as every other
        // disaster.
        if (d.option("real-lightning", false) && !reduced && d.option("visuals", true))
          strike.getWorld().strikeLightningEffect(strike);
        for (var entity : living(strike, 3.5)) d.damage(entity, 1 + d.intensity());
      }
    }
    if (strike != null && d.age() - strikeAt <= 9) {
      if (!reduced) particle(d, Particle.ELECTRIC_SPARK, strike, 5, 1);
      for (int branch = 0; branch < 2; branch++)
        for (int step = 0; step < 14; step++) {
          double f = step / 13.0,
              x = Math.sin(step * 7.3 + strikeAt) * 1.2,
              z = Math.cos(step * 5.3 + strikeAt) * 1.2;
          if (branch == 1) {
            x += f * 4;
            z -= f * 3;
          }
          Location p = strike.clone().add(x, f * (branch == 0 ? 28 : 13), z);
          dust(
              d,
              p,
              reduced ? Color.fromRGB(127, 144, 184) : Color.fromRGB(227, 233, 255),
              reduced ? .65f : 1.2f,
              1,
              .1);
        }
    }
    for (int i = 0; i < 5; i++) {
      double a = i * 2.4 + d.age() * .08;
      Location p = center.clone().add(Math.cos(a) * 6, 1 + (i % 3) * .6, Math.sin(a) * 6);
      model(d, "debris" + i, "storm_debris", p, .2 + strength * .3, a, a * .3, false);
    }
  }
}
