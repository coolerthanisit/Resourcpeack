package com.cataclysmengine.disaster.tsunami;

import com.cataclysmengine.disaster.*;
import com.cataclysmengine.disaster.environment.EnvironmentBehavior;
import org.bukkit.*;
import org.bukkit.entity.LivingEntity;
import org.bukkit.util.Vector;

/** An advancing curved crest with independently animated face, foam and trailing surge layers. */
public final class TsunamiBehavior extends EnvironmentBehavior {
  private int flooded;

  @Override
  public void tick(Disaster d) {
    if (d.phase() == Phase.AFTERMATH && !d.option("aftermath", true)) {
      hideAll(d);
      return;
    }
    if (d.age() % 2 != 0) return;
    double s = d.strength();
    Vector direction = wind(d), across = new Vector(-direction.getZ(), 0, direction.getX());
    double progress =
        switch (d.phase()) {
          case WARNING, FORMATION -> 0;
          case ACTIVE -> d.progress();
          default -> 1;
        };
    double offset = -d.radius() * .75 + progress * d.radius() * 1.5;
    Location center = d.origin().add(direction.clone().multiply(offset));
    double maxHeight = Math.min(26, d.value("wave-height", 6 + d.intensity() * 3));
    double height = maxHeight * s;
    sound(d, center, "water_roar", .2 + s * 1.3, .8f);
    if (d.phase() == Phase.WARNING) {
      for (int i = 0; i < 8; i++) {
        Location p =
            d.origin()
                .add(direction.clone().multiply(-d.radius() * .7))
                .add(across.clone().multiply((i - 3.5) * 3));
        particle(d, Particle.SPLASH, p, 2, .6);
      }
      return;
    }
    if (d.phase() == Phase.AFTERMATH) {
      hideAll(d);
      for (int i = 0; i < 4; i++) {
        Location p = sample(d, d.radius());
        if (p != null) particle(d, Particle.SPLASH, p, 3, .6);
      }
      return;
    }
    int segments = 12;
    for (int i = 0; i < segments; i++) {
      double lateral = (i - (segments - 1) / 2.0) * d.radius() / segments * 1.6;
      double arch = 1 - .25 * Math.pow(lateral / Math.max(1, d.radius()), 2);
      double wobble = Math.sin(d.age() * .05 + i * .9) * .6;
      Location base = center.clone().add(across.clone().multiply(lateral));
      Location surface = surface(base);
      if (surface == null) continue;
      // The sea-level datum does not climb intact buildings; the visible crest is attenuated by
      // terrain.
      double raisedGround = Math.max(0, surface.getY() - d.origin().getY());
      double localHeight = Math.max(.3, height * arch - raisedGround * .7);
      for (int layer = 0; layer < 2; layer++) {
        Location p =
            base.clone()
                .add(direction.clone().multiply(-layer * 2))
                .add(0, localHeight * .42 + wobble, 0);
        model(
            d,
            "wave" + i + "_" + layer,
            "wave",
            p,
            Math.max(.15, localHeight * .55),
            (float) Math.atan2(direction.getZ(), direction.getX()),
            Math.sin(d.age() * .025 + i) * .06,
            false);
      }
      Location crest =
          base.clone().add(direction.clone().multiply(.9)).add(0, localHeight + wobble, 0);
      particle(d, Particle.CLOUD, crest, 2, .9);
      particle(d, Particle.SPLASH, crest, 4, 1.2);
      particle(d, Particle.FALLING_WATER, base.clone().add(0, localHeight * .6, 0), 3, .7);
    }
    if (hazardous(d) && d.age() % 4 == 0) {
      for (LivingEntity e : living(center, Math.min(d.radius(), height + 7))) {
        Vector relative = e.getLocation().toVector().subtract(center.toVector());
        if (Math.abs(relative.dot(direction)) < 6 && e.getY() < center.getY() + height) {
          d.force(e, direction.clone().multiply(.15 + .05 * d.intensity()).setY(.12));
          particle(d, Particle.SPLASH, e.getLocation(), 5, .5);
          if (d.age() % 20 == 0) d.damage(e, .5 * d.intensity());
        }
      }
      int max = (int) Math.clamp(d.value("flooding.max-area", 256), 0, 4096);
      int depth = (int) Math.clamp(d.value("flooding.max-depth", 3), 1, 8);
      for (int n = 0; n < 8 && flooded < max; n++) {
        Location p =
            surface(
                center
                    .clone()
                    .add(
                        across
                            .clone()
                            .multiply(random.nextDouble(-d.radius() * .7, d.radius() * .7)))
                    .subtract(direction.clone().multiply(random.nextDouble(1, 5))));
        if (p == null || !inside(d, p) || p.getY() > d.origin().getY() + depth) continue;
        for (int y = 0; y < depth && flooded < max; y++)
          if (water(d, p.clone().add(0, y, 0), "water")) flooded++;
      }
    }
  }
}
