package com.cataclysmengine.api;

import com.cataclysmengine.disaster.Disaster;
import java.util.UUID;
import org.bukkit.event.HandlerList;

public final class DisasterWarningEvent extends CataclysmEvent {
  private static final HandlerList HANDLERS = new HandlerList();
  private final Disaster disaster;

  public DisasterWarningEvent(UUID id, Disaster disaster) {
    super(id);
    this.disaster = disaster;
  }

  public Disaster getDisaster() {
    return disaster;
  }

  public HandlerList getHandlers() {
    return HANDLERS;
  }

  public static HandlerList getHandlerList() {
    return HANDLERS;
  }
}
