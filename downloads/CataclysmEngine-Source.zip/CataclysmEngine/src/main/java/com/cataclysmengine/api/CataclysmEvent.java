package com.cataclysmengine.api;

import java.util.UUID;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;

public abstract class CataclysmEvent extends Event implements Cancellable {
  private final UUID id;
  private boolean cancelled;

  protected CataclysmEvent(UUID id) {
    this.id = id;
  }

  public UUID getDisasterId() {
    return id;
  }

  public boolean isCancelled() {
    return cancelled;
  }

  public void setCancelled(boolean value) {
    cancelled = value;
  }
}
