package com.cataclysmengine.disaster;

public interface DisasterBehavior {
  void tick(Disaster d);

  default void close(Disaster d) {
    d.vfx().cleanup(d.id());
  }
}
