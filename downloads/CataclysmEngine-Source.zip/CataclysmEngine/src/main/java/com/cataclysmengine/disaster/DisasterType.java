package com.cataclysmengine.disaster;

import org.bukkit.Material;

public enum DisasterType {
  METEOR(Material.MAGMA_BLOCK, "Meteor Strike", "meteor_entry"),
  TORNADO(Material.HOPPER, "Tornado", "tornado_wind"),
  EARTHQUAKE(Material.CRACKED_STONE_BRICKS, "Earthquake", "earthquake_rumble"),
  TSUNAMI(Material.PRISMARINE, "Tsunami", "water_roar"),
  VOLCANO(Material.OBSIDIAN, "Volcanic Eruption", "volcano_pressure"),
  BLIZZARD(Material.SNOW_BLOCK, "Blizzard", "blizzard_wind"),
  SANDSTORM(Material.SAND, "Sandstorm", "sandstorm_wind"),
  WILDFIRE(Material.CAMPFIRE, "Wildfire", "fire_crackle"),
  SUPERCELL(Material.LIGHTNING_ROD, "Supercell Thunderstorm", "thunder"),
  FLOOD(Material.WATER_BUCKET, "Flash Flood", "flood_rush");
  public final Material icon;
  public final String title, sound;

  DisasterType(Material m, String t, String s) {
    icon = m;
    title = t;
    sound = s;
  }

  public String key() {
    return name().toLowerCase(java.util.Locale.ROOT);
  }

  public static DisasterType parse(String s) {
    return valueOf(
        s.toUpperCase(java.util.Locale.ROOT)
            .replace("FLASH_FLOOD", "FLOOD")
            .replace("METEOR_STRIKE", "METEOR")
            .replace("VOLCANIC_ERUPTION", "VOLCANO")
            .replace("SUPERCELL_THUNDERSTORM", "SUPERCELL"));
  }
}
