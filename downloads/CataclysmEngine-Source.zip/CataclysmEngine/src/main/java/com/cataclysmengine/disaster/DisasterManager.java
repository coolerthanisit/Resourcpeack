package com.cataclysmengine.disaster;

import com.cataclysmengine.CataclysmEnginePlugin;
import com.cataclysmengine.api.*;
import com.cataclysmengine.terrain.DestructionMode;
import java.util.*;
import org.bukkit.*;
import org.bukkit.entity.Player;

/** Public synchronous plugin API. Calls must originate on the server thread. */
public final class DisasterManager {
  private final CataclysmEnginePlugin plugin;
  private final Map<UUID, Disaster> active = new LinkedHashMap<>();
  private final Map<String, Long> cooldowns = new HashMap<>();
  private final Map<UUID, Long> nextNatural = new HashMap<>();
  private long lastNatural;

  public DisasterManager(CataclysmEnginePlugin p) {
    plugin = p;
  }

  public Collection<Disaster> active() {
    return List.copyOf(active.values());
  }

  public Disaster get(UUID id) {
    return active.get(id);
  }

  public boolean inRegion(Location l) {
    return active.values().stream()
        .anyMatch(
            d ->
                d.origin().getWorld().equals(l.getWorld())
                    && d.origin().distanceSquared(l) <= d.radius() * d.radius());
  }

  public boolean worldAllowed(World w) {
    var cfg = plugin.settings().file("worlds");
    var white = cfg.getStringList("whitelist");
    return (white.isEmpty() || white.contains(w.getName()))
        && !cfg.getStringList("blacklist").contains(w.getName());
  }

  public Disaster start(DisasterType t, Location loc, boolean preview, boolean instant) {
    if (!Bukkit.isPrimaryThread())
      throw new IllegalStateException("Disasters must start on the server thread");
    if (!plugin.getConfig().getBoolean("enabled", true)
        || !plugin.settings().bool(t, "enabled", true))
      throw new IllegalArgumentException("This disaster is disabled");
    World w = loc.getWorld();
    if (w == null || !worldAllowed(w))
      throw new IllegalArgumentException("World is unavailable or excluded");
    if (!Double.isFinite(loc.getX())
        || !Double.isFinite(loc.getY())
        || !Double.isFinite(loc.getZ())
        || loc.getY() < w.getMinHeight()
        || loc.getY() >= w.getMaxHeight()
        || !w.getWorldBorder().isInside(loc))
      throw new IllegalArgumentException("Target coordinates are outside world bounds");
    if (!w.isChunkLoaded(loc.getBlockX() >> 4, loc.getBlockZ() >> 4))
      throw new IllegalArgumentException("Target chunk must already be loaded");
    if (!plugin.protection().allowed(loc))
      throw new IllegalArgumentException("Target is protected");
    if (active.size() >= plugin.getConfig().getInt("limits.max-concurrent", 3))
      throw new IllegalArgumentException("Concurrent disaster limit reached");
    DestructionMode mode;
    try {
      mode =
          DestructionMode.valueOf(
              plugin
                  .getConfig()
                  .getString("default-destruction-mode", "VISUAL_ONLY")
                  .toUpperCase(Locale.ROOT));
    } catch (IllegalArgumentException e) {
      throw new IllegalArgumentException("Invalid destruction mode in config.yml");
    }
    if (mode == DestructionMode.PERMANENT
        && !plugin.getConfig().getBoolean("destruction.allow-permanent", false))
      throw new IllegalArgumentException(
          "Permanent destruction requires destruction.allow-permanent: true");
    Disaster d = new Disaster(plugin, t, loc, preview, instant, mode);
    var event = new DisasterStartEvent(d.id(), d);
    Bukkit.getPluginManager().callEvent(event);
    if (event.isCancelled())
      throw new IllegalArgumentException("Another plugin cancelled the disaster");
    active.put(d.id(), d);
    plugin.terrain().begin(d.id(), d.mode());
    plugin.warn(d, true);
    cooldowns.put(
        w.getUID() + ":" + t.key(),
        System.currentTimeMillis() + plugin.settings().integer(t, "cooldown", 300) * 1000L);
    return d;
  }

  public boolean stop(UUID id) {
    Disaster d = active.get(id);
    if (d == null) return false;
    try {
      d.close();
    } finally {
      active.remove(id);
      plugin.hideWarning(id);
      plugin.terrain().finish(id);
      Bukkit.getPluginManager().callEvent(new DisasterEndEvent(id, d));
    }
    return true;
  }

  public void stopAll() {
    new ArrayList<>(active.keySet()).forEach(this::stop);
  }

  public void tick() {
    for (Disaster d : active()) {
      try {
        d.tick();
        if (d.phase() == Phase.ENDED) {
          stop(d.id());
          continue;
        }
        if (d.age() % 20 == 0) plugin.warn(d, false);
      } catch (Exception ex) {
        plugin
            .getLogger()
            .log(
                java.util.logging.Level.SEVERE,
                "Disaster " + d.id() + " stopped after failure",
                ex);
        stop(d.id());
      }
    }
  }

  public boolean eligible(DisasterType t, Location l) {
    World w = l.getWorld();
    if (w == null
        || w.getEnvironment() != World.Environment.NORMAL
        || !worldAllowed(w)
        || !plugin.settings().bool(t, "enabled", true)
        || !plugin.protection().allowed(l)
        || inRegion(l)) return false;
    if (cooldowns.getOrDefault(w.getUID() + ":" + t.key(), 0L) > System.currentTimeMillis())
      return false;
    String biome = w.getBiome(l).name().toLowerCase(Locale.ROOT);
    var allowed = plugin.settings().file("disasters").getStringList(t.key() + ".allowed-biomes");
    if (!allowed.isEmpty() && allowed.stream().noneMatch(x -> x.equalsIgnoreCase(biome)))
      return false;
    Material surface =
        w.getBlockAt(l.getBlockX(), Math.max(w.getMinHeight(), l.getBlockY() - 1), l.getBlockZ())
            .getType();
    return switch (t) {
      case SANDSTORM -> biome.contains("desert") || biome.contains("badlands");
      case BLIZZARD ->
          biome.contains("snow")
              || biome.contains("frozen")
              || biome.contains("ice")
              || biome.contains("grove");
      case TSUNAMI -> biome.contains("ocean") && surface == Material.WATER;
      case FLOOD -> biome.contains("river") || biome.contains("swamp");
      case WILDFIRE ->
          !w.hasStorm()
              && (biome.contains("forest") || biome.contains("taiga") || biome.contains("savanna"));
      case VOLCANO ->
          plugin.settings().file("worlds").getStringList("volcano-sources").stream()
              .anyMatch(s -> nearSource(s, l));
      case TORNADO -> surface != Material.WATER && !biome.contains("ocean");
      default -> surface != Material.WATER;
    };
  }

  private boolean nearSource(String s, Location l) {
    try {
      String[] a = s.split(",");
      return a.length == 4
          && a[0].equals(l.getWorld().getName())
          && l.distanceSquared(
                  new Location(
                      l.getWorld(),
                      Double.parseDouble(a[1]),
                      Double.parseDouble(a[2]),
                      Double.parseDouble(a[3])))
              < 4096;
    } catch (RuntimeException ignored) {
      return false;
    }
  }

  public Disaster random(Location loc) {
    List<DisasterType> types = new ArrayList<>(Arrays.asList(DisasterType.values()));
    Collections.shuffle(types);
    for (var t : types) if (eligible(t, loc)) return start(t, loc, false, false);
    throw new IllegalArgumentException(
        "No biome-appropriate disaster is eligible at this location");
  }

  private Location volcanoSource(Location nearby) {
    for (String source : plugin.settings().file("worlds").getStringList("volcano-sources"))
      try {
        String[] a = source.split(",");
        if (a.length != 4 || !a[0].equals(nearby.getWorld().getName())) continue;
        Location vent =
            new Location(
                nearby.getWorld(),
                Double.parseDouble(a[1]),
                Double.parseDouble(a[2]),
                Double.parseDouble(a[3]));
        if (vent.distanceSquared(nearby) <= 4096
            && vent.getWorld().isChunkLoaded(vent.getBlockX() >> 4, vent.getBlockZ() >> 4))
          return vent;
      } catch (IllegalArgumentException ignored) {
      }
    return null;
  }

  public void natural() {
    if (!plugin.getConfig().getBoolean("automatic-disasters", false)
        || Bukkit.getTPS()[0] < 18
        || System.currentTimeMillis() - lastNatural
            < plugin.getConfig().getLong("global-cooldown", 300) * 1000) return;
    long now = System.currentTimeMillis();
    var cfg = plugin.settings().file("worlds");
    for (World w : Bukkit.getWorlds()) {
      if (!worldAllowed(w)
          || w.getPlayers().isEmpty()
          || now < nextNatural.getOrDefault(w.getUID(), 0L)) continue;
      nextNatural.put(
          w.getUID(),
          now
              + Math.max(
                      10,
                      cfg.getInt(
                          "worlds." + w.getName() + ".frequency-seconds",
                          cfg.getInt("default-frequency-seconds", 180)))
                  * 1000L);
      Player p = w.getPlayers().get(new Random().nextInt(w.getPlayers().size()));
      int x = p.getLocation().getBlockX() + new Random().nextInt(65) - 32,
          z = p.getLocation().getBlockZ() + new Random().nextInt(65) - 32;
      if (!w.isChunkLoaded(x >> 4, z >> 4)) continue;
      Location at = new Location(w, x, w.getHighestBlockYAt(x, z) + 1, z);
      for (DisasterType t : DisasterType.values()) {
        Location target = t == DisasterType.VOLCANO ? volcanoSource(at) : at;
        if (target != null
            && eligible(t, target)
            && Math.random() < plugin.settings().number(t, "natural-spawn-chance", .12)) {
          try {
            Disaster d = start(t, target, false, false);
            d.intensity(
                cfg.getInt(
                    "worlds." + w.getName() + ".difficulty", cfg.getInt("default-difficulty", 2)));
            lastNatural = now;
          } catch (IllegalArgumentException ignored) {
          }
          return;
        }
      }
    }
  }
}
