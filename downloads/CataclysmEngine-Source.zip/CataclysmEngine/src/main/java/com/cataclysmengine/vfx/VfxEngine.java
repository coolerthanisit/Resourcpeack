package com.cataclysmengine.vfx;

import com.cataclysmengine.CataclysmEnginePlugin;
import com.cataclysmengine.disaster.Disaster;
import java.util.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.Transformation;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/** A single main-thread, distance-aware rendering budget for all events. */
public final class VfxEngine {
  private final CataclysmEnginePlugin plugin;
  private final NamespacedKey ownerKey, qualityKey;
  private final Map<UUID, Set<ItemDisplay>> displays = new HashMap<>();
  private final Map<UUID, Integer> eventParticles = new HashMap<>();
  private int renderTick;
  private int emissions;
  private double degradation = 1;

  public VfxEngine(CataclysmEnginePlugin p) {
    plugin = p;
    ownerKey = new NamespacedKey(p, "owner");
    qualityKey = new NamespacedKey(p, "quality");
  }

  public void beginTick() {
    emissions = 0;
    eventParticles.clear();
    double tps = Bukkit.getTPS()[0];
    degradation = tps < 15 ? .25 : tps < 18 ? .55 : 1;
    displays.values().forEach(s -> s.removeIf(e -> !e.isValid()));
    if (++renderTick % 20 == 0)
      for (Set<ItemDisplay> group : displays.values())
        for (ItemDisplay e : group)
          for (Player p : e.getWorld().getPlayers()) {
            var model = e.getItemStack().getItemMeta().getItemModel();
            boolean minor = model != null && minor(model.getKey());
            boolean hide =
                minor
                    && (quality(p) < .3
                        || (quality(p) < .7
                            && p.getLocation().distanceSquared(e.getLocation()) > 4096));
            if (hide) p.hideEntity(plugin, e);
            else p.showEntity(plugin, e);
          }
  }

  public void stale(org.bukkit.Chunk c) {
    for (Entity e : c.getEntities())
      if (e.getPersistentDataContainer().has(ownerKey, PersistentDataType.STRING)) {
        String id = e.getPersistentDataContainer().get(ownerKey, PersistentDataType.STRING);
        boolean live = false;
        try {
          live = plugin.manager() != null && plugin.manager().get(UUID.fromString(id)) != null;
        } catch (IllegalArgumentException ignored) {
        }
        if (!live) e.remove();
      }
  }

  private boolean loaded(Location l) {
    return l.getWorld() != null
        && l.getY() >= l.getWorld().getMinHeight()
        && l.getY() < l.getWorld().getMaxHeight()
        && l.getWorld().isChunkLoaded(l.getBlockX() >> 4, l.getBlockZ() >> 4);
  }

  private boolean minor(String key) {
    return key.contains("fragment") || key.contains("debris") || key.equals("magma_bomb");
  }

  public ItemDisplay model(UUID owner, Location at, String key, float scale, boolean glow) {
    if (!loaded(at) || count() >= plugin.getConfig().getInt("limits.max-display-entities", 220))
      return null;
    if (minor(key)) {
      long fragments =
          displays.values().stream()
              .flatMap(Set::stream)
              .filter(
                  e ->
                      e.isValid()
                          && e.getItemStack().getItemMeta().getItemModel() != null
                          && minor(e.getItemStack().getItemMeta().getItemModel().getKey()))
              .count();
      if (fragments >= plugin.getConfig().getInt("limits.max-fragments", 32)) return null;
    }
    Disaster d = plugin.manager() == null ? null : plugin.manager().get(owner);
    if (d != null
        && (!d.option("visuals", true)
            || displays.getOrDefault(owner, Set.of()).size() >= d.value("maximum-displays", 48)))
      return null;

    ItemDisplay e =
        at.getWorld()
            .spawn(
                at,
                ItemDisplay.class,
                x -> {
                  x.setPersistent(false);
                  x.setInvulnerable(true);
                  x.setGravity(false);
                  x.setSilent(true);
                  x.getPersistentDataContainer()
                      .set(ownerKey, PersistentDataType.STRING, owner.toString());
                  x.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.NONE);
                  ItemStack item = new ItemStack(Material.PAPER);
                  var m = item.getItemMeta();
                  m.setItemModel(new NamespacedKey("cataclysm", key));
                  item.setItemMeta(m);
                  x.setItemStack(item);
                  x.setInterpolationDuration(3);
                  x.setTeleportDuration(3);
                  x.setViewRange((float) (range() / 64));
                  x.setDisplayWidth(Math.max(4, scale * 2));
                  x.setDisplayHeight(Math.max(4, scale * 2));
                  if (glow) x.setBrightness(new Display.Brightness(15, 15));
                });
    displays.computeIfAbsent(owner, k -> new HashSet<>()).add(e);
    pose(e, at, scale, 0, 0);
    return e;
  }

  public void pose(ItemDisplay e, Location at, float scale, float yaw, float pitch) {
    if (e == null || !e.isValid() || !loaded(at)) return;
    e.teleport(at);
    e.setInterpolationDelay(0);
    e.setTransformation(
        new Transformation(
            new Vector3f(),
            new Quaternionf().rotateY(yaw).rotateX(pitch),
            new Vector3f(Math.max(.001f, scale)),
            new Quaternionf()));
  }

  public double range() {
    return plugin.settings().file("visuals").getDouble("max-range", 160);
  }

  private double quality(Player p) {
    String q = p.getPersistentDataContainer().get(qualityKey, PersistentDataType.STRING);
    if (q == null) q = plugin.settings().file("visuals").getString("quality", "HIGH");
    return switch (q.toUpperCase(Locale.ROOT)) {
      case "LOW" -> .25;
      case "MEDIUM" -> .55;
      default -> 1;
    };
  }

  public void particle(Disaster d, Particle particle, Location at, int count, double spread) {
    emit(d, particle, at, count, spread, null);
  }

  public void dust(Disaster d, Location at, Color color, float size, int count, double spread) {
    emit(
        d,
        Particle.DUST,
        at,
        count,
        spread,
        new Particle.DustOptions(color, Math.clamp(size, .01f, 4)));
  }

  private <T> void emit(Disaster d, Particle kind, Location at, int count, double spread, T data) {
    if (!d.option("visuals", true) || !loaded(at) || count <= 0) return;
    int interval = Math.clamp(plugin.getConfig().getInt("simulation-interval", 2), 1, 20);
    if (d.age() % interval != 0) return;
    String layer =
        switch (kind) {
          case DUST -> "dust";
          case SMOKE, LARGE_SMOKE, CAMPFIRE_COSY_SMOKE -> "smoke";
          case FLAME, SMALL_FLAME -> "flame";
          case SPLASH, DRIPPING_WATER, FALLING_WATER -> "water";
          case SNOWFLAKE -> "snow";
          default -> "other";
        };
    if (!plugin.settings().file("visuals").getBoolean("particle-layers." + layer, true)) return;
    int cap = plugin.getConfig().getInt("limits.max-particles-per-tick", 3500);
    int eventCap = (int) d.value("maximum-particles", 900);
    double max = range();
    for (Player p : at.getWorld().getPlayers()) {
      double dist = p.getLocation().distanceSquared(at);
      if (dist > max * max) continue;
      int remaining = Math.min(cap - emissions, eventCap - eventParticles.getOrDefault(d.id(), 0));
      int n =
          Math.min(
              remaining,
              (int)
                  Math.ceil(
                      count * quality(p) * degradation * Math.max(.12, 1 - Math.sqrt(dist) / max)));
      if (n <= 0) break;
      p.spawnParticle(kind, at, n, spread, spread, spread, 0, data);
      emissions += n;
      eventParticles.merge(d.id(), n, Integer::sum);
    }
  }

  public void sound(Disaster d, Location at, String key, float volume, float pitch) {
    var cfg = plugin.settings().file("sounds");
    if (!d.option("sounds", true)
        || !cfg.getBoolean("enabled", true)
        || !cfg.getBoolean("layers." + key, true)) return;
    double range = cfg.getDouble("range", 160);
    for (Player p : at.getWorld().getPlayers()) {
      double distance = p.getLocation().distance(at);
      if (distance < range)
        p.playSound(
            at,
            "cataclysm:" + key,
            SoundCategory.WEATHER,
            (float) (volume * cfg.getDouble("volume", .8) * (1 - distance / range)),
            Math.clamp(pitch, .5f, 2));
    }
  }

  public int count() {
    return displays.values().stream().mapToInt(Set::size).sum();
  }

  public void remove(Entity e) {
    if (e != null) e.remove();
  }

  public void cleanup(UUID owner) {
    var set = displays.remove(owner);
    if (set != null) set.forEach(Entity::remove);
    Disaster d = plugin.manager().get(owner);
    var layers = plugin.settings().file("sounds").getConfigurationSection("layers");
    if (d != null && layers != null)
      for (Player p : d.origin().getWorld().getPlayers())
        for (String k : layers.getKeys(false)) p.stopSound("cataclysm:" + k, SoundCategory.WEATHER);
  }

  public void shutdown() {
    new ArrayList<>(displays.keySet()).forEach(this::cleanup);
  }

  public Map<String, Object> stats() {
    return Map.of(
        "displays",
        count(),
        "particle-packets-this-tick",
        emissions,
        "detail-factor",
        degradation,
        "tps",
        Bukkit.getTPS()[0]);
  }
}
