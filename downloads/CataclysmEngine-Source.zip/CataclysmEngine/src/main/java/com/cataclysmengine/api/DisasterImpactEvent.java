package com.cataclysmengine.api;

import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.event.HandlerList;

public final class DisasterImpactEvent extends CataclysmEvent {
  private static final HandlerList HANDLERS = new HandlerList();
  private final Location location;

  public DisasterImpactEvent(UUID id, Location location) {
    super(id);
    this.location = location.clone();
  }

  public Location getLocation() {
    return location.clone();
  }

  public HandlerList getHandlers() {
    return HANDLERS;
  }

  public static HandlerList getHandlerList() {
    return HANDLERS;
  }
}
