package com.cataclysmengine.disaster.tornado;

import com.cataclysmengine.disaster.*;
import com.cataclysmengine.disaster.environment.EnvironmentBehavior;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.util.Vector;

/** A travelling, widening, multi-layer funnel with an independently rotating debris field. */
public final class TornadoBehavior extends EnvironmentBehavior {
  private Location center;

  @Override
  public void tick(Disaster d) {
    if (d.phase() == Phase.AFTERMATH && !d.option("aftermath", true)) {
      hideAll(d);
      return;
    }
    if (d.age() % 2 != 0) return;
    Location wanted = movingCenter(d);
    // Slowly varying heading bends the track rather than moving through random teleports.
    wanted.add(
        Math.sin(d.age() * .002) * d.radius() * .15,
        0,
        Math.cos(d.age() * .002) * d.radius() * .15);
    Location floor = surface(wanted);
    if (floor == null) return;
    center = floor;
    double s = d.strength(),
        height = (22 + d.intensity() * 7) * Math.max(.03, s),
        width = (2 + d.intensity() * 1.5) * s;
    sound(d, center, "tornado_wind", .3 + s * 1.3, .8 + d.intensity() * .04);
    if (d.phase() == Phase.AFTERMATH) {
      hideAll(d);
      particle(d, Particle.CLOUD, center, 4, 3);
      return;
    }
    // Cloud bank remains aloft while the funnel grows downward during formation.
    for (int i = 0; i < 7; i++) {
      double a = i * Math.PI * 2 / 7 + d.age() * .009, r = 6 + width * 1.3;
      Location p = center.clone().add(Math.cos(a) * r, 22 + d.intensity() * 7, Math.sin(a) * r);
      model(d, "cloud" + i, "cloud", p, (4 + s * 5) * s, a, 0, false);
    }
    if (d.phase() == Phase.WARNING) return;
    int levels = 14 + d.intensity() * 3;
    for (int i = 0; i < levels; i++) {
      double t = (double) i / levels,
          y = height * t,
          r =
              com.cataclysmengine.disaster.environment.StormMath.funnelRadius(t, d.intensity(), s)
                  * (1 + .09 * Math.sin(d.age() * .07 + i));
      for (int layer = 0; layer < 2; layer++) {
        double a = d.age() * (layer == 0 ? .19 : .08) + i * .79;
        Location p = center.clone().add(Math.cos(a) * r, y, Math.sin(a) * r);
        dust(
            d,
            p,
            layer == 0 ? Color.fromRGB(83, 80, 75) : Color.fromRGB(123, 119, 111),
            1.5f,
            2,
            .32);
      }
    }
    for (int i = 0; i < 6 + d.intensity() * 2; i++) {
      double t = ((i * .17 + d.age() * .004) % 1), a = i * 2.4 + d.age() * .12;
      double r = .8 + width * t;
      Location p = center.clone().add(Math.cos(a) * r, t * height, Math.sin(a) * r);
      model(
          d,
          "debris" + i,
          i % 2 == 0 ? "wooden_debris" : "stone_debris",
          p,
          .25 + .12 * d.intensity(),
          a,
          a * .3,
          false);
    }
    for (int i = 0; i < 10; i++) {
      double a = d.age() * .15 + i * Math.PI / 5;
      dust(
          d,
          center.clone().add(Math.cos(a) * width, .3, Math.sin(a) * width),
          Color.fromRGB(125, 106, 81),
          1.8f,
          2,
          .6);
    }
    if (hazardous(d) && d.age() % 4 == 0) {
      for (LivingEntity e : living(center, Math.min(d.radius(), width + 8))) {
        Vector offset = center.toVector().subtract(e.getLocation().toVector());
        double distance = Math.max(1, Math.hypot(offset.getX(), offset.getZ()));
        Vector pull =
            new Vector(offset.getX() / distance, 0, offset.getZ() / distance)
                .multiply(.05 + d.intensity() * .025);
        pull.add(
            new Vector(
                    -offset.getZ() / distance, .08 + d.intensity() * .025, offset.getX() / distance)
                .multiply(.7));
        d.force(e, pull);
        if (d.age() % 20 == 0 && distance < width * .7) d.damage(e, d.intensity() * .4);
      }
      // Loose dropped items follow the same capped vortex, without modifying their inventory data.
      int loose = 0;
      for (Entity e : center.getWorld().getNearbyEntities(center, width + 5, height, width + 5))
        if (e instanceof Item && d.plugin().protection().allowed(e.getLocation())) {
          if (loose++ >= 32) break;
          Vector v = center.toVector().subtract(e.getLocation().toVector());
          v.setY(0);
          if (v.lengthSquared() > 1) v.normalize().multiply(.12);
          v.add(new Vector(-v.getZ(), .12, v.getX()));
          e.setVelocity(v);
        }
      if (d.age() % 10 == 0)
        for (int i = 0; i < 4; i++) {
          Location p =
              surface(
                  center
                      .clone()
                      .add(random.nextDouble(-width, width), 0, random.nextDouble(-width, width)));
          if (p == null) continue;
          for (int y = 0; y < 5; y++) {
            Location at = p.clone().add(0, y, 0);
            if (!loaded(at)) continue;
            Material m = at.getBlock().getType();
            boolean leaf = Tag.LEAVES.isTagged(m) && d.option("affect-leaves", true);
            boolean weak =
                d.option("weak-blocks", false)
                    && (Tag.FLOWERS.isTagged(m)
                        || m == Material.SHORT_GRASS
                        || m == Material.TALL_GRASS);
            if (leaf || weak) edit(d, at, Material.AIR, leaf ? "leaves" : "vegetation");
          }
        }
    }
  }
}
