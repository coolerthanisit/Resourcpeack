package com.cataclysmengine.terrain;

/** VISUAL_ONLY is the safe default. CUSTOM effects must be explicitly allowed in protection.yml. */
public enum DestructionMode {
  VISUAL_ONLY,
  TEMPORARY,
  PERMANENT,
  CUSTOM;

  public static DestructionMode parse(String value) {
    if (value == null) return VISUAL_ONLY;
    try {
      return valueOf(value.toUpperCase(java.util.Locale.ROOT).replace('-', '_'));
    } catch (IllegalArgumentException ex) {
      return VISUAL_ONLY;
    }
  }
}
