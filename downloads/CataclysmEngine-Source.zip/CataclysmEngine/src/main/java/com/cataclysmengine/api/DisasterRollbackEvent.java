package com.cataclysmengine.api;

import java.util.UUID;
import org.bukkit.event.HandlerList;

public final class DisasterRollbackEvent extends CataclysmEvent {
  private static final HandlerList HANDLERS = new HandlerList();

  public DisasterRollbackEvent(UUID id) {
    super(id);
  }

  public HandlerList getHandlers() {
    return HANDLERS;
  }

  public static HandlerList getHandlerList() {
    return HANDLERS;
  }
}
