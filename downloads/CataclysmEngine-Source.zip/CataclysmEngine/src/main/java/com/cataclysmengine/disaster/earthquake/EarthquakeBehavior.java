package com.cataclysmengine.disaster.earthquake;

import com.cataclysmengine.disaster.*;
import com.cataclysmengine.disaster.environment.EnvironmentBehavior;
import java.util.*;
import org.bukkit.*;
import org.bukkit.entity.LivingEntity;
import org.bukkit.util.Vector;

/** Branching, seeded fault paths, localized roof debris and finite timed aftershocks. */
public final class EarthquakeBehavior extends EnvironmentBehavior {
  private final List<Vector> faults = new ArrayList<>();
  private boolean prepared;
  private int edited, aftershockUntil = -1, aftershocks;

  private void prepare(Disaster d) {
    for (var point :
        com.cataclysmengine.disaster.environment.StormMath.faults(
            d.id().getMostSignificantBits(), d.radius()))
      faults.add(new Vector(point.x(), point.depth(), point.z()));
    prepared = true;
  }

  @Override
  public void tick(Disaster d) {
    if (d.phase() == Phase.AFTERMATH && !d.option("aftermath", true)) {
      hideAll(d);
      return;
    }
    if (!prepared) prepare(d);
    if (d.age() % 3 != 0) return;
    boolean after = d.phase() == Phase.AFTERMATH;
    if (after
        && d.phaseAge() % 40 <= 2
        && aftershocks < 3
        && random.nextDouble() < d.value("aftershock-chance", .45)) {
      aftershockUntil = d.age() + random.nextInt(18, 42);
      aftershocks++;
      d.vfx().sound(d, d.origin(), "rock_crack", .5f, (float) random.nextDouble(.7, 1.1));
    }
    double strength = after ? (d.age() < aftershockUntil ? .3 : 0) : d.strength();
    sound(
        d,
        d.origin(),
        after ? "rock_crack" : "earthquake_rumble",
        .2 + strength,
        .65 + .05 * d.intensity());
    if (strength == 0) return;
    int count = Math.max(3, (int) (faults.size() * Math.min(1, strength + .1)));
    for (int i = 0; i < count; i += 2) {
      Vector v = faults.get(i);
      Location p = groundAt(d, v.getX(), v.getZ());
      if (p == null) continue;
      dust(d, p, Color.fromRGB(113, 91, 72), 1.2f, 2, .3 + strength);
      if (i % 6 == 0 && visible(d))
        model(
            d,
            "fault" + i,
            "scorched_rock",
            p.clone().add(0, -.15, 0),
            .22 + strength * .25,
            i,
            .07,
            false);
    }
    if (d.phase() == Phase.DISSIPATION) {
      for (int i = 0; i < faults.size(); i += 6) {
        var e = displays.get("fault" + i);
        if (e != null) d.vfx().pose(e, e.getLocation(), (float) (.1 + .35 * strength), i, 0);
      }
    }
    if ((hazardous(d) || after && strength > 0 && !d.preview()) && d.age() % 6 == 0) {
      for (LivingEntity entity : living(d.origin(), d.radius())) {
        d.force(
            entity,
            new Vector(
                random.nextDouble(-.055, .055) * d.intensity(),
                .04 + strength * .05,
                random.nextDouble(-.055, .055) * d.intensity()));
        if (d.age() % 30 == 0 && entity.isOnGround())
          d.damage(entity, .3 * d.intensity() * strength);
        // A handful of inspected blocks above the entity creates falling ceiling dust without
        // loading chunks.
        Location eye = entity.getEyeLocation();
        for (int y = 1; y < 8; y++) {
          Location roof = eye.clone().add(0, y, 0);
          if (!loaded(roof)) break;
          if (roof.getBlock().getType().isSolid()) {
            dust(d, roof.clone().add(0, -.5, 0), Color.fromRGB(134, 123, 105), .7f, 5, .6);
            if (hazardous(d) && d.option("cave-ins", false) && d.age() % 30 == 0) {
              Material m = roof.getBlock().getType();
              if (m == Material.STONE || m == Material.DEEPSLATE || m == Material.TUFF)
                edit(d, roof, Material.AIR, "cave-ins");
            }
            break;
          }
        }
      }
      if (hazardous(d) && d.option("cracks", true))
        for (int budget = 0; budget < 4 && edited < faults.size(); budget++, edited++) {
          Vector v = faults.get(edited);
          Location p = groundAt(d, v.getX(), v.getZ());
          if (p == null) continue;
          int depth = Math.min((int) v.getY(), (int) d.value("max-depth", 3));
          for (int y = 1; y <= depth; y++)
            edit(d, p.clone().subtract(0, y, 0), Material.AIR, "cracks");
        }
    }
  }
}
