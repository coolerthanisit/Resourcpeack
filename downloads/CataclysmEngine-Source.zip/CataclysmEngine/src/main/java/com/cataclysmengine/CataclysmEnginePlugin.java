package com.cataclysmengine;

import com.cataclysmengine.api.*;
import com.cataclysmengine.command.DisasterCommand;
import com.cataclysmengine.config.Settings;
import com.cataclysmengine.disaster.*;
import com.cataclysmengine.disaster.blizzard.BlizzardBehavior;
import com.cataclysmengine.disaster.earthquake.EarthquakeBehavior;
import com.cataclysmengine.disaster.flood.FloodBehavior;
import com.cataclysmengine.disaster.meteor.MeteorBehavior;
import com.cataclysmengine.disaster.sandstorm.SandstormBehavior;
import com.cataclysmengine.disaster.supercell.SupercellBehavior;
import com.cataclysmengine.disaster.tornado.TornadoBehavior;
import com.cataclysmengine.disaster.tsunami.TsunamiBehavior;
import com.cataclysmengine.disaster.volcano.VolcanoBehavior;
import com.cataclysmengine.disaster.wildfire.WildfireBehavior;
import com.cataclysmengine.gui.AdminGui;
import com.cataclysmengine.protection.ProtectionService;
import com.cataclysmengine.resourcepack.PackService;
import com.cataclysmengine.terrain.TerrainService;
import com.cataclysmengine.vfx.VfxEngine;
import java.time.Duration;
import java.util.*;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.world.*;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

public final class CataclysmEnginePlugin extends JavaPlugin implements Listener {
  private Settings settings;
  private ProtectionService protection;
  private TerrainService terrain;
  private VfxEngine vfx;
  private PackService pack;
  private DisasterManager manager;
  private final Map<UUID, Integer> fallImmunity = new HashMap<>();
  private final Set<UUID> cancelledWarnings = new HashSet<>();
  private final Map<UUID, BossBar> bars = new HashMap<>();
  private final Map<UUID, Set<UUID>> viewers = new HashMap<>();

  public Settings settings() {
    return settings;
  }

  public ProtectionService protection() {
    return protection;
  }

  public TerrainService terrain() {
    return terrain;
  }

  public VfxEngine vfx() {
    return vfx;
  }

  public PackService pack() {
    return pack;
  }

  public DisasterManager manager() {
    return manager;
  }

  @Override
  public void onEnable() {
    saveDefaultConfig();
    settings = new Settings(this);
    protection = new ProtectionService(this);
    terrain = new TerrainService(this, protection);
    vfx = new VfxEngine(this);
    manager = new DisasterManager(this);
    pack = new PackService(this);
    var gui = new AdminGui(this);
    var command = new DisasterCommand(this, gui);
    Objects.requireNonNull(getCommand("disaster")).setExecutor(command);
    getCommand("disaster").setTabCompleter(command);
    getServer().getPluginManager().registerEvents(this, this);
    getServer().getPluginManager().registerEvents(gui, this);
    getServer().getPluginManager().registerEvents(pack, this);
    for (World w : Bukkit.getWorlds()) for (Chunk c : w.getLoadedChunks()) vfx.stale(c);
    // Actual elapsed server ticks drive all timelines. Simulation interval only degrades minor VFX
    // within the render budget.
    getServer()
        .getScheduler()
        .runTaskTimer(
            this,
            () -> {
              if (Bukkit.getCurrentTick() % 20 == 0)
                fallImmunity.values().removeIf(expiry -> expiry < Bukkit.getCurrentTick());
              vfx.beginTick();
              terrain.tick();
              manager.tick();
            },
            1,
            1);
    getServer().getScheduler().runTaskTimer(this, manager::natural, 200, 200);
    getLogger()
        .info(
            "CataclysmEngine enabled: Paper 1.21.11 / Java 25; destruction defaults to"
                + " VISUAL_ONLY.");
  }

  @Override
  public void onDisable() {
    if (manager != null) manager.stopAll();
    if (vfx != null) vfx.shutdown();
    if (terrain != null) terrain.shutdown();
    getServer().getScheduler().cancelTasks(this);
  }

  public void reloadSettings() {
    manager.stopAll();
    settings.reload();
    protection.reload();
    terrain.reload();
  }

  public DisasterBehavior createBehavior(DisasterType type) {
    return switch (type) {
      case METEOR -> new MeteorBehavior();
      case TORNADO -> new TornadoBehavior();
      case EARTHQUAKE -> new EarthquakeBehavior();
      case TSUNAMI -> new TsunamiBehavior();
      case VOLCANO -> new VolcanoBehavior();
      case BLIZZARD -> new BlizzardBehavior();
      case SANDSTORM -> new SandstormBehavior();
      case WILDFIRE -> new WildfireBehavior();
      case SUPERCELL -> new SupercellBehavior();
      case FLOOD -> new FloodBehavior();
    };
  }

  public void damage(Disaster d, LivingEntity e, double amount) {
    if (d.preview()
        || !d.option("damage", false)
        || !eligible(e)
        || !protection.allowed(e.getLocation())) return;
    var event = new DisasterDamageEvent(d.id(), e, Math.clamp(amount, 0, 20));
    Bukkit.getPluginManager().callEvent(event);
    if (!event.isCancelled()) e.damage(event.getDamage());
  }

  public void force(Disaster d, LivingEntity e, Vector delta) {
    if (d.preview()
        || !d.option("forces", true)
        || !eligible(e)
        || !protection.allowed(e.getLocation())) return;
    if (!Double.isFinite(delta.getX())
        || !Double.isFinite(delta.getY())
        || !Double.isFinite(delta.getZ())) return;
    Vector v = e.getVelocity().add(delta);
    if (v.lengthSquared() > 2.25) v.normalize().multiply(1.5);
    v.setY(Math.clamp(v.getY(), -.6, .65));
    if (!d.option("damage", false))
      fallImmunity.put(e.getUniqueId(), Bukkit.getCurrentTick() + 200);
    e.setVelocity(v);
  }

  private boolean eligible(LivingEntity e) {
    return !(e instanceof ArmorStand)
        && (!(e instanceof Player p)
            || (p.getGameMode() != GameMode.CREATIVE && p.getGameMode() != GameMode.SPECTATOR));
  }

  public void warn(Disaster d, boolean first) {
    if (d.phase() != Phase.WARNING) {
      hideWarning(d.id());
      return;
    }
    if (cancelledWarnings.contains(d.id())) return;
    if (first) {
      var ev = new DisasterWarningEvent(d.id(), d);
      Bukkit.getPluginManager().callEvent(ev);
      if (ev.isCancelled()) {
        cancelledWarnings.add(d.id());
        return;
      }
    }
    var cfg = settings.file("messages");
    var mm = MiniMessage.miniMessage();
    String color = cfg.getString(d.type().key() + ".color", "#ff7524");
    int seconds = (int) Math.ceil((1 - d.progress()) * d.value("warning-duration", 15));
    String action =
        cfg.getString("warning-actionbar", "<gold>{type} • {seconds}s")
            .replace("{type}", d.type().title)
            .replace("{seconds}", "" + seconds)
            .replace("{color}", color);
    BossBar bar =
        bars.computeIfAbsent(
            d.id(),
            id ->
                BossBar.bossBar(
                    mm.deserialize(action), 1, BossBar.Color.RED, BossBar.Overlay.PROGRESS));
    bar.name(mm.deserialize(action));
    bar.progress((float) (1 - d.progress()));
    if (first) vfx.sound(d, d.origin(), "warning", .6f, 1);
    Set<UUID> visible = viewers.computeIfAbsent(d.id(), k -> new HashSet<>());
    for (Player p : Bukkit.getOnlinePlayers()) {
      boolean near =
          p.getWorld().equals(d.origin().getWorld())
              && p.getLocation().distanceSquared(d.origin())
                  <= Math.pow(Math.max(64, d.radius() * 3), 2);
      if (!near) {
        if (visible.remove(p.getUniqueId())) p.hideBossBar(bar);
        continue;
      }
      boolean joined = visible.add(p.getUniqueId());
      if (joined && cfg.getBoolean("bossbars", true)) p.showBossBar(bar);
      p.sendActionBar(mm.deserialize(action));
      if (first || joined) {
        p.showTitle(
            Title.title(
                mm.deserialize(cfg.getString(d.type().key() + ".title", "<gold>DISASTER WARNING")),
                mm.deserialize(cfg.getString(d.type().key() + ".subtitle", "<gray>Seek shelter")),
                Title.Times.times(
                    Duration.ofMillis(500), Duration.ofSeconds(4), Duration.ofSeconds(1))));
      }
    }
  }

  public void hideWarning(UUID id) {
    cancelledWarnings.remove(id);
    BossBar b = bars.remove(id);
    viewers.remove(id);
    if (b != null) for (Player p : Bukkit.getOnlinePlayers()) p.hideBossBar(b);
  }

  @EventHandler
  public void chunkLoad(ChunkLoadEvent e) {
    vfx.stale(e.getChunk());
  }

  @EventHandler
  public void worldUnload(WorldUnloadEvent e) {
    for (Disaster d : manager.active())
      if (d.origin().getWorld().equals(e.getWorld())) manager.stop(d.id());
  }

  @EventHandler
  public void chunkUnload(ChunkUnloadEvent e) {
    for (Disaster d : manager.active())
      if (d.origin().getWorld().equals(e.getWorld())
          && (d.origin().getBlockX() >> 4) == e.getChunk().getX()
          && (d.origin().getBlockZ() >> 4) == e.getChunk().getZ()) manager.stop(d.id());
  }

  @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
  public void fall(org.bukkit.event.entity.EntityDamageEvent event) {
    if (event.getCause() == org.bukkit.event.entity.EntityDamageEvent.DamageCause.FALL
        && fallImmunity.getOrDefault(event.getEntity().getUniqueId(), 0) > Bukkit.getCurrentTick())
      event.setCancelled(true);
  }

  @EventHandler
  public void quit(org.bukkit.event.player.PlayerQuitEvent event) {
    protection.forgetSelection(event.getPlayer().getUniqueId());
    viewers.values().forEach(set -> set.remove(event.getPlayer().getUniqueId()));
    fallImmunity.remove(event.getPlayer().getUniqueId());
  }
}
