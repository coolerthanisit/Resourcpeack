package com.cataclysmengine.rollback;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Append-only, force-synced write-ahead data. An incomplete final line is never replayed. */
public final class TerrainJournal {
  private TerrainJournal() {}

  public static void append(Path file, String line) throws IOException {
    Files.createDirectories(file.getParent());
    boolean created = !Files.exists(file);
    byte[] bytes = (line + "\n").getBytes(StandardCharsets.UTF_8);
    try (FileChannel channel =
        FileChannel.open(
            file, StandardOpenOption.CREATE, StandardOpenOption.WRITE, StandardOpenOption.APPEND)) {
      ByteBuffer buffer = ByteBuffer.wrap(bytes);
      while (buffer.hasRemaining()) channel.write(buffer);
      channel.force(true);
    }
    if (created)
      try (FileChannel directory = FileChannel.open(file.getParent(), StandardOpenOption.READ)) {
        directory.force(true);
      }
  }

  public static List<String> read(Path file) throws IOException {
    String data = Files.readString(file, StandardCharsets.UTF_8);
    int last = data.lastIndexOf('\n');
    if (last < 0) return List.of();
    return data.substring(0, last).lines().toList();
  }

  /** Repair only an incomplete final record after a crash, retaining all complete records. */
  public static void repairTail(Path file) throws IOException {
    byte[] bytes = Files.readAllBytes(file);
    int end = bytes.length;
    while (end > 0 && bytes[end - 1] != '\n') end--;
    if (end != bytes.length)
      try (FileChannel channel = FileChannel.open(file, StandardOpenOption.WRITE)) {
        channel.truncate(end);
        channel.force(true);
      }
  }

  public static String encode(String value) {
    return Base64.getEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_8));
  }

  public static String decode(String value) {
    return new String(Base64.getDecoder().decode(value), StandardCharsets.UTF_8);
  }
}
