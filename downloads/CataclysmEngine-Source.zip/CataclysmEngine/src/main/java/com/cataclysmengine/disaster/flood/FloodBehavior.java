package com.cataclysmengine.disaster.flood;

import com.cataclysmengine.disaster.*;
import com.cataclysmengine.disaster.environment.EnvironmentBehavior;
import java.util.*;
import org.bukkit.*;
import org.bukkit.util.Vector;

/**
 * A bounded, elevation-ordered flood front. No native fluid is allowed to escape its recorded
 * cells.
 */
public final class FloodBehavior extends EnvironmentBehavior {
  private record Cell(int x, int y, int z) {}

  private final PriorityQueue<Cell> frontier =
      new PriorityQueue<>(Comparator.comparingInt(Cell::y));
  private final Set<Long> visited = new HashSet<>();
  private final List<Cell> wet = new ArrayList<>();
  private final List<Cell> known = new ArrayList<>();
  private int changed;
  private boolean initialized;

  private long key(int x, int z) {
    return ((long) x << 32) ^ (z & 0xffffffffL);
  }

  private void discover(Disaster d, int x, int z) {
    if (visited.size() >= Math.clamp((int) d.value("flooding.max-area", 256), 1, 2048)) return;
    if (!visited.add(key(x, z))) return;
    Location candidate =
        surface(new Location(d.origin().getWorld(), x + .5, d.origin().getY(), z + .5));
    if (candidate == null || !inside(d, candidate) || !d.plugin().protection().allowed(candidate))
      return;
    Cell cell = new Cell(x, candidate.getBlockY(), z);
    frontier.add(cell);
    known.add(cell);
  }

  @Override
  public void tick(Disaster d) {
    if (d.phase() == Phase.AFTERMATH && !d.option("aftermath", true)) {
      hideAll(d);
      return;
    }
    if (d.age() % 3 != 0) return;
    Location source = d.origin();
    double strength = d.strength();
    Vector direction = wind(d);
    sound(d, source, "flood_rush", .2 + strength, .85);
    if (d.phase() == Phase.WARNING) {
      particle(d, Particle.FALLING_WATER, source.clone().add(0, 5, 0), 8, 4);
      return;
    }
    if (!initialized) {
      discover(d, source.getBlockX(), source.getBlockZ());
      initialized = true;
    }
    int depth = (int) Math.clamp(d.value("flooding.max-depth", 3), 1, 8);
    double stage =
        com.cataclysmengine.disaster.environment.StormMath.floodFraction(
            d.phase().name(), d.progress());
    double level = source.getY() + stage * depth;
    for (int budget = 0;
        budget < 8 && !frontier.isEmpty() && d.phase() != Phase.AFTERMATH;
        budget++) {
      Cell first = frontier.peek();
      if (first.y > level) break;
      Cell cell = frontier.poll();
      wet.add(cell);
      discover(d, cell.x + 1, cell.z);
      discover(d, cell.x - 1, cell.z);
      discover(d, cell.x, cell.z + 1);
      discover(d, cell.x, cell.z - 1);
    }
    // Revisit a handful of cells as the level rises; this does not scan or fill an entire region in
    // one tick.
    int max = (int) Math.clamp(d.value("flooding.max-blocks", 384), 0, 4096);
    if (hazardous(d) && !wet.isEmpty())
      for (int i = 0; i < 10 && changed < max; i++) {
        Cell cell = wet.get(random.nextInt(wet.size()));
        for (int y = cell.y; y <= Math.floor(level) && y < cell.y + depth && changed < max; y++) {
          Location at = new Location(source.getWorld(), cell.x + .5, y, cell.z + .5);
          if (water(d, at, "water")) changed++;
        }
      }
    if (d.phase() == Phase.AFTERMATH) {
      hideAll(d);
      for (int i = 0; i < 3 && !known.isEmpty(); i++) {
        Cell c = known.get(random.nextInt(known.size()));
        particle(
            d, Particle.SPLASH, new Location(source.getWorld(), c.x + .5, c.y, c.z + .5), 2, .4);
      }
      return;
    }
    for (int i = 0; i < 12; i++) {
      if (wet.isEmpty()) break;
      Cell cell = wet.get((i * 17 + (d.age() / 12)) % wet.size());
      if (cell.y > level) {
        hide(d, "water" + i);
        hide(d, "debris" + i);
        continue;
      }
      double ripple = Math.sin(d.age() * .08 + i) * .12;
      Location water = new Location(source.getWorld(), cell.x + .5, level + ripple, cell.z + .5);
      model(
          d,
          "water" + i,
          "wave",
          water,
          .4 + stage * .5,
          Math.atan2(direction.getZ(), direction.getX()),
          0,
          false);
      if (i % 3 == 0)
        model(
            d,
            "debris" + i,
            "wooden_debris",
            water.clone().add(direction.clone().multiply(Math.sin(d.age() * .02 + i) * .6)),
            .3,
            d.age() * .01 + i,
            .04,
            false);
      particle(d, Particle.SPLASH, water, 2, .4);
      particle(d, Particle.FALLING_WATER, water.clone().add(0, 5, 0), 2, 1);
    }
    if (hazardous(d) && d.age() % 6 == 0)
      for (var entity : living(source, d.radius())) {
        if (entity.getY() > level + .8) continue;
        d.force(entity, direction.clone().multiply(.08 + .02 * d.intensity()).setY(.06));
        particle(d, Particle.SPLASH, entity.getLocation(), 3, .6);
        if (d.age() % 30 == 0 && entity.getEyeLocation().getY() < level)
          d.damage(entity, .3 * d.intensity());
      }
  }
}
