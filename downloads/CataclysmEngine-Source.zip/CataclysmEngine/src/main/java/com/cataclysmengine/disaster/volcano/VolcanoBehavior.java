package com.cataclysmengine.disaster.volcano;

import com.cataclysmengine.disaster.*;
import com.cataclysmengine.disaster.environment.EnvironmentBehavior;
import java.util.*;
import org.bukkit.*;
import org.bukkit.util.Vector;

/** A selected vent, pressure plume, repeated ejections and finite downhill lava branches. */
public final class VolcanoBehavior extends EnvironmentBehavior {
  private static final class Bomb {
    Location at;
    Vector velocity;
    int age;
    final int slot;

    Bomb(Location l, Vector v, int s) {
      at = l;
      velocity = v;
      slot = s;
    }
  }

  private final List<Bomb> bombs = new ArrayList<>();
  private final List<Location> cooling = new ArrayList<>();
  private final List<Location> flow = new ArrayList<>();
  private int sequence, flowing;

  @Override
  public void tick(Disaster d) {
    if (d.phase() == Phase.AFTERMATH && !d.option("aftermath", true)) {
      hideAll(d);
      return;
    }
    if (d.age() % 2 != 0) return;
    Location vent = d.origin();
    double s = d.strength();
    sound(
        d,
        vent,
        d.phase() == Phase.ACTIVE ? "lava_bubble" : "volcano_pressure",
        .3 + s,
        .65 + s * .25);
    // Ring-shaped heat vents remain visually distinct from the tall ash column.
    for (int i = 0; i < 6; i++) {
      double a = i * Math.PI / 3 + d.age() * .02;
      particle(d, Particle.SMOKE, vent.clone().add(Math.cos(a) * 2, 1, Math.sin(a) * 2), 2, .4);
      if (visible(d))
        particle(d, Particle.LAVA, vent.clone().add(Math.cos(a), 1, Math.sin(a)), 1, .2);
    }
    if (d.phase() == Phase.WARNING) return;
    if (d.phase() == Phase.AFTERMATH) {
      for (int i = 0; i < cooling.size(); i++)
        model(d, "cooled" + i, "cooling_rock", cooling.get(i), .4, 0, 0, false);
      particle(d, Particle.SMOKE, vent, 3, 2);
      return;
    }
    double plumeHeight = (10 + 7 * d.intensity()) * s;
    for (int i = 0; i < 9; i++) {
      double t = i / 8.0, a = d.age() * .018 + i * 2.4;
      Location p =
          vent.clone().add(Math.cos(a) * (1 + t * 6), t * plumeHeight, Math.sin(a) * (1 + t * 6));
      particle(d, Particle.LARGE_SMOKE, p, 2, 1 + t * 2);
      if (i < 4) particle(d, Particle.FLAME, p, 3, .4 + t);
      if (i >= 5) model(d, "ash" + i, "cloud", p, (2 + t * 5) * s, a, 0, false);
    }
    for (int i = 0; i < 4; i++) {
      double a = i * Math.PI / 2;
      model(
          d,
          "fountain" + i,
          "lava_fragment",
          vent.clone().add(Math.cos(a) * s, 2 + s * 3, Math.sin(a) * s),
          .4 + s * .8,
          d.age() * .04,
          a,
          true);
    }
    int cap = (int) Math.clamp(d.value("max-bombs", 16), 0, 32);
    if (d.phase() == Phase.ACTIVE
        && d.age() % Math.max(8, (int) d.value("eruption-interval", 35)) <= 1
        && bombs.size() < cap) {
      d.vfx().sound(d, vent, "volcano_eruption", 1.3f, .8f);
      particle(d, Particle.EXPLOSION, vent, 2, 1);
      for (int i = 0; i < Math.min(3, cap - bombs.size()); i++) {
        double a = random.nextDouble() * Math.PI * 2, speed = random.nextDouble(.15, .35);
        bombs.add(
            new Bomb(
                vent.clone().add(0, 2, 0),
                new Vector(
                    Math.cos(a) * speed, .55 + random.nextDouble() * .3, Math.sin(a) * speed),
                sequence++));
      }
    }
    for (Iterator<Bomb> iter = bombs.iterator(); iter.hasNext(); ) {
      Bomb b = iter.next();
      b.age += 2;
      b.velocity.setY(b.velocity.getY() - .035 * 2).multiply(.995);
      Location next = b.at.clone().add(b.velocity.clone().multiply(2));
      if (!loaded(next) || !inside(d, next) || b.age > 160) {
        hide(d, "bomb" + b.slot);
        iter.remove();
        continue;
      }
      // Two substeps keep a fast ejectum from tunnelling through a one-block roof.
      Location mid = b.at.clone().add(b.velocity);
      if (mid.getBlock().getType().isSolid() || next.getBlock().getType().isSolid()) {
        Location hit = mid.getBlock().getType().isSolid() ? mid : next;
        particle(d, Particle.LAVA, hit, 8, .6);
        particle(d, Particle.SMOKE, hit, 5, .8);
        d.vfx().sound(d, hit, "debris", .5f, .8f);
        if (cooling.size() < 12) cooling.add(hit.clone().add(0, .4, 0));
        if (hazardous(d)) for (var entity : living(hit, 2)) d.damage(entity, d.intensity());
        hide(d, "bomb" + b.slot);
        iter.remove();
        continue;
      }
      b.at = next;
      model(
          d,
          "bomb" + b.slot,
          "magma_bomb",
          b.at,
          .35 + d.intensity() * .12,
          b.age * .1,
          b.age * .07,
          true);
      particle(d, Particle.FLAME, b.at, 3, .2);
      particle(d, Particle.SMOKE, b.at, 2, .3);
    }
    if (hazardous(d) && d.age() % 8 == 0) {
      if (flow.isEmpty()) {
        Location p = surface(vent);
        if (p != null) flow.add(p);
      }
      // Only a small number of branching, loaded surface cells are simulated per update.
      int limit = (int) Math.clamp(d.value("max-flow-cells", 96), 0, 512);
      for (int attempt = 0; attempt < 3 && flowing < limit && !flow.isEmpty(); attempt++) {
        Location head = flow.get(random.nextInt(flow.size()));
        Location best = null;
        for (int step = 0; step < 4; step++) {
          double a = step * Math.PI / 2;
          Location candidate =
              surface(head.clone().add(Math.round(Math.cos(a)), 0, Math.round(Math.sin(a))));
          if (candidate != null
              && candidate.getY() <= head.getY()
              && inside(d, candidate)
              && (best == null || candidate.getY() < best.getY())) best = candidate;
        }
        if (best == null) continue;
        model(
            d,
            "lavaflow" + (flowing % 12),
            "lava_fragment",
            best.clone().add(0, .1, 0),
            .5,
            0,
            0,
            true);
        particle(d, Particle.SMOKE, best, 2, .3);
        particle(d, Particle.LAVA, best, 2, .3);
        if (d.option("lava", false)) edit(d, best, Material.LAVA, "lava");
        if (flow.size() < limit) flow.add(best);
        flowing++;
      }
    }
  }
}
