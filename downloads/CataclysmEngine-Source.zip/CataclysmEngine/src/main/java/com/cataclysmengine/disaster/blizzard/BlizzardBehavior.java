package com.cataclysmengine.disaster.blizzard;

import com.cataclysmengine.disaster.*;
import com.cataclysmengine.disaster.environment.EnvironmentBehavior;
import org.bukkit.*;
import org.bukkit.block.data.type.Snow;
import org.bukkit.util.Vector;

/** Directional, player-local snow curtains, rotating ice grit and bounded snow accumulation. */
public final class BlizzardBehavior extends EnvironmentBehavior {
  @Override
  public void tick(Disaster d) {
    if (d.phase() == Phase.AFTERMATH && !d.option("aftermath", true)) {
      hideAll(d);
      return;
    }
    if (d.age() % 3 != 0) return;
    double strength = d.strength();
    Location center = movingCenter(d);
    Vector wind = wind(d);
    sound(d, center, "blizzard_wind", .25 + strength, .8 + strength * .2);
    if (d.phase() == Phase.AFTERMATH) {
      hideAll(d);
      particle(d, Particle.SNOWFLAKE, center, 4, 4);
      return;
    }
    // Curtains are advected along the same wind as the ice models; particles alone do not drive the
    // snow.
    for (var player : center.getWorld().getPlayers()) {
      if (player.getLocation().distanceSquared(center) > d.radius() * d.radius()) continue;
      Location eye = player.getEyeLocation();
      double local =
          1
              - Math.min(
                  .8,
                  Math.sqrt(player.getLocation().distanceSquared(center))
                      / Math.max(1, d.radius()));
      int flakes = Math.max(2, (int) (18 * strength * local));
      for (int i = 0; i < flakes; i++) {
        double phase = ((d.age() * .035 + i * .618) % 1),
            lateral = Math.sin(i * 7.31 + d.age() * .02) * 7;
        Location at =
            eye.clone()
                .add(wind.clone().multiply(phase * 12 - 6))
                .add(-wind.getZ() * lateral, 4 - phase * 7, wind.getX() * lateral);
        particle(d, Particle.SNOWFLAKE, at, 1, .25);
        if (i % 4 == 0) dust(d, at, Color.fromRGB(220, 239, 255), 1.3f, 1, .4);
      }
      if (hazardous(d)
          && d.age() % 20 == 0
          && d.option("freezing", true)
          && player.getGameMode() != GameMode.CREATIVE
          && player.getGameMode() != GameMode.SPECTATOR) {
        if (player.getLocation().getBlock().getLightFromSky() > 7
            && d.plugin().protection().allowed(player.getLocation())) {
          int next =
              Math.min(
                  player.getMaxFreezeTicks() - 1, player.getFreezeTicks() + 18 * d.intensity());
          player.setFreezeTicks(
              next); // Vanilla freezing damage is replaced by the protected/cancellable plugin
                     // damage path.
          if (d.option("damage", false) && next >= player.getMaxFreezeTicks() - 1)
            d.damage(player, .3 * d.intensity());
        }
      }
    }
    if (visible(d))
      for (int i = 0; i < 8; i++) {
        double phase = ((d.age() * .013 + i * .137) % 1), a = i * 2.4;
        Location p =
            center
                .clone()
                .add(
                    Math.cos(a) * d.radius() * .6,
                    2 + Math.sin(a) * 1.5,
                    Math.sin(a) * d.radius() * .6)
                .add(wind.clone().multiply((phase - .5) * 9));
        model(
            d,
            "ice" + i,
            "ice_fragment",
            p,
            .12 + strength * .3,
            d.age() * .04 + i,
            d.age() * .02,
            false);
      }
    if (hazardous(d) && d.option("accumulation", true) && d.age() % 12 == 0) {
      for (int i = 0; i < 4; i++) {
        Location at = sample(d, d.radius());
        if (at == null) continue;
        if (at.clone().subtract(0, 1, 0).getBlock().getType() == Material.SNOW)
          at.subtract(0, 1, 0);
        if (!loaded(at) || !at.clone().subtract(0, 1, 0).getBlock().getType().isSolid()) continue;
        if (at.getBlock().getType() == Material.SNOW) {
          Snow layers = (Snow) at.getBlock().getBlockData();
          int max = (int) Math.clamp(d.value("max-snow-layers", 3), 1, 8);
          if (layers.getLayers() < max) {
            layers.setLayers(layers.getLayers() + 1);
            if (d.option("block-damage", false))
              d.plugin().terrain().edit(d.id(), at.getBlock(), layers, d.mode(), "snow");
          }
        } else if (at.getBlock().getType().isAir()) edit(d, at, Material.SNOW, "snow");
      }
    }
  }
}
