package com.cataclysmengine.terrain;

import com.cataclysmengine.api.DisasterBlockChangeEvent;
import com.cataclysmengine.api.DisasterRollbackEvent;
import com.cataclysmengine.protection.ProtectionService;
import com.cataclysmengine.rollback.TerrainJournal;
import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.TileState;
import org.bukkit.block.data.BlockData;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityCombustByBlockEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.plugin.java.JavaPlugin;

/** Bounded main-thread terrain changes with durable compare-and-restore rollback. */
public final class TerrainService implements Listener {
  private final JavaPlugin plugin;
  private final ProtectionService protection;
  private final Path directory;
  private final Map<UUID, Session> sessions = new LinkedHashMap<>();
  private final Map<Key, UUID> owners = new HashMap<>();
  private int editsThisTick;
  private boolean failed;
  private YamlConfiguration settings;
  private int nextSession;
  private final Map<UUID, Integer> hazardImmunity = new HashMap<>();

  public TerrainService(JavaPlugin plugin, ProtectionService protection) {
    this.plugin = plugin;
    this.protection = protection;
    directory = new File(plugin.getDataFolder(), "rollback").toPath();
    reload();
    recover();
    Bukkit.getPluginManager().registerEvents(this, plugin);
  }

  public void begin(UUID id, DestructionMode mode) {
    requireThread();
    if (mode == DestructionMode.VISUAL_ONLY) return;
    if (sessions.containsKey(id)) return;
    if (sessions.size()
        >= Math.max(1, plugin.getConfig().getInt("limits.max-terrain-journals", 256))) return;
    long deadline = Long.MAX_VALUE;
    Session session = new Session(id, mode, deadline);
    if (mode != DestructionMode.VISUAL_ONLY && !write(session, "META|" + mode + "|" + deadline))
      return;
    sessions.put(id, session);
  }

  public boolean edit(UUID id, Block block, BlockData data, DestructionMode mode, String effect) {
    requireThread();
    if (failed || mode == DestructionMode.VISUAL_ONLY || data == null || block == null)
      return false;
    if (mode == DestructionMode.PERMANENT
        && !plugin.getConfig().getBoolean("destruction.allow-permanent", false)) return false;
    if (mode == DestructionMode.CUSTOM) {
      if (!settings.getBoolean("custom-effects." + effect, false)) return false;
    }
    if ((data.getMaterial() == Material.FIRE || data.getMaterial() == Material.SOUL_FIRE)
        && !Boolean.TRUE.equals(block.getWorld().getGameRuleValue(GameRule.DO_FIRE_TICK)))
      return false;
    if (editsThisTick
        >= Math.max(1, plugin.getConfig().getInt("limits.max-changed-blocks-per-tick", 64)))
      return false;
    if (!block.getWorld().isChunkLoaded(block.getX() >> 4, block.getZ() >> 4)) return false;
    if (block.getY() < block.getWorld().getMinHeight()
        || block.getY() >= block.getWorld().getMaxHeight()) return false;
    if (!protection.allowed(block.getLocation()) || protectedBlock(block)) return false;
    // Never introduce a tile entity: all complex state is left untouched by this engine.
    if (data.getMaterial().isBlock() && isTileMaterial(data.getMaterial())) return false;
    if (block.getBlockData().getAsString().equals(data.getAsString())) return false;
    begin(id, mode);
    Session session = sessions.get(id);
    if (session == null || session.rolling) return false;
    // A physical flood/lava component must remain temporary, even in a permanent solid event.
    // Conservatively promote the entire event instead of allowing mixed irrecoverable fluids.
    if (mode == DestructionMode.TEMPORARY && session.mode != DestructionMode.TEMPORARY) {
      if (!write(session, "MODE|TEMPORARY")) return false;
      session.mode = DestructionMode.TEMPORARY;
    }
    Key key = new Key(block.getWorld().getUID(), block.getX(), block.getY(), block.getZ());
    UUID owner = owners.get(key);
    if (owner != null && !owner.equals(id)) return false;
    Change previous = session.changes.get(key);
    if (previous != null
        && (previous.touched || !previous.applied.equals(block.getBlockData().getAsString())))
      return false;
    int maxEdits =
        Math.max(1, plugin.getConfig().getInt("limits.max-terrain-edits-per-event", 4096));
    if (previous == null && session.changes.size() >= maxEdits) return false;
    if (session.anchor == null) session.anchor = block.getLocation();
    double maxRadius = Math.max(1, plugin.getConfig().getDouble("limits.max-radius", 96));
    if (!session.anchor.getWorld().equals(block.getWorld())
        || session.anchor.distanceSquared(block.getLocation()) > maxRadius * maxRadius)
      return false;
    long chunk = ((long) (block.getX() >> 4) << 32) ^ ((block.getZ() >> 4) & 0xffffffffL);
    int chunkLimit = Math.max(1, plugin.getConfig().getInt("limits.chunks-per-event", 16));
    if (!session.chunks.contains(chunk) && session.chunks.size() >= chunkLimit) return false;
    var changeEvent =
        new DisasterBlockChangeEvent(id, block, block.getBlockData().clone(), data.clone(), effect);
    Bukkit.getPluginManager().callEvent(changeEvent);
    if (changeEvent.isCancelled()
        || session.rolling
        || sessions.get(id) != session
        || !block.getWorld().isChunkLoaded(block.getX() >> 4, block.getZ() >> 4)
        || !block.getBlockData().getAsString().equals(changeEvent.getBefore().getAsString())
        || !protection.allowed(block.getLocation())) return false;
    String original = previous == null ? block.getBlockData().getAsString() : previous.original;
    Change change = new Change(key, original, data.getAsString(), false);
    if (!write(
        session,
        "EDIT|"
            + key.world
            + "|"
            + key.x
            + "|"
            + key.y
            + "|"
            + key.z
            + "|"
            + TerrainJournal.encode(original)
            + "|"
            + TerrainJournal.encode(change.applied))) return false;
    session.changes.put(key, change);
    session.worlds.add(key.world);
    session.chunks.add(chunk);
    owners.put(key, id);
    block.setBlockData(data, false);
    editsThisTick++;
    return true;
  }

  private boolean protectedBlock(Block block) {
    if (block.getState() instanceof TileState) return true;
    return switch (block.getType()) {
      case BEDROCK,
          BARRIER,
          END_PORTAL,
          END_PORTAL_FRAME,
          NETHER_PORTAL,
          STRUCTURE_VOID,
          LIGHT,
          COMMAND_BLOCK,
          CHAIN_COMMAND_BLOCK,
          REPEATING_COMMAND_BLOCK,
          JIGSAW,
          STRUCTURE_BLOCK ->
          true;
      default -> false;
    };
  }

  private boolean isTileMaterial(Material material) {
    String n = material.name();
    return n.contains("CHEST")
        || n.endsWith("SHULKER_BOX")
        || n.endsWith("SIGN")
        || n.endsWith("BANNER")
        || n.endsWith("SKULL")
        || n.endsWith("HEAD")
        || n.endsWith("BED")
        || n.endsWith("FURNACE")
        || n.contains("COMMAND_BLOCK")
        || n.equals("HOPPER")
        || n.equals("BARREL")
        || n.equals("DISPENSER")
        || n.equals("DROPPER")
        || n.equals("SPAWNER")
        || n.equals("BEACON")
        || n.equals("BREWING_STAND")
        || n.equals("LECTERN")
        || n.equals("CAMPFIRE")
        || n.equals("SOUL_CAMPFIRE")
        || n.contains("BEE")
        || n.equals("DECORATED_POT")
        || n.equals("CHISELED_BOOKSHELF")
        || n.equals("CRAFTER")
        || n.equals("VAULT")
        || n.equals("TRIAL_SPAWNER")
        || n.equals("CONDUIT")
        || n.equals("JUKEBOX")
        || n.equals("ENCHANTING_TABLE")
        || n.equals("ENDER_CHEST")
        || n.equals("END_GATEWAY")
        || n.equals("END_PORTAL")
        || n.equals("MOVING_PISTON")
        || n.equals("STRUCTURE_BLOCK")
        || n.equals("JIGSAW")
        || n.equals("SUSPICIOUS_SAND")
        || n.equals("SUSPICIOUS_GRAVEL")
        || n.equals("SCULK_SENSOR")
        || n.equals("CALIBRATED_SCULK_SENSOR")
        || n.equals("SCULK_SHRIEKER")
        || n.equals("SCULK_CATALYST");
  }

  /** Queues a bounded rollback; unloaded chunks remain pending until naturally loaded. */
  public int rollback(UUID id) {
    requireThread();
    Session session = sessions.get(id);
    if (session == null) return 0;
    if (!session.rolling) {
      var event = new DisasterRollbackEvent(id);
      Bukkit.getPluginManager().callEvent(event);
      if (event.isCancelled()) return 0;
      if (sessions.get(id) != session) return 0;
    }
    if (!session.rolling && !write(session, "ROLLBACK")) return 0;
    session.rolling = true;
    return session.changes.size();
  }

  /** Called by the shared controller once per server tick, never asynchronously. */
  public void tick() {
    requireThread();
    editsThisTick = 0;
    int serverTick = Bukkit.getCurrentTick();
    hazardImmunity.entrySet().removeIf(e -> e.getValue() <= serverTick);
    if (failed) return;
    int budget = Math.max(1, plugin.getConfig().getInt("limits.max-changed-blocks-per-tick", 64));
    int inspections = Math.max(4, budget * 4);
    long now = System.currentTimeMillis();
    List<Session> current = new ArrayList<>(sessions.values());
    int start = current.isEmpty() ? 0 : nextSession % current.size();
    for (int index = 0; index < current.size(); index++) {
      if (inspections <= 0 || budget <= 0) return;
      int position = (start + index) % current.size();
      Session session = current.get(position);
      nextSession = position + 1;
      if ((session.mode == DestructionMode.TEMPORARY || session.mode == DestructionMode.CUSTOM)
          && now >= session.deadline) rollback(session.id);
      if (!session.rolling) continue;
      if (session.rollbackQueue == null)
        session.rollbackQueue = new ArrayDeque<>(session.changes.keySet());
      int scanBudget = Math.min(inspections, session.rollbackQueue.size());
      for (int scan = 0; scan < scanBudget; scan++) {
        if (budget <= 0 || inspections <= 0) return;
        inspections--;
        Key key = session.rollbackQueue.removeFirst();
        Change change = session.changes.get(key);
        if (change == null) continue;
        World world = Bukkit.getWorld(change.key.world);
        if (world == null || !world.isChunkLoaded(change.key.x >> 4, change.key.z >> 4)) {
          session.rollbackQueue.addLast(key);
          continue;
        }
        Block block = world.getBlockAt(change.key.x, change.key.y, change.key.z);
        // Snapshot player changes win. Protection added since an event also wins.
        if (!change.touched
            && block.getBlockData().getAsString().equals(change.applied)
            && !(block.getState() instanceof TileState)) {
          if (!protection.allowed(block.getLocation())) {
            session.rollbackQueue.addLast(key);
            continue;
          }
          block.setBlockData(Bukkit.createBlockData(change.original), false);
          // Completion follows the world write: a crash before this record is safe to retry.
          if (!write(session, "RESTORE|" + keyText(change.key))) return;
        } else if (!write(session, "SKIP|" + keyText(change.key))) return;
        session.changes.remove(change.key);
        session.retired.put(change.key, change);
        budget--;
        editsThisTick++;
      }
      if (session.changes.isEmpty()) {
        // World changes must be durable before their write-ahead record is retired.
        try {
          for (UUID worldId : session.worlds) {
            World world = Bukkit.getWorld(worldId);
            if (world != null) world.save();
          }
        } catch (RuntimeException ex) {
          failed = true;
          plugin
              .getLogger()
              .severe("World save failed; completed restoration journal retained: " + session.id);
          return;
        }
        if (write(session, "COMPLETE")) {
          sessions.remove(session.id);
          for (Key key : session.retired.keySet()) owners.remove(key, session.id);
          try {
            Files.deleteIfExists(file(session.id));
          } catch (IOException ex) {
            plugin.getLogger().warning("Completed rollback journal retained: " + session.id);
          }
        }
      }
    }
  }

  public void shutdown() {
    requireThread();
    for (Session session : new ArrayList<>(sessions.values()))
      if (session.mode == DestructionMode.TEMPORARY || session.mode == DestructionMode.CUSTOM)
        rollback(session.id);
    // Journals have already been forced to stable storage. Large/unloaded work resumes on boot.
  }

  public Map<String, Object> stats() {
    return Map.of(
        "journals",
        sessions.size(),
        "tracked-blocks",
        owners.size(),
        "edits-this-tick",
        editsThisTick,
        "storage-failed",
        failed,
        "pending-rollbacks",
        sessions.values().stream().filter(s -> s.rolling).count());
  }

  public List<UUID> recordedIds() {
    return List.copyOf(sessions.keySet());
  }

  /** Start the post-event restoration delay or discard an event that never changed terrain. */
  public void finish(UUID id) {
    requireThread();
    Session session = sessions.get(id);
    if (session != null
        && !session.rolling
        && !session.changes.isEmpty()
        && session.deadline == Long.MAX_VALUE
        && (session.mode == DestructionMode.TEMPORARY || session.mode == DestructionMode.CUSTOM)) {
      long seconds =
          Math.min(
              31_536_000,
              Math.max(1, plugin.getConfig().getLong("destruction.restore-after-seconds", 300)));
      long deadline = System.currentTimeMillis() + seconds * 1000L;
      if (write(session, "DEADLINE|" + deadline)) session.deadline = deadline;
    }
    if (session != null
        && !session.rolling
        && session.changes.isEmpty()
        && session.retired.isEmpty()
        && write(session, "COMPLETE")) {
      sessions.remove(id);
      try {
        Files.deleteIfExists(file(id));
      } catch (IOException ex) {
        plugin.getLogger().warning("Unused terrain journal retained: " + id);
      }
    }
  }

  public void reload() {
    settings =
        YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "protection.yml"));
  }

  private void recover() {
    try {
      Files.createDirectories(directory);
      try (var files = Files.list(directory)) {
        for (Path path :
            files.filter(p -> p.getFileName().toString().endsWith(".journal")).sorted().toList()) {
          TerrainJournal.repairTail(path);
          UUID id = UUID.fromString(path.getFileName().toString().replace(".journal", ""));
          Session session = null;
          for (String line : TerrainJournal.read(path)) {
            String[] a = line.split("\\|", -1);
            if (a[0].equals("META"))
              session = new Session(id, DestructionMode.valueOf(a[1]), Long.parseLong(a[2]));
            else if (session != null && a[0].equals("MODE"))
              session.mode = DestructionMode.valueOf(a[1]);
            else if (session != null && a[0].equals("DEADLINE"))
              session.deadline = Long.parseLong(a[1]);
            else if (session != null && a[0].equals("EDIT")) {
              Key key =
                  new Key(
                      UUID.fromString(a[1]),
                      Integer.parseInt(a[2]),
                      Integer.parseInt(a[3]),
                      Integer.parseInt(a[4]));
              session.changes.put(
                  key,
                  new Change(key, TerrainJournal.decode(a[5]), TerrainJournal.decode(a[6]), false));
              session.worlds.add(key.world);
            } else if (session != null && a[0].equals("SKIP")) session.changes.remove(parseKey(a));
            else if (session != null && a[0].equals("TOUCH")) {
              Change c = session.changes.get(parseKey(a));
              if (c != null)
                session.changes.put(c.key, new Change(c.key, c.original, c.applied, true));
            } else if (session != null && a[0].equals("ROLLBACK")) session.rolling = true;
            else if (session != null && a[0].equals("COMPLETE")) session.changes.clear();
          }
          if (session != null && !session.changes.isEmpty()) {
            // Any interrupted temporary event is restored after restart.
            if (session.mode == DestructionMode.TEMPORARY || session.mode == DestructionMode.CUSTOM)
              session.rolling = true;
            sessions.put(id, session);
            for (Key key : session.changes.keySet()) {
              UUID prior = owners.putIfAbsent(key, id);
              if (prior != null) throw new IOException("Overlapping rollback journals at " + key);
            }
          }
        }
      }
    } catch (IOException | RuntimeException ex) {
      failed = true;
      plugin
          .getLogger()
          .severe(
              "Terrain storage recovery failed; ALL further terrain edits disabled. Preserve"
                  + " rollback files: "
                  + ex.getMessage());
    }
  }

  private Key parseKey(String[] a) {
    return new Key(
        UUID.fromString(a[1]),
        Integer.parseInt(a[2]),
        Integer.parseInt(a[3]),
        Integer.parseInt(a[4]));
  }

  private String keyText(Key k) {
    return k.world + "|" + k.x + "|" + k.y + "|" + k.z;
  }

  private Path file(UUID id) {
    return directory.resolve(id + ".journal");
  }

  private boolean write(Session session, String line) {
    if (failed) return false;
    try {
      TerrainJournal.append(file(session.id), line);
      return true;
    } catch (IOException ex) {
      failed = true;
      plugin
          .getLogger()
          .severe(
              "Terrain journal cannot be synced; terrain editing and restoration paused: "
                  + ex.getMessage());
      return false;
    }
  }

  private void requireThread() {
    if (!Bukkit.isPrimaryThread())
      throw new IllegalStateException("Terrain changes require the server thread.");
  }

  private void touch(Block block) {
    Key key = new Key(block.getWorld().getUID(), block.getX(), block.getY(), block.getZ());
    UUID id = owners.get(key);
    if (id == null) return;
    Session session = sessions.get(id);
    Change c = session.changes.get(key);
    if (c == null) c = session.retired.get(key);
    if (c != null && !c.touched && write(session, "TOUCH|" + keyText(key))) {
      Change touched = new Change(key, c.original, c.applied, true);
      if (session.changes.containsKey(key)) session.changes.put(key, touched);
      else session.retired.put(key, touched);
    }
  }

  private boolean managed(Block b) {
    return owners.containsKey(new Key(b.getWorld().getUID(), b.getX(), b.getY(), b.getZ()));
  }

  /**
   * Native fluid/fire damage is suppressed only at owned hazards; disaster damage remains
   * authoritative.
   */
  @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
  public void hazardDamage(EntityDamageEvent event) {
    Entity entity = event.getEntity();
    switch (event.getCause()) {
      case FIRE, FIRE_TICK, LAVA, HOT_FLOOR -> {
        boolean contact = touchesOwnedHeat(entity);
        if (contact) hazardImmunity.put(entity.getUniqueId(), Bukkit.getCurrentTick() + 200);
        boolean residual =
            event.getCause() == EntityDamageEvent.DamageCause.FIRE_TICK
                && hazardImmunity.getOrDefault(entity.getUniqueId(), 0) > Bukkit.getCurrentTick();
        if (contact || residual) {
          event.setCancelled(true);
          entity.setFireTicks(0);
        }
      }
      case DROWNING -> {
        Block eye =
            entity instanceof LivingEntity living
                ? living.getEyeLocation().getBlock()
                : entity.getLocation().getBlock();
        if (eye.getType() == Material.WATER && managed(eye)) event.setCancelled(true);
      }
      default -> {}
    }
  }

  @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
  public void hazardCombust(EntityCombustByBlockEvent event) {
    Block source = event.getCombuster();
    if (source != null && managed(source) && heat(source.getType())) {
      hazardImmunity.put(event.getEntity().getUniqueId(), Bukkit.getCurrentTick() + 200);
      event.setCancelled(true);
    }
  }

  private boolean touchesOwnedHeat(Entity entity) {
    var box = entity.getBoundingBox();
    Location location = entity.getLocation();
    // At most 5x6x5 block checks per damage event, including ground contact.
    int minX = Math.max(location.getBlockX() - 2, (int) Math.floor(box.getMinX() - .05));
    int maxX = Math.min(location.getBlockX() + 2, (int) Math.floor(box.getMaxX() + .05));
    int minY = Math.max(location.getBlockY() - 1, (int) Math.floor(box.getMinY() - .15));
    int maxY = Math.min(location.getBlockY() + 4, (int) Math.floor(box.getMaxY() + .05));
    int minZ = Math.max(location.getBlockZ() - 2, (int) Math.floor(box.getMinZ() - .05));
    int maxZ = Math.min(location.getBlockZ() + 2, (int) Math.floor(box.getMaxZ() + .05));
    World world = entity.getWorld();
    for (int x = minX; x <= maxX; x++)
      for (int z = minZ; z <= maxZ; z++) {
        if (!world.isChunkLoaded(x >> 4, z >> 4)) continue;
        for (int y = minY; y <= maxY; y++) {
          if (y < world.getMinHeight() || y >= world.getMaxHeight()) continue;
          Block b = world.getBlockAt(x, y, z);
          if (heat(b.getType()) && managed(b)) return true;
        }
      }
    return false;
  }

  private boolean heat(Material material) {
    return material == Material.FIRE
        || material == Material.SOUL_FIRE
        || material == Material.LAVA
        || material == Material.MAGMA_BLOCK
        || material == Material.CAMPFIRE
        || material == Material.SOUL_CAMPFIRE;
  }

  @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
  public void fluid(BlockFromToEvent event) {
    if (managed(event.getBlock()) || managed(event.getToBlock())) event.setCancelled(true);
  }

  @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
  public void spread(BlockSpreadEvent event) {
    if (managed(event.getSource()) || managed(event.getBlock())) event.setCancelled(true);
  }

  @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
  public void burn(BlockBurnEvent event) {
    if (managed(event.getBlock())
        || event.getIgnitingBlock() != null && managed(event.getIgnitingBlock()))
      event.setCancelled(true);
  }

  @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
  public void ignite(BlockIgniteEvent event) {
    if (managed(event.getBlock())
        || event.getIgnitingBlock() != null && managed(event.getIgnitingBlock()))
      event.setCancelled(true);
  }

  @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
  public void form(BlockFormEvent event) {
    if (managed(event.getBlock())) event.setCancelled(true);
  }

  @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
  public void fade(BlockFadeEvent event) {
    if (managed(event.getBlock())) event.setCancelled(true);
  }

  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void breakBlock(BlockBreakEvent event) {
    touch(event.getBlock());
  }

  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void place(BlockPlaceEvent event) {
    touch(event.getBlock());
  }

  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void bucketEmpty(PlayerBucketEmptyEvent event) {
    touch(event.getBlock());
  }

  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void bucketFill(PlayerBucketFillEvent event) {
    touch(event.getBlock());
  }

  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void entityChange(EntityChangeBlockEvent event) {
    touch(event.getBlock());
  }

  @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
  public void pistonExtend(BlockPistonExtendEvent event) {
    if (event.getBlocks().stream()
        .anyMatch(b -> managed(b) || managed(b.getRelative(event.getDirection()))))
      event.setCancelled(true);
  }

  @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
  public void pistonRetract(BlockPistonRetractEvent event) {
    if (event.getBlocks().stream()
        .anyMatch(b -> managed(b) || managed(b.getRelative(event.getDirection()))))
      event.setCancelled(true);
  }

  @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
  public void explode(EntityExplodeEvent event) {
    event.blockList().removeIf(this::managed);
  }

  @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
  public void explodeBlock(BlockExplodeEvent event) {
    event.blockList().removeIf(this::managed);
  }

  private record Key(UUID world, int x, int y, int z) {}

  private record Change(Key key, String original, String applied, boolean touched) {}

  private static final class Session {
    final UUID id;
    DestructionMode mode;
    long deadline;
    final Map<Key, Change> changes = new LinkedHashMap<>();
    final Map<Key, Change> retired = new LinkedHashMap<>();
    final Set<Long> chunks = new HashSet<>();
    final Set<UUID> worlds = new HashSet<>();
    boolean rolling;
    Location anchor;
    Deque<Key> rollbackQueue;

    Session(UUID id, DestructionMode mode, long deadline) {
      this.id = id;
      this.mode = mode;
      this.deadline = deadline;
    }
  }
}
