package com.cataclysmengine.api;

import com.cataclysmengine.disaster.Disaster;
import java.util.UUID;
import org.bukkit.event.HandlerList;

public final class DisasterEndEvent extends org.bukkit.event.Event {
  private static final HandlerList HANDLERS = new HandlerList();
  private final Disaster disaster;
  private final UUID id;

  public DisasterEndEvent(UUID id, Disaster disaster) {
    this.id = id;
    this.disaster = disaster;
  }

  public UUID getDisasterId() {
    return id;
  }

  public Disaster getDisaster() {
    return disaster;
  }

  public HandlerList getHandlers() {
    return HANDLERS;
  }

  public static HandlerList getHandlerList() {
    return HANDLERS;
  }
}
