package com.cataclysmengine.disaster.meteor;

/** Pure deterministic geometry used by flight and crater simulation. */
public final class MeteorMath {
  private MeteorMath() {}

  public static double smoothStep(double t) {
    t = Math.clamp(t, 0.0, 1.0);
    return t * t * (3.0 - 2.0 * t);
  }

  /** Continuous angular noise keeps the crater rim irregular without random vertical walls. */
  public static double rimNoise(double angle, double seed) {
    return 0.52 * Math.sin(angle * 3 + seed)
        + 0.29 * Math.sin(angle * 7 - seed * 0.7)
        + 0.19 * Math.cos(angle * 11 + seed * 1.3);
  }

  public static double craterDepth(
      double x, double z, double radius, double depth, double irregularity, double seed) {
    double angle = Math.atan2(z, x);
    double localRadius = radius * (1 + Math.clamp(irregularity, 0, 0.4) * rimNoise(angle, seed));
    double normalized = Math.hypot(x, z) / Math.max(1, localRadius);
    if (normalized >= 1) return 0;
    double profile = Math.pow(1 - normalized * normalized, 1.4);
    double ripples = 0.15 * Math.sin(x * 0.7 + seed) * Math.cos(z * 0.6 - seed);
    return Math.max(0, depth * profile + ripples * depth * (1 - normalized));
  }
}
