package com.cataclysmengine.vfx.animation;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;

/** Immutable tick-based keyframe animation. No world access; safe for off-thread math. */
public final class AnimationTimeline {
  public enum Easing {
    LINEAR,
    EASE_IN,
    EASE_OUT,
    EASE_IN_OUT,
    SMOOTH_STEP;

    public double apply(double value) {
      double t = Math.clamp(value, 0, 1);
      return switch (this) {
        case LINEAR -> t;
        case EASE_IN -> t * t;
        case EASE_OUT -> 1 - (1 - t) * (1 - t);
        case EASE_IN_OUT -> t < .5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
        case SMOOTH_STEP -> t * t * (3 - 2 * t);
      };
    }
  }

  /** Rotation is in radians and unwrapped, allowing deliberate multi-turn tumbles. */
  public record Pose(
      double x,
      double y,
      double z,
      double yaw,
      double pitch,
      double scale,
      double opacity,
      double emissionRate) {
    public Pose {
      if (!Double.isFinite(x)
          || !Double.isFinite(y)
          || !Double.isFinite(z)
          || !Double.isFinite(yaw)
          || !Double.isFinite(pitch)
          || !Double.isFinite(scale)
          || !Double.isFinite(opacity)
          || !Double.isFinite(emissionRate))
        throw new IllegalArgumentException("Pose values must be finite");
      if (scale < 0 || emissionRate < 0 || opacity < 0 || opacity > 1)
        throw new IllegalArgumentException("Invalid scale, opacity or emission rate");
    }

    private Pose interpolate(Pose other, double amount) {
      return new Pose(
          mix(x, other.x, amount),
          mix(y, other.y, amount),
          mix(z, other.z, amount),
          mix(yaw, other.yaw, amount),
          mix(pitch, other.pitch, amount),
          mix(scale, other.scale, amount),
          mix(opacity, other.opacity, amount),
          mix(emissionRate, other.emissionRate, amount));
    }

    private static double mix(double from, double to, double t) {
      return from + (to - from) * t;
    }
  }

  /** Easing on a keyframe controls the segment beginning at that keyframe. */
  public record Keyframe(double tick, Pose pose, Easing easing) {
    public Keyframe {
      if (!Double.isFinite(tick) || tick < 0)
        throw new IllegalArgumentException("Invalid keyframe tick");
      Objects.requireNonNull(pose);
      Objects.requireNonNull(easing);
    }
  }

  public record SoundCue(double tick, String key) {
    public SoundCue {
      if (!Double.isFinite(tick) || tick < 0)
        throw new IllegalArgumentException("Invalid sound cue tick");
      if (key == null || key.isBlank())
        throw new IllegalArgumentException("Sound cue key is required");
    }
  }

  private final List<Keyframe> keyframes;
  private final List<SoundCue> sounds;

  public AnimationTimeline(List<Keyframe> keyframes, List<SoundCue> sounds) {
    if (keyframes == null || keyframes.isEmpty())
      throw new IllegalArgumentException("At least one keyframe is required");
    ArrayList<Keyframe> sorted = new ArrayList<>(keyframes);
    sorted.sort(Comparator.comparingDouble(Keyframe::tick));
    for (int i = 1; i < sorted.size(); i++)
      if (sorted.get(i - 1).tick == sorted.get(i).tick)
        throw new IllegalArgumentException("Duplicate keyframe ticks");
    this.keyframes = List.copyOf(sorted);
    ArrayList<SoundCue> cues = new ArrayList<>(Objects.requireNonNull(sounds));
    cues.sort(Comparator.comparingDouble(SoundCue::tick));
    for (SoundCue cue : cues)
      if (cue.tick < startTick() || cue.tick > endTick())
        throw new IllegalArgumentException("Sound cue lies outside timeline");
    this.sounds = List.copyOf(cues);
  }

  public double startTick() {
    return keyframes.getFirst().tick;
  }

  public double endTick() {
    return keyframes.getLast().tick;
  }

  public double duration() {
    return endTick() - startTick();
  }

  /** Out-of-range samples hold the first/last pose, never extrapolate. */
  public Pose sample(double tick) {
    if (!Double.isFinite(tick)) throw new IllegalArgumentException("Sample tick must be finite");
    if (tick <= startTick()) return keyframes.getFirst().pose;
    if (tick >= endTick()) return keyframes.getLast().pose;
    for (int i = 1; i < keyframes.size(); i++) {
      Keyframe next = keyframes.get(i);
      if (tick <= next.tick) {
        Keyframe previous = keyframes.get(i - 1);
        double t = (tick - previous.tick) / (next.tick - previous.tick);
        return previous.pose.interpolate(next.pose, previous.easing.apply(t));
      }
    }
    return keyframes.getLast().pose;
  }

  /** Emits each cue in (previousTick, currentTick], retaining cues when simulation skips ticks. */
  public void soundCuesBetween(
      double previousTick, double currentTick, Consumer<SoundCue> consumer) {
    if (!Double.isFinite(previousTick)
        || !Double.isFinite(currentTick)
        || currentTick < previousTick)
      throw new IllegalArgumentException("Sound playback requires finite forward tick positions");
    Objects.requireNonNull(consumer);
    for (SoundCue cue : sounds)
      if (cue.tick > previousTick && cue.tick <= currentTick) consumer.accept(cue);
  }
}
