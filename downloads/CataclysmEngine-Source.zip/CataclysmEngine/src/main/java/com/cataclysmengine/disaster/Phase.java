package com.cataclysmengine.disaster;

public enum Phase {
  WARNING,
  FORMATION,
  ACTIVE,
  DISSIPATION,
  AFTERMATH,
  ENDED
}
