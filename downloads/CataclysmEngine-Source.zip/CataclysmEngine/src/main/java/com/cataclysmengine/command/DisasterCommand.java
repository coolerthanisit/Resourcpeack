package com.cataclysmengine.command;

import com.cataclysmengine.CataclysmEnginePlugin;
import com.cataclysmengine.disaster.Disaster;
import com.cataclysmengine.disaster.DisasterType;
import com.cataclysmengine.gui.AdminGui;
import java.util.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;

/**
 * Validated, permission-separated administration entry point; works from console with coordinates.
 */
public final class DisasterCommand implements CommandExecutor, TabCompleter {
  private final CataclysmEnginePlugin plugin;
  private final AdminGui gui;
  private static final List<String> COMMANDS =
      List.of(
          "help",
          "gui",
          "start",
          "stop",
          "stopall",
          "list",
          "reload",
          "toggle",
          "intensity",
          "random",
          "preview",
          "rollback",
          "pack",
          "debug",
          "performance",
          "protect",
          "quality");

  public DisasterCommand(CataclysmEnginePlugin plugin, AdminGui gui) {
    this.plugin = plugin;
    this.gui = gui;
  }

  public static boolean allowed(CommandSender sender, String permission) {
    return sender.hasPermission("cataclysm.admin")
        || sender.hasPermission("cataclysm." + permission);
  }

  private void require(CommandSender sender, String permission) {
    if (!allowed(sender, permission))
      throw new IllegalArgumentException("You need cataclysm." + permission + " permission.");
  }

  private static Player player(CommandSender sender) {
    if (sender instanceof Player p) return p;
    throw new IllegalArgumentException(
        "This operation requires a player. Use /disaster start <type> <world> <x> <y> <z> from"
            + " console.");
  }

  private static void exact(String[] args, int n, String usage) {
    if (args.length != n) throw new IllegalArgumentException("Usage: /disaster " + usage);
  }

  private static void say(CommandSender sender, String text) {
    sender.sendMessage(Component.text(text, NamedTextColor.AQUA));
  }

  private static UUID uuid(String value) {
    try {
      UUID id = UUID.fromString(value);
      if (!id.toString().equalsIgnoreCase(value)) throw new IllegalArgumentException();
      return id;
    } catch (IllegalArgumentException ex) {
      throw new IllegalArgumentException("Use the complete event UUID from /disaster list.");
    }
  }

  private static DisasterType type(String value) {
    try {
      return DisasterType.parse(value);
    } catch (IllegalArgumentException ex) {
      throw new IllegalArgumentException("Unknown disaster. Types: " + String.join(", ", types()));
    }
  }

  private static List<String> types() {
    return Arrays.stream(DisasterType.values()).map(DisasterType::key).toList();
  }

  @Override
  public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
    String sub = args.length == 0 ? "help" : args[0].toLowerCase(Locale.ROOT);
    try {
      switch (sub) {
        case "help" -> {
          require(sender, "gui");
          say(sender, "CATACLYSM ENGINE — commands");
          for (String line :
              List.of(
                  "gui | list | random | stopall | reload | pack [send]",
                  "start <type> [<world> <x> <y> <z>] [--instant]",
                  "preview <type> [<world> <x> <y> <z>]",
                  "stop <id> | rollback <id> | intensity <id> <1-5>",
                  "toggle <type> | debug | performance",
                  "protect pos1|pos2|create <name>|remove <name>|list",
                  "quality low|medium|high")) say(sender, "/disaster " + line);
        }
        case "gui" -> {
          exact(args, 1, "gui");
          require(sender, "gui");
          gui.open(player(sender));
        }
        case "start", "preview" -> {
          boolean preview = sub.equals("preview");
          require(sender, preview ? "preview" : "start");
          boolean instant =
              !preview && args.length > 1 && args[args.length - 1].equalsIgnoreCase("--instant");
          int end = args.length - (instant ? 1 : 0);
          if (end != 2 && end != 6)
            throw new IllegalArgumentException(
                "Usage: /disaster "
                    + sub
                    + " <type> [<world> <x> <y> <z>]"
                    + (preview ? "" : " [--instant]"));
          Location target = end == 2 ? player(sender).getLocation() : coordinates(args);
          Disaster d = plugin.manager().start(type(args[1]), target, preview, instant);
          say(sender, "Started " + d.type().title + (preview ? " preview" : "") + ": " + d.id());
        }
        case "stop" -> {
          exact(args, 2, "stop <id>");
          require(sender, "stop");
          if (!plugin.manager().stop(uuid(args[1])))
            throw new IllegalArgumentException("No active event has that ID.");
          say(sender, "Disaster stopped; temporary changes follow rollback policy.");
        }
        case "stopall" -> {
          exact(args, 1, "stopall");
          require(sender, "stop");
          plugin.manager().stopAll();
          say(sender, "All active disasters stopped.");
        }
        case "list" -> {
          exact(args, 1, "list");
          require(sender, "gui");
          var active = plugin.manager().active();
          if (active.isEmpty()) say(sender, "No active disasters.");
          for (Disaster d : active) {
            Location l = d.origin();
            say(
                sender,
                d.id()
                    + " | "
                    + d.type().title
                    + " | "
                    + d.phase()
                    + " | intensity "
                    + d.intensity()
                    + " | "
                    + l.getWorld().getName()
                    + " "
                    + l.getBlockX()
                    + " "
                    + l.getBlockY()
                    + " "
                    + l.getBlockZ());
          }
        }
        case "reload" -> {
          exact(args, 1, "reload");
          require(sender, "reload");
          plugin.reloadSettings();
          say(sender, "Configuration reloaded. New events use updated lifecycle settings.");
        }
        case "toggle" -> {
          exact(args, 2, "toggle <type>");
          require(sender, "admin");
          DisasterType t = type(args[1]);
          plugin.settings().toggle(t);
          say(sender, t.title + " enabled: " + plugin.settings().bool(t, "enabled", true));
        }
        case "intensity" -> {
          exact(args, 3, "intensity <id> <1-5>");
          require(sender, "start");
          int n;
          try {
            n = Integer.parseInt(args[2]);
          } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Intensity must be an integer from 1 to 5.");
          }
          if (n < 1 || n > 5) throw new IllegalArgumentException("Intensity must be from 1 to 5.");
          Disaster d = plugin.manager().get(uuid(args[1]));
          if (d == null) throw new IllegalArgumentException("No active event has that ID.");
          d.intensity(n);
          say(sender, "Intensity changed to " + d.intensity() + ".");
        }
        case "random" -> {
          exact(args, 1, "random");
          require(sender, "start");
          Disaster d = plugin.manager().random(player(sender).getLocation());
          say(sender, "Started eligible " + d.type().title + ": " + d.id());
        }
        case "rollback" -> {
          exact(args, 2, "rollback <id>");
          require(sender, "rollback");
          UUID id = uuid(args[1]);
          plugin.manager().stop(id);
          int count = plugin.terrain().rollback(id);
          say(
              sender,
              "Rollback requested: "
                  + count
                  + " recorded changes. Unloaded chunks wait until available; later edits are"
                  + " preserved.");
        }
        case "pack" -> {
          require(sender, "gui");
          if (args.length == 2 && args[1].equalsIgnoreCase("send")) {
            say(sender, plugin.pack().info());
            plugin.pack().send(player(sender));
          } else {
            exact(args, 1, "pack [send]");
            say(sender, plugin.pack().info());
          }
        }
        case "debug", "performance" -> {
          exact(args, 1, sub);
          require(sender, "debug");
          say(
              sender,
              "Active disasters: "
                  + plugin.manager().active().size()
                  + " | TPS: "
                  + String.format(Locale.ROOT, "%.2f", Bukkit.getTPS()[0]));
          say(sender, "VFX: " + plugin.vfx().stats());
          say(sender, "Terrain: " + plugin.terrain().stats());
          if (sub.equals("debug")) {
            say(sender, "Java " + Runtime.version() + " | " + Bukkit.getVersion());
            say(sender, "Safe zones: " + plugin.protection().zones());
            say(sender, plugin.pack().info());
          }
        }
        case "protect" -> protect(sender, args);
        case "quality" -> {
          exact(args, 2, "quality low|medium|high");
          Player p = player(sender);
          String quality = args[1].toLowerCase(Locale.ROOT);
          if (!List.of("low", "medium", "high").contains(quality))
            throw new IllegalArgumentException("Choose low, medium, or high.");
          p.getPersistentDataContainer()
              .set(
                  new NamespacedKey("cataclysmengine", "quality"),
                  PersistentDataType.STRING,
                  quality);
          say(sender, "Personal effects quality: " + quality + ". Server caps still apply.");
        }
        default -> throw new IllegalArgumentException("Unknown command. Use /disaster help.");
      }
    } catch (IllegalArgumentException | IllegalStateException ex) {
      sender.sendMessage(
          Component.text(
              ex.getMessage() == null ? "The operation could not be completed." : ex.getMessage(),
              NamedTextColor.RED));
    }
    return true;
  }

  private Location coordinates(String[] args) {
    World world = Bukkit.getWorld(args[2]);
    if (world == null) throw new IllegalArgumentException("Unknown or unloaded world: " + args[2]);
    double x = number(args[3]), y = number(args[4]), z = number(args[5]);
    if (Math.abs(x) > 29_999_984
        || Math.abs(z) > 29_999_984
        || y < world.getMinHeight()
        || y >= world.getMaxHeight())
      throw new IllegalArgumentException("Coordinates are outside world bounds.");
    Location location = new Location(world, x, y, z);
    if (!world.getWorldBorder().isInside(location))
      throw new IllegalArgumentException("Target is outside the world border.");
    if (!world.isChunkLoaded(location.getBlockX() >> 4, location.getBlockZ() >> 4))
      throw new IllegalArgumentException(
          "Target chunk is not loaded. Visit it before starting a disaster.");
    return location;
  }

  private static double number(String value) {
    try {
      double d = Double.parseDouble(value);
      if (!Double.isFinite(d)) throw new NumberFormatException();
      return d;
    } catch (NumberFormatException ex) {
      throw new IllegalArgumentException("Coordinates must be finite numbers.");
    }
  }

  private void protect(CommandSender sender, String[] args) {
    require(sender, "admin");
    if (args.length < 2)
      throw new IllegalArgumentException(
          "Usage: /disaster protect pos1|pos2|create <name>|remove <name>|list");
    switch (args[1].toLowerCase(Locale.ROOT)) {
      case "pos1", "pos2" -> {
        exact(args, 2, "protect " + args[1]);
        Player p = player(sender);
        plugin
            .protection()
            .setPosition(
                p.getUniqueId(), args[1].equalsIgnoreCase("pos1") ? 1 : 2, p.getLocation());
        say(sender, "Selected " + args[1] + " at your current block.");
      }
      case "create" -> {
        exact(args, 3, "protect create <name>");
        plugin.protection().createZone(player(sender).getUniqueId(), args[2]);
        say(sender, "Saved safe zone " + args[2] + ".");
      }
      case "remove" -> {
        exact(args, 3, "protect remove <name>");
        plugin.protection().removeZone(args[2]);
        say(sender, "Removed safe zone " + args[2] + ".");
      }
      case "list" -> {
        exact(args, 2, "protect list");
        say(sender, "Safe zones: " + plugin.protection().zones());
      }
      default -> throw new IllegalArgumentException("Unknown protection operation.");
    }
  }

  private String permissionFor(String sub) {
    return switch (sub) {
      case "help", "gui", "list", "pack" -> "gui";
      case "start", "random", "intensity" -> "start";
      case "stop", "stopall" -> "stop";
      case "preview" -> "preview";
      case "reload" -> "reload";
      case "rollback" -> "rollback";
      case "debug", "performance" -> "debug";
      default -> "admin";
    };
  }

  @Override
  public List<String> onTabComplete(
      CommandSender sender, Command command, String alias, String[] args) {
    List<String> choices = new ArrayList<>();
    if (args.length == 1) {
      for (String s : COMMANDS)
        if (s.equals("quality") || allowed(sender, permissionFor(s))) choices.add(s);
    } else {
      String sub = args[0].toLowerCase(Locale.ROOT);
      if (!sub.equals("quality") && !allowed(sender, permissionFor(sub))) return List.of();
      if (args.length == 2)
        switch (sub) {
          case "start", "preview", "toggle" -> choices.addAll(types());
          case "stop", "intensity" ->
              plugin.manager().active().forEach(d -> choices.add(d.id().toString()));
          case "rollback" ->
              plugin.terrain().recordedIds().forEach(id -> choices.add(id.toString()));
          case "protect" -> choices.addAll(List.of("pos1", "pos2", "create", "remove", "list"));
          case "quality" -> choices.addAll(List.of("low", "medium", "high"));
          case "pack" -> choices.add("send");
          default -> {}
        }
      if (args.length == 3 && (sub.equals("start") || sub.equals("preview")))
        Bukkit.getWorlds().forEach(w -> choices.add(w.getName()));
      if (args.length == 3 && sub.equals("intensity"))
        choices.addAll(List.of("1", "2", "3", "4", "5"));
      if (args.length == 3 && sub.equals("protect") && args[1].equalsIgnoreCase("remove"))
        choices.addAll(plugin.protection().zones());
      if (args.length >= 4
          && args.length <= 6
          && (sub.equals("start") || sub.equals("preview"))
          && sender instanceof Player p) {
        Location l = p.getLocation();
        choices.add(
            Integer.toString(
                args.length == 4
                    ? l.getBlockX()
                    : args.length == 5 ? l.getBlockY() : l.getBlockZ()));
      }
      if ((args.length == 3 || args.length == 7) && sub.equals("start")) choices.add("--instant");
    }
    String prefix = args[args.length - 1].toLowerCase(Locale.ROOT);
    return choices.stream()
        .filter(s -> s.toLowerCase(Locale.ROOT).startsWith(prefix))
        .sorted()
        .toList();
  }
}
