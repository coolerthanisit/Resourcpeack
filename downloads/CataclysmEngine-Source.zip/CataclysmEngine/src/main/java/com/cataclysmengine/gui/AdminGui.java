package com.cataclysmengine.gui;

import com.cataclysmengine.CataclysmEnginePlugin;
import com.cataclysmengine.command.DisasterCommand;
import com.cataclysmengine.disaster.Disaster;
import com.cataclysmengine.disaster.DisasterType;
import java.util.*;
import java.util.function.Consumer;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

/** Server-owned menu inventories. All player item movement and spoofed clicks are cancelled. */
public final class AdminGui implements Listener {
  private final CataclysmEnginePlugin plugin;

  public AdminGui(CataclysmEnginePlugin plugin) {
    this.plugin = plugin;
  }

  private static final class Menu implements InventoryHolder {
    final UUID owner;
    final Map<Integer, Consumer<InventoryClickEvent>> actions = new HashMap<>();
    final Inventory inventory;

    Menu(Player player, int rows, String subtitle) {
      owner = player.getUniqueId();
      inventory =
          Bukkit.createInventory(
              this,
              rows * 9,
              Component.text("CATACLYSM ENGINE", NamedTextColor.GOLD)
                  .append(
                      Component.text(
                          subtitle.isEmpty() ? "" : " · " + subtitle, NamedTextColor.DARK_GRAY)));
    }

    @Override
    public Inventory getInventory() {
      return inventory;
    }

    void button(
        int slot,
        Material material,
        String name,
        List<String> lore,
        Consumer<InventoryClickEvent> action) {
      ItemStack item = new ItemStack(material);
      ItemMeta meta = item.getItemMeta();
      meta.displayName(
          Component.text(name, NamedTextColor.AQUA).decoration(TextDecoration.ITALIC, false));
      meta.lore(
          lore.stream()
              .map(
                  s ->
                      Component.text(s, NamedTextColor.GRAY)
                          .decoration(TextDecoration.ITALIC, false))
              .toList());
      item.setItemMeta(meta);
      inventory.setItem(slot, item);
      if (action != null) actions.put(slot, action);
    }
  }

  private void permission(Player p, String value) {
    if (!DisasterCommand.allowed(p, value))
      throw new IllegalArgumentException("You need cataclysm." + value + " permission.");
  }

  private static void message(Player p, String text) {
    p.sendMessage(Component.text(text, NamedTextColor.AQUA));
  }

  public void open(Player p) {
    permission(p, "gui");
    Menu menu = new Menu(p, 4, "");
    int i = 0;
    for (DisasterType type : DisasterType.values()) {
      int slot = (i < 7 ? 10 + i : 19 + (i - 7));
      i++;
      menu.button(
          slot,
          type.icon,
          type.title,
          List.of(
              "Configure, preview and start",
              "Enabled: " + plugin.settings().bool(type, "enabled", true)),
          e -> configure(p, type, p.getLocation()));
    }
    menu.button(
        23,
        Material.CLOCK,
        "Active Disasters",
        List.of(plugin.manager().active().size() + " running", "Stop or roll back active events"),
        e -> active(p, 0));
    menu.button(
        24,
        Material.COMPARATOR,
        "Configuration",
        List.of("Natural events, quality and limits"),
        e -> configuration(p));
    menu.button(
        25,
        Material.REDSTONE,
        "Performance",
        List.of("View tick rate and resource budgets"),
        e -> performance(p));
    menu.button(
        31,
        Material.BOOK,
        "Resource Pack Information",
        List.of("View pack configuration and request download"),
        e -> pack(p));
    p.openInventory(menu.inventory);
  }

  private void configure(Player p, DisasterType t, Location target) {
    permission(p, "gui");
    Menu menu = new Menu(p, 4, t.title);
    boolean enabled = plugin.settings().bool(t, "enabled", true);
    menu.button(
        4,
        t.icon,
        t.title,
        List.of("Target: " + place(target), "Configured values apply to new events"),
        null);
    menu.button(
        10,
        Material.LIME_DYE,
        "Start Disaster",
        List.of(
            "Starts with the configured warning stage",
            "Uses current destruction and gameplay settings"),
        e -> {
          permission(p, "start");
          if (destructive(t)) confirm(p, t, target);
          else start(p, t, target, false);
        });
    menu.button(
        11,
        Material.ENDER_EYE,
        "Preview Disaster",
        List.of("Visual-only terrain mode", "Preview suppresses gameplay damage and forces"),
        e -> {
          permission(p, "preview");
          start(p, t, target, true);
        });
    menu.button(
        12,
        Material.BLAZE_POWDER,
        "Intensity: " + plugin.settings().integer(t, "intensity", 2),
        List.of("Left: increase; right: decrease", "Range 1–5 (tornado EF0–EF4)"),
        e -> {
          permission(p, "admin");
          int n = plugin.settings().integer(t, "intensity", 2) + (e.isRightClick() ? -1 : 1);
          plugin.settings().set(t, "intensity", Math.clamp(n, 1, 5));
          configure(p, t, target);
        });
    menu.button(
        13,
        Material.COMPASS,
        "Radius: " + plugin.settings().number(t, "radius", 32),
        List.of("Left: +4 blocks; right: −4 blocks", "Limited by global maximum radius"),
        e -> {
          permission(p, "admin");
          double n = plugin.settings().number(t, "radius", 32) + (e.isRightClick() ? -4 : 4);
          plugin
              .settings()
              .set(
                  t,
                  "radius",
                  Math.clamp(n, 4, plugin.getConfig().getDouble("limits.max-radius", 80)));
          configure(p, t, target);
        });
    menu.button(
        14,
        Material.CLOCK,
        "Active duration: " + plugin.settings().integer(t, "active-duration", 40) + "s",
        List.of("Left: +10 seconds; right: −10 seconds", "Range 10–600 seconds"),
        e -> {
          permission(p, "admin");
          int n =
              plugin.settings().integer(t, "active-duration", 40) + (e.isRightClick() ? -10 : 10);
          plugin.settings().set(t, "active-duration", Math.clamp(n, 10, 600));
          configure(p, t, target);
        });
    toggle(
        menu,
        15,
        p,
        t,
        target,
        "block-damage",
        "Terrain changes",
        Material.IRON_PICKAXE,
        false,
        List.of(
            "Global destruction mode still applies",
            "Permanent mode requires explicit YAML configuration"));
    toggle(
        menu,
        16,
        p,
        t,
        target,
        "sounds",
        "Custom sounds",
        Material.NOTE_BLOCK,
        true,
        List.of("Positional disaster sound layers"));
    toggle(
        menu,
        20,
        p,
        t,
        target,
        "visuals",
        "Visual effects",
        Material.GLOWSTONE_DUST,
        true,
        List.of("Displays and particle layers"));
    menu.button(
        21,
        Material.ENDER_PEARL,
        "Target Location",
        List.of(
            "Left: your current location",
            "Right: block under crosshair (up to 96 blocks)",
            "Current: " + place(target)),
        e -> {
          Location selected = p.getLocation();
          if (e.isRightClick()) {
            Block block = p.getTargetBlockExact(96);
            if (block == null)
              throw new IllegalArgumentException("Look at a loaded block within 96 blocks.");
            selected = block.getLocation().add(.5, 1, .5);
          }
          configure(p, t, selected);
        });
    menu.button(
        22,
        enabled ? Material.LIME_CONCRETE : Material.RED_CONCRETE,
        "Enabled: " + enabled,
        List.of("Click to toggle this disaster type"),
        e -> {
          permission(p, "admin");
          plugin.settings().toggle(t);
          configure(p, t, target);
        });
    menu.button(31, Material.ARROW, "Back", List.of("Main menu"), e -> open(p));
    p.openInventory(menu.inventory);
  }

  private void toggle(
      Menu menu,
      int slot,
      Player p,
      DisasterType t,
      Location target,
      String key,
      String label,
      Material material,
      boolean fallback,
      List<String> description) {
    List<String> lore = new ArrayList<>(description);
    lore.add("Click to toggle");
    menu.button(
        slot,
        material,
        label + ": " + plugin.settings().bool(t, key, fallback),
        lore,
        e -> {
          permission(p, "admin");
          plugin.settings().set(t, key, !plugin.settings().bool(t, key, fallback));
          configure(p, t, target);
        });
  }

  private boolean destructive(DisasterType t) {
    return plugin.settings().bool(t, "block-damage", false)
        && !plugin
            .getConfig()
            .getString("default-destruction-mode", "VISUAL_ONLY")
            .equalsIgnoreCase("VISUAL_ONLY");
  }

  private void confirm(Player p, DisasterType t, Location target) {
    Menu menu = new Menu(p, 3, "Confirm terrain changes");
    menu.button(
        4,
        Material.TNT,
        "Confirm " + t.title,
        List.of(
            "Target: " + place(target),
            "Global mode: "
                + plugin.getConfig().getString("default-destruction-mode", "VISUAL_ONLY"),
            "Terrain and gameplay may be affected.",
            "Safe zones and edit limits remain enforced."),
        null);
    menu.button(
        11,
        Material.LIME_CONCRETE,
        "Confirm Start",
        List.of("Start this configured disaster"),
        e -> {
          permission(p, "start");
          start(p, t, target, false);
        });
    menu.button(
        15,
        Material.RED_CONCRETE,
        "Cancel",
        List.of("Return without starting"),
        e -> configure(p, t, target));
    p.openInventory(menu.inventory);
  }

  private void start(Player p, DisasterType t, Location target, boolean preview) {
    permission(p, preview ? "preview" : "start");
    Disaster d = plugin.manager().start(t, target.clone(), preview, false);
    p.closeInventory();
    message(p, "Started " + t.title + (preview ? " preview" : "") + ": " + d.id());
  }

  private void active(Player p, int requestedPage) {
    permission(p, "gui");
    List<Disaster> events = new ArrayList<>(plugin.manager().active());
    int last = Math.max(0, (events.size() - 1) / 21), page = Math.clamp(requestedPage, 0, last);
    Menu menu = new Menu(p, 4, "Active " + (page + 1));
    for (int index = page * 21; index < Math.min(events.size(), (page + 1) * 21); index++) {
      Disaster d = events.get(index);
      int slot = index - page * 21;
      menu.button(
          slot,
          d.type().icon,
          d.type().title,
          List.of(
              d.id().toString(),
              d.phase() + " · intensity " + d.intensity(),
              place(d.origin()),
              "Left: stop event",
              "Right: confirm rollback"),
          e -> {
            if (e.isRightClick()) {
              permission(p, "rollback");
              confirmRollback(p, d.id());
            } else {
              permission(p, "stop");
              plugin.manager().stop(d.id());
              active(p, page);
            }
          });
    }
    if (events.isEmpty())
      menu.button(
          13,
          Material.GLASS_BOTTLE,
          "No active disasters",
          List.of("Start a disaster or visual preview from the main menu"),
          null);
    menu.button(27, Material.ARROW, "Back", List.of("Main menu"), e -> open(p));
    if (page > 0)
      menu.button(
          28,
          Material.SPECTRAL_ARROW,
          "Previous",
          List.of("Previous page"),
          e -> active(p, page - 1));
    menu.button(31, Material.CLOCK, "Refresh", List.of("Update event list"), e -> active(p, page));
    menu.button(
        32,
        Material.BARRIER,
        "Stop All",
        List.of("Stops all active events", "No new event effects will be emitted"),
        e -> {
          permission(p, "stop");
          plugin.manager().stopAll();
          active(p, 0);
        });
    if (page < last)
      menu.button(
          35, Material.SPECTRAL_ARROW, "Next", List.of("Next page"), e -> active(p, page + 1));
    p.openInventory(menu.inventory);
  }

  private void confirmRollback(Player p, UUID id) {
    Menu menu = new Menu(p, 3, "Confirm rollback");
    menu.button(
        11,
        Material.LIME_CONCRETE,
        "Restore recorded changes",
        List.of(
            id.toString(),
            "The event will be stopped before rollback.",
            "Later edits are preserved where identifiable."),
        e -> {
          permission(p, "rollback");
          plugin.manager().stop(id);
          int n = plugin.terrain().rollback(id);
          message(p, "Rollback requested for " + n + " recorded changes.");
          active(p, 0);
        });
    menu.button(
        15, Material.RED_CONCRETE, "Cancel", List.of("Return to active events"), e -> active(p, 0));
    p.openInventory(menu.inventory);
  }

  private void configuration(Player p) {
    permission(p, "gui");
    Menu menu = new Menu(p, 3, "Configuration");
    menu.button(
        10,
        Material.DAYLIGHT_DETECTOR,
        "Automatic disasters: " + plugin.getConfig().getBoolean("automatic-disasters", false),
        List.of(
            "Click to toggle natural scheduling",
            "Biome, cooldown and protection rules still apply"),
        e -> {
          permission(p, "admin");
          plugin
              .getConfig()
              .set(
                  "automatic-disasters",
                  !plugin.getConfig().getBoolean("automatic-disasters", false));
          plugin.saveConfig();
          configuration(p);
        });
    menu.button(
        12,
        Material.SPYGLASS,
        "Server particle quality: "
            + plugin.settings().file("visuals").getString("quality", "HIGH"),
        List.of("Cycle LOW / MEDIUM / HIGH", "Personal reduction: /disaster quality low"),
        e -> {
          permission(p, "admin");
          List<String> quality = List.of("LOW", "MEDIUM", "HIGH");
          String current =
              plugin
                  .settings()
                  .file("visuals")
                  .getString("quality", "HIGH")
                  .toUpperCase(Locale.ROOT);
          plugin
              .settings()
              .file("visuals")
              .set("quality", quality.get((quality.indexOf(current) + 1) % 3));
          saveVisuals();
          configuration(p);
        });
    menu.button(
        14,
        Material.PAPER,
        "Safety and budgets",
        List.of(
            "Destruction: "
                + plugin.getConfig().getString("default-destruction-mode", "VISUAL_ONLY"),
            "Max radius: " + plugin.getConfig().getDouble("limits.max-radius", 80),
            "Global settings: plugins/CataclysmEngine/config.yml",
            "Permanent terrain changes require explicit configuration"),
        null);
    menu.button(
        16,
        Material.REPEATER,
        "Reload configuration",
        List.of("Read configuration files from disk"),
        e -> {
          permission(p, "reload");
          plugin.reloadSettings();
          configuration(p);
          message(p, "Configuration reloaded.");
        });
    menu.button(22, Material.ARROW, "Back", List.of("Main menu"), e -> open(p));
    p.openInventory(menu.inventory);
  }

  private void saveVisuals() {
    try {
      plugin
          .settings()
          .file("visuals")
          .save(new java.io.File(plugin.getDataFolder(), "visuals.yml"));
    } catch (java.io.IOException ex) {
      throw new IllegalStateException("Cannot persist visuals.yml.", ex);
    }
  }

  private void performance(Player p) {
    permission(p, "debug");
    Menu menu = new Menu(p, 3, "Performance");
    List<String> vfx = new ArrayList<>();
    plugin.vfx().stats().forEach((key, value) -> vfx.add(key + ": " + value));
    List<String> terrain = new ArrayList<>();
    plugin.terrain().stats().forEach((key, value) -> terrain.add(key + ": " + value));
    menu.button(11, Material.REDSTONE, "VFX budgets", vfx, null);
    menu.button(13, Material.GRASS_BLOCK, "Terrain budgets", terrain, null);
    menu.button(
        15,
        Material.CLOCK,
        "Server",
        List.of(
            "TPS: " + String.format(Locale.ROOT, "%.2f", Bukkit.getTPS()[0]),
            "Players: " + Bukkit.getOnlinePlayers().size(),
            "Active events: " + plugin.manager().active().size(),
            "Click to refresh"),
        e -> performance(p));
    menu.button(22, Material.ARROW, "Back", List.of("Main menu"), e -> open(p));
    p.openInventory(menu.inventory);
  }

  private void pack(Player p) {
    permission(p, "gui");
    Menu menu = new Menu(p, 3, "Resource Pack");
    menu.button(
        11,
        Material.WRITTEN_BOOK,
        "Pack information",
        List.of(
            "Click to print full pack details in chat",
            "Host the ZIP at a direct HTTPS download URL",
            "Configure the generated SHA-1 in config.yml"),
        e -> message(p, plugin.pack().info()));
    menu.button(
        15,
        Material.CHEST,
        "Request pack download",
        List.of(
            "Send the configured resource pack to you", "No local file paths are sent to clients"),
        e -> {
          message(p, plugin.pack().info());
          plugin.pack().send(p);
        });
    menu.button(22, Material.ARROW, "Back", List.of("Main menu"), e -> open(p));
    p.openInventory(menu.inventory);
  }

  private static String place(Location l) {
    return l.getWorld().getName() + " " + l.getBlockX() + " " + l.getBlockY() + " " + l.getBlockZ();
  }

  @EventHandler
  public void click(InventoryClickEvent event) {
    if (!(event.getView().getTopInventory().getHolder() instanceof Menu menu)) return;
    event.setCancelled(true);
    if (!(event.getWhoClicked() instanceof Player p) || !menu.owner.equals(p.getUniqueId())) return;
    int slot = event.getRawSlot();
    if (slot < 0 || slot >= menu.inventory.getSize()) return;
    Consumer<InventoryClickEvent> action = menu.actions.get(slot);
    if (action == null) return;
    // A menu may be stale after permissions are changed; re-check both menu and operation
    // permissions.
    Bukkit.getScheduler()
        .runTask(
            plugin,
            () -> {
              if (!p.isOnline() || p.getOpenInventory().getTopInventory() != menu.inventory) return;
              try {
                permission(p, "gui");
                action.accept(event);
              } catch (IllegalArgumentException | IllegalStateException ex) {
                p.sendMessage(
                    Component.text(
                        ex.getMessage() == null
                            ? "Operation could not be completed."
                            : ex.getMessage(),
                        NamedTextColor.RED));
              }
            });
  }

  @EventHandler
  public void drag(InventoryDragEvent event) {
    if (event.getView().getTopInventory().getHolder() instanceof Menu) event.setCancelled(true);
  }
}
