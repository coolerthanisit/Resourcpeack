package com.cataclysmengine.disaster.environment;

import com.cataclysmengine.disaster.*;
import com.cataclysmengine.terrain.DestructionMode;
import java.util.*;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.*;
import org.bukkit.util.Vector;

/**
 * Loaded-chunk-only primitives shared by the regional simulations. All calls are on the server
 * thread.
 */
public abstract class EnvironmentBehavior implements DisasterBehavior {
  protected final Random random = new Random();
  protected final Map<String, ItemDisplay> displays = new HashMap<>();

  protected boolean hazardous(Disaster d) {
    return d.phase() == Phase.ACTIVE && !d.preview();
  }

  protected boolean visible(Disaster d) {
    return d.phase() != Phase.WARNING && d.phase() != Phase.ENDED;
  }

  protected boolean loaded(Location p) {
    return p.getWorld() != null
        && p.getBlockY() >= p.getWorld().getMinHeight()
        && p.getBlockY() < p.getWorld().getMaxHeight()
        && p.getWorld().isChunkLoaded(p.getBlockX() >> 4, p.getBlockZ() >> 4);
  }

  protected Location surface(Location p) {
    if (!loaded(p)) return null;
    int y = p.getWorld().getHighestBlockYAt(p.getBlockX(), p.getBlockZ());
    return new Location(
        p.getWorld(), p.getX(), Math.min(y + 1, p.getWorld().getMaxHeight() - 1), p.getZ());
  }

  protected Location groundAt(Disaster d, double dx, double dz) {
    return surface(d.origin().add(dx, 0, dz));
  }

  protected Location sample(Disaster d, double radius) {
    double angle = random.nextDouble() * Math.PI * 2, r = Math.sqrt(random.nextDouble()) * radius;
    return groundAt(d, Math.cos(angle) * r, Math.sin(angle) * r);
  }

  protected Vector wind(Disaster d) {
    double angle = Math.toRadians(d.value("wind-angle", 30));
    return new Vector(Math.cos(angle), 0, Math.sin(angle));
  }

  protected Location movingCenter(Disaster d) {
    // Travel is bounded even if active durations or movement speed are configured very high.
    double travel =
        StormMath.boundedTravel(d.age() / 20.0, d.value("movement-speed", 0.6), d.radius());
    Vector direction = wind(d);
    return d.origin().add(direction.multiply(travel));
  }

  protected void model(
      Disaster d,
      String slot,
      String key,
      Location at,
      double scale,
      double yaw,
      double pitch,
      boolean glow) {
    if (!loaded(at) || !d.option("visuals", true)) return;
    ItemDisplay entity = displays.get(slot);
    if (entity == null || !entity.isValid()) {
      entity = d.vfx().model(d.id(), at, key, (float) Math.max(.001, scale), glow);
      if (entity != null) displays.put(slot, entity);
    }
    if (entity != null)
      d.vfx().pose(entity, at, (float) Math.max(.001, scale), (float) yaw, (float) pitch);
  }

  protected void hide(Disaster d, String slot) {
    ItemDisplay e = displays.remove(slot);
    if (e != null) d.vfx().remove(e);
  }

  protected void hideAll(Disaster d) {
    for (ItemDisplay e : displays.values()) d.vfx().remove(e);
    displays.clear();
  }

  protected void sound(Disaster d, Location p, String sound, double volume, double pitch) {
    if (d.age() % 40 == 0) d.vfx().sound(d, p, sound, (float) volume, (float) pitch);
  }

  protected List<LivingEntity> living(Location center, double radius) {
    if (!loaded(center)) return List.of();
    List<LivingEntity> result = new ArrayList<>();
    for (Entity e : center.getWorld().getNearbyEntities(center, radius, radius, radius)) {
      if (result.size() >= 96) break;
      if (e instanceof LivingEntity living
          && living.isValid()
          && !living.isDead()
          && living.getLocation().distanceSquared(center) <= radius * radius) result.add(living);
    }
    return result;
  }

  protected boolean edit(Disaster d, Location p, Material material, String effect) {
    if (!hazardous(d) || !loaded(p) || !d.option("block-damage", false)) return false;
    return d.plugin()
        .terrain()
        .edit(d.id(), p.getBlock(), material.createBlockData(), d.mode(), effect);
  }

  protected boolean water(Disaster d, Location p, String effect) {
    if (!hazardous(d)
        || !loaded(p)
        || !d.option("block-damage", false)
        || !d.option("flooding.physical", false)
        || d.mode() == DestructionMode.VISUAL_ONLY) return false;
    Block b = p.getBlock();
    if (!b.getType().isAir()) return false;
    // Physical floods are temporary even when solid destruction has been explicitly made permanent.
    return d.plugin()
        .terrain()
        .edit(d.id(), b, Material.WATER.createBlockData(), DestructionMode.TEMPORARY, effect);
  }

  protected void dust(Disaster d, Location p, Color color, float size, int count, double spread) {
    d.vfx().dust(d, p, color, size, count, spread);
  }

  protected void particle(Disaster d, Particle particle, Location at, int count, double spread) {
    d.vfx().particle(d, particle, at, count, spread);
  }

  protected double smooth(double t) {
    t = Math.clamp(t, 0, 1);
    return t * t * (3 - 2 * t);
  }

  protected boolean inside(Disaster d, Location p) {
    return p.getWorld() == d.origin().getWorld()
        && p.distanceSquared(d.origin()) <= d.radius() * d.radius();
  }

  @Override
  public void close(Disaster d) {
    hideAll(d);
    DisasterBehavior.super.close(d);
  }
}
