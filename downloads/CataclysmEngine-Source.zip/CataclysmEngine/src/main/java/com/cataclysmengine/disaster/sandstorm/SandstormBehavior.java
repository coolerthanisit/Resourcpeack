package com.cataclysmengine.disaster.sandstorm;

import com.cataclysmengine.disaster.*;
import com.cataclysmengine.disaster.environment.EnvironmentBehavior;
import org.bukkit.*;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

/** Travelling layered dust banks, rotating dust devils and directionally advected sand grit. */
public final class SandstormBehavior extends EnvironmentBehavior {
  @Override
  public void tick(Disaster d) {
    if (d.phase() == Phase.AFTERMATH && !d.option("aftermath", true)) {
      hideAll(d);
      return;
    }
    if (d.age() % 3 != 0) return;
    double strength = d.strength();
    Location center = movingCenter(d);
    Vector wind = wind(d);
    sound(d, center, "sandstorm_wind", .25 + strength * 1.1, .85 + strength * .15);
    if (d.phase() == Phase.AFTERMATH) {
      hideAll(d);
      dust(d, center, Color.fromRGB(168, 133, 77), .8f, 3, 4);
      return;
    }
    for (int column = 0; column < 4; column++) {
      double a = column * 2.4 + d.age() * .005;
      Location base =
          surface(
              center.clone().add(Math.cos(a) * d.radius() * .5, 0, Math.sin(a) * d.radius() * .5));
      if (base == null) continue;
      for (int level = 0; level < 9; level++) {
        double spin = d.age() * .11 + level * .65 + column,
            y = level * 1.3 * strength,
            r = .7 + level * .22 * strength;
        dust(
            d,
            base.clone().add(Math.cos(spin) * r, y, Math.sin(spin) * r),
            Color.fromRGB(194, 155, 92),
            1.8f,
            2,
            .6);
      }
      if (visible(d))
        model(
            d,
            "dustbank" + column,
            "cloud",
            base.clone().add(0, 3 + strength * 2, 0),
            (3 + strength * 4) * strength,
            a,
            0,
            false);
    }
    for (var player : center.getWorld().getPlayers()) {
      double dist = player.getLocation().distanceSquared(center);
      if (dist > d.radius() * d.radius()) continue;
      double density = strength * (1 - Math.sqrt(dist) / Math.max(1, d.radius()));
      for (int i = 0; i < Math.max(3, (int) (20 * density)); i++) {
        double t = (i * .618 + d.age() * .045) % 1, lateral = Math.sin(i * 4.7) * 7;
        Location p =
            player
                .getEyeLocation()
                .add(wind.clone().multiply(t * 14 - 7))
                .add(-wind.getZ() * lateral, Math.sin(i) * 3 - t, wind.getX() * lateral);
        dust(
            d,
            p,
            i % 3 == 0 ? Color.fromRGB(230, 194, 125) : Color.fromRGB(177, 134, 73),
            1.2f,
            1,
            .3);
      }
      if (hazardous(d)
          && d.age() % 30 == 0
          && d.option("slowing", true)
          && d.plugin().protection().allowed(player.getLocation())
          && player.getGameMode() != GameMode.CREATIVE
          && player.getGameMode() != GameMode.SPECTATOR) {
        // Brief effects are allowed to expire after leaving the area; no persistent potion state is
        // left behind.
        if (!player.hasPotionEffect(PotionEffectType.SLOWNESS))
          player.addPotionEffect(
              new PotionEffect(
                  PotionEffectType.SLOWNESS,
                  35,
                  Math.min(1, d.intensity() / 3),
                  true,
                  false,
                  false));
        d.force(player, wind.clone().multiply(.04 * d.intensity()));
      }
    }
    if (visible(d))
      for (int i = 0; i < 7; i++) {
        double phase = (d.age() * .01 + i * .13) % 1;
        Location p =
            center
                .clone()
                .add(wind.clone().multiply((phase - .5) * d.radius()))
                .add(Math.sin(i * 3.7) * 5, 1 + phase * 2, Math.cos(i * 3.7) * 5);
        model(
            d,
            "grit" + i,
            "storm_debris",
            p,
            .14 + strength * .16,
            d.age() * .09 + i,
            d.age() * .07,
            false);
      }
    if (hazardous(d) && d.option("accumulation", true) && d.age() % 20 == 0)
      for (int i = 0; i < 3; i++) {
        Location p = sample(d, d.radius());
        if (p == null) continue;
        Material below = p.clone().subtract(0, 1, 0).getBlock().getType();
        // Supported full blocks are used rather than unstable falling sand entities.
        if (p.getBlock().getType().isAir()
            && (below == Material.SAND
                || below == Material.SANDSTONE
                || below == Material.RED_SANDSTONE)) edit(d, p, Material.SAND, "sand");
      }
  }
}
