package com.cataclysmengine.disaster.wildfire;

import com.cataclysmengine.disaster.*;
import com.cataclysmengine.disaster.environment.EnvironmentBehavior;
import java.util.*;
import org.bukkit.*;
import org.bukkit.util.Vector;

/** A finite, wind-biased cellular surface fire. Each cell has fuel, burn age and cooling time. */
public final class WildfireBehavior extends EnvironmentBehavior {
  private record Cell(int x, int y, int z, int born) {}

  private final Map<Long, Cell> cells = new LinkedHashMap<>();
  private final Set<Long> seen = new HashSet<>();
  private int ignited;

  private long key(int x, int z) {
    return ((long) x << 32) ^ (z & 0xffffffffL);
  }

  private boolean fuel(Location p) {
    if (!loaded(p)) return false;
    Material m = p.getBlock().getType(), below = p.clone().subtract(0, 1, 0).getBlock().getType();
    return Tag.LEAVES.isTagged(m)
        || Tag.LOGS.isTagged(m)
        || m == Material.SHORT_GRASS
        || m == Material.TALL_GRASS
        || m == Material.FERN
        || Tag.LEAVES.isTagged(below)
        || Tag.LOGS.isTagged(below)
        || below == Material.GRASS_BLOCK
        || below == Material.MOSS_BLOCK;
  }

  private void add(Disaster d, Location p) {
    if (p == null || !inside(d, p) || !fuel(p)) return;
    long key = key(p.getBlockX(), p.getBlockZ());
    if (!seen.add(key)) return;
    cells.put(key, new Cell(p.getBlockX(), p.getBlockY(), p.getBlockZ(), d.age()));
    ignited++;
  }

  @Override
  public void tick(Disaster d) {
    if (d.phase() == Phase.AFTERMATH && !d.option("aftermath", true)) {
      hideAll(d);
      return;
    }
    if (d.age() % 4 != 0) return;
    Location origin = d.origin();
    double strength = d.strength();
    sound(d, origin, "fire_crackle", .3 + strength, .85 + strength * .15);
    if (d.phase() == Phase.WARNING) {
      particle(d, Particle.SMOKE, origin, 3, .8);
      return;
    }
    int cap = (int) Math.clamp(d.value("max-cells", 96), 1, 512);
    int lifetime = (int) Math.clamp(d.value("cell-lifetime", 160), 20, 1200);
    if (cells.isEmpty() && ignited == 0) add(d, surface(origin));
    int index = 0, fireEdits = 0;
    List<Cell> current = new ArrayList<>(cells.values());
    for (Cell cell : current) {
      Location at = new Location(origin.getWorld(), cell.x + .5, cell.y, cell.z + .5);
      if (!loaded(at)) continue;
      int age = d.age() - cell.born;
      double burn = Math.max(0, 1 - age / (double) lifetime) * strength;
      boolean burning = age < lifetime && d.phase() != Phase.AFTERMATH;
      if (burning) {
        particle(d, Particle.FLAME, at, Math.max(1, (int) (3 * burn)), .45);
        particle(
            d,
            Particle.LARGE_SMOKE,
            at.clone().add(wind(d).multiply(age * .003)).add(0, 1 + age * .015, 0),
            2,
            .8 + age * .005);
        if (index % 5 == 0)
          particle(
              d,
              Particle.SMALL_FLAME,
              at.clone().add(wind(d).multiply((d.age() % 30) * .09)).add(0, 2, 0),
              2,
              .3);
        if (index < 6)
          model(d, "burning" + index, "burning_shell", at, .25 + burn * .4, d.age() * .01, 0, true);
        if (hazardous(d) && d.age() % 20 == 0) {
          if (fireEdits++ < 8
              && d.option("physical-fire", false)
              && Boolean.TRUE.equals(at.getWorld().getGameRuleValue(GameRule.DO_FIRE_TICK))
              && at.getBlock().getType().isAir()) edit(d, at, Material.FIRE, "fire");
        }
      } else {
        particle(d, Particle.SMOKE, at, 1, .6);
        if (age < lifetime + 40 && hazardous(d) && d.option("scorch", true)) {
          Location ground = at.clone().subtract(0, 1, 0);
          Material below = ground.getBlock().getType();
          if (below == Material.GRASS_BLOCK || below == Material.MOSS_BLOCK)
            edit(d, ground, Material.COARSE_DIRT, "scorch");
          if (Tag.LEAVES.isTagged(at.getBlock().getType())) edit(d, at, Material.AIR, "leaves");
        }
        if (age > lifetime + 60) cells.remove(key(cell.x, cell.z));
      }
      index++;
    }
    if (hazardous(d) && d.age() % 20 == 0)
      for (var entity : living(origin, d.radius())) {
        Cell cell =
            cells.get(key(entity.getLocation().getBlockX(), entity.getLocation().getBlockZ()));
        if (cell != null
            && d.age() - cell.born < lifetime
            && Math.abs(entity.getY() - cell.y) < 2.5) d.damage(entity, .4 * d.intensity());
      }
    for (int i = index; i < 6; i++) hide(d, "burning" + i);
    if (d.phase() == Phase.ACTIVE && ignited < cap && !current.isEmpty()) {
      int attempts = (int) Math.clamp(d.value("spread-rate", 3), 1, 12);
      boolean raining = origin.getWorld().hasStorm();
      Vector wind = wind(d);
      for (int i = 0; i < attempts; i++) {
        if (ignited >= cap) break;
        Cell source = current.get(random.nextInt(current.size()));
        if (d.age() - source.born > lifetime) continue;
        if (raining && random.nextDouble() < .8) continue;
        double angle = Math.atan2(wind.getZ(), wind.getX()) + random.nextDouble(-1.6, 1.6);
        int dx = (int) Math.round(Math.cos(angle)), dz = (int) Math.round(Math.sin(angle));
        Location next =
            surface(
                new Location(origin.getWorld(), source.x + dx + .5, source.y, source.z + dz + .5));
        add(d, next);
      }
    }
    if (d.phase() == Phase.DISSIPATION || d.phase() == Phase.AFTERMATH) {
      for (int i = 0; i < 6; i++) hide(d, "burning" + i);
    }
  }
}
