package com.cataclysmengine.api;

import java.util.UUID;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.event.HandlerList;

public final class DisasterBlockChangeEvent extends CataclysmEvent {
  private static final HandlerList HANDLERS = new HandlerList();
  private final Block block;
  private final BlockData before;
  private final BlockData after;
  private final String effect;

  public DisasterBlockChangeEvent(
      UUID id, Block block, BlockData before, BlockData after, String effect) {
    super(id);
    this.block = block;
    this.before = before.clone();
    this.after = after.clone();
    this.effect = effect;
  }

  public Block getBlock() {
    return block;
  }

  public BlockData getBefore() {
    return before.clone();
  }

  public BlockData getAfter() {
    return after.clone();
  }

  public String getEffect() {
    return effect;
  }

  public HandlerList getHandlers() {
    return HANDLERS;
  }

  public static HandlerList getHandlerList() {
    return HANDLERS;
  }
}
