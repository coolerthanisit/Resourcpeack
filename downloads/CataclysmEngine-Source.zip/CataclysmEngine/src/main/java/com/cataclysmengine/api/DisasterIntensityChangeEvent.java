package com.cataclysmengine.api;

import com.cataclysmengine.disaster.Disaster;
import java.util.UUID;
import org.bukkit.event.HandlerList;

public final class DisasterIntensityChangeEvent extends CataclysmEvent {
  private static final HandlerList HANDLERS = new HandlerList();
  private final Disaster disaster;
  private final int oldIntensity;
  private final int newIntensity;

  public DisasterIntensityChangeEvent(
      UUID id, Disaster disaster, int oldIntensity, int newIntensity) {
    super(id);
    this.disaster = disaster;
    this.oldIntensity = oldIntensity;
    this.newIntensity = newIntensity;
  }

  public Disaster getDisaster() {
    return disaster;
  }

  public int getOldIntensity() {
    return oldIntensity;
  }

  public int getNewIntensity() {
    return newIntensity;
  }

  public HandlerList getHandlers() {
    return HANDLERS;
  }

  public static HandlerList getHandlerList() {
    return HANDLERS;
  }
}
