package com.cataclysmengine.config;

import com.cataclysmengine.disaster.DisasterType;
import java.io.File;
import java.io.IOException;
import java.util.*;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

public final class Settings {
  private final JavaPlugin plugin;
  private final Map<String, YamlConfiguration> files = new HashMap<>();

  public Settings(JavaPlugin p) {
    plugin = p;
    reload();
  }

  public void reload() {
    plugin.reloadConfig();
    for (String n : List.of("disasters", "messages", "sounds", "visuals", "worlds", "protection")) {
      File f = new File(plugin.getDataFolder(), n + ".yml");
      if (!f.exists()) plugin.saveResource(n + ".yml", false);
      files.put(n, YamlConfiguration.loadConfiguration(f));
    }
  }

  public YamlConfiguration file(String n) {
    return files.get(n);
  }

  public boolean bool(DisasterType t, String k, boolean d) {
    return file("disasters").getBoolean(t.key() + "." + k, d);
  }

  public double number(DisasterType t, String k, double d) {
    return file("disasters").getDouble(t.key() + "." + k, d);
  }

  public int integer(DisasterType t, String k, int d) {
    return file("disasters").getInt(t.key() + "." + k, d);
  }

  public String text(DisasterType t, String k, String d) {
    return file("disasters").getString(t.key() + "." + k, d);
  }

  public void set(DisasterType t, String key, Object value) {
    file("disasters").set(t.key() + "." + key, value);
    try {
      file("disasters").save(new File(plugin.getDataFolder(), "disasters.yml"));
    } catch (IOException e) {
      throw new IllegalStateException("Cannot save disasters.yml", e);
    }
  }

  public void toggle(DisasterType t) {
    set(t, "enabled", !bool(t, "enabled", true));
  }
}
