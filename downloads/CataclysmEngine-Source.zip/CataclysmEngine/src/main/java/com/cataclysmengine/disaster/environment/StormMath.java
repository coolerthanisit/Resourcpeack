package com.cataclysmengine.disaster.environment;

import java.util.*;

/** Pure simulation geometry, kept independent of the live world for reproducible testing. */
public final class StormMath {
  private StormMath() {}

  public record Fault(double x, double z, int depth) {}

  public static List<Fault> faults(long seed, double radius) {
    if (!Double.isFinite(radius) || radius <= 0)
      throw new IllegalArgumentException("Radius must be finite and positive");
    Random random = new Random(seed);
    List<Fault> points = new ArrayList<>();
    for (int branch = 0; branch < 4; branch++) {
      double angle = branch * Math.PI / 2 + random.nextDouble(-.3, .3), x = 0, z = 0;
      for (int i = 0; i < 18; i++) {
        angle += random.nextDouble(-.22, .22);
        x += Math.cos(angle) * radius / 23;
        z += Math.sin(angle) * radius / 23;
        if (x * x + z * z < radius * radius) points.add(new Fault(x, z, random.nextInt(1, 4)));
        if (i == 10)
          for (int k = 1; k <= 5; k++) {
            double a = angle + .8,
                bx = x + Math.cos(a) * k * radius / 64,
                bz = z + Math.sin(a) * k * radius / 64;
            if (bx * bx + bz * bz < radius * radius) points.add(new Fault(bx, bz, 1 + k % 2));
          }
      }
    }
    return List.copyOf(points);
  }

  public static double boundedTravel(double elapsedSeconds, double speed, double radius) {
    if (!Double.isFinite(elapsedSeconds) || !Double.isFinite(speed) || !Double.isFinite(radius))
      return 0;
    return Math.clamp(elapsedSeconds * Math.max(0, speed), 0, Math.max(0, radius) * .75);
  }

  public static double funnelRadius(double heightFraction, int intensity, double strength) {
    double t = Math.clamp(heightFraction, 0, 1), s = Math.clamp(strength, 0, 1);
    return (.5 + (2 + Math.clamp(intensity, 1, 5) * 1.5) * t * t) * s;
  }

  public static double floodFraction(String phase, double progress) {
    double t = Math.clamp(progress, 0, 1);
    return switch (phase) {
      case "FORMATION" -> t * .2;
      case "ACTIVE" -> .2 + t * .8;
      case "DISSIPATION" -> 1 - t;
      default -> 0;
    };
  }
}
