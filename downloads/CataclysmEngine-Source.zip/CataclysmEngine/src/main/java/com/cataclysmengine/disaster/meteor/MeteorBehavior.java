package com.cataclysmengine.disaster.meteor;

import com.cataclysmengine.api.DisasterImpactEvent;
import com.cataclysmengine.disaster.Disaster;
import com.cataclysmengine.disaster.DisasterBehavior;
import com.cataclysmengine.disaster.Phase;
import com.cataclysmengine.terrain.DestructionMode;
import com.cataclysmengine.vfx.animation.AnimationTimeline;
import com.cataclysmengine.vfx.animation.AnimationTimeline.Easing;
import com.cataclysmengine.vfx.animation.AnimationTimeline.Keyframe;
import com.cataclysmengine.vfx.animation.AnimationTimeline.Pose;
import com.cataclysmengine.vfx.animation.AnimationTimeline.SoundCue;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.SplittableRandom;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

/**
 * One main-thread controller owns flight, trail history, fragments, impacts and bounded terrain
 * work.
 */
public final class MeteorBehavior implements DisasterBehavior {
  // A normalized 100-tick animation is stretched to the configured travel duration.
  // x is path progress; yaw/pitch are tumble rotations; scale is the molten-core pulse.
  private static final AnimationTimeline ENTRY =
      new AnimationTimeline(
          List.of(
              new Keyframe(0, new Pose(0, 0, 0, 0, 0, .84, 1, .2), Easing.LINEAR),
              new Keyframe(45, new Pose(.363375, 0, 0, 2.8, 2, .84, 1, .65), Easing.LINEAR),
              new Keyframe(62, new Pose(.53754, 0, 0, 5.2, 3.3, .90, 1, .85), Easing.LINEAR),
              new Keyframe(100, new Pose(1, 0, 0, 10, 6, .84, 1, 1), Easing.LINEAR)),
          List.of(
              new SoundCue(1, "meteor_entry"),
              new SoundCue(28, "meteor_entry"),
              new SoundCue(56, "meteor_entry"),
              new SoundCue(84, "meteor_entry")));

  private final List<Flight> flights = new ArrayList<>();
  private final List<Fragment> fragments = new ArrayList<>();
  private final List<Impact> impacts = new ArrayList<>();
  private final SplittableRandom random = new SplittableRandom();
  private boolean launched;
  private int lastShower;

  @Override
  public void tick(Disaster d) {
    if (d.phase() == Phase.WARNING) {
      if (d.option("sky-ambiance", true) && d.age() % 10 == 0) {
        Location sky =
            d.origin()
                .add(
                    0,
                    Math.min(70, d.origin().getWorld().getMaxHeight() - d.origin().getY() - 8),
                    0);
        d.vfx().dust(d, sky, Color.fromRGB(255, 103, 35), 2.4f, 5, 12);
      }
      return;
    }
    if (!launched) {
      launched = true;
      flights.add(new Flight(d, d.origin(), selectSize(d), false));
    }
    if (d.phase() == Phase.ACTIVE
        && d.option("meteor-showers", false)
        && lastShower < Math.clamp((int) d.value("shower-count", 3), 0, 6)
        && d.phaseAge() >= 40 + lastShower * 60) {
      lastShower++;
      double angle = random.nextDouble(Math.PI * 2);
      double range = random.nextDouble(4, Math.max(5, d.radius() * 0.7));
      Location target = d.origin().add(Math.cos(angle) * range, 0, Math.sin(angle) * range);
      if (loaded(target)) {
        target.setY(target.getWorld().getHighestBlockYAt(target) + 1);
        flights.add(new Flight(d, target, "small", true));
      }
    }
    for (Iterator<Flight> it = flights.iterator(); it.hasNext(); ) {
      if (it.next().tick(d)) it.remove();
    }
    for (Iterator<Fragment> it = fragments.iterator(); it.hasNext(); ) {
      if (it.next().tick(d)) it.remove();
    }
    for (Impact impact : impacts) impact.tick(d);
    if (d.phase() == Phase.DISSIPATION || d.phase() == Phase.AFTERMATH) {
      for (Flight flight : flights) flight.finish(d);
      flights.clear();
    }
  }

  private String selectSize(Disaster d) {
    String configured = d.text("size", "auto").toLowerCase(java.util.Locale.ROOT);
    return switch (configured) {
      case "small", "medium", "large", "colossal" -> configured;
      default ->
          switch (d.intensity()) {
            case 1 -> "small";
            case 2, 3 -> "medium";
            case 4 -> "large";
            default -> "colossal";
          };
    };
  }

  private static boolean loaded(Location at) {
    return at.getY() >= at.getWorld().getMinHeight()
        && at.getY() < at.getWorld().getMaxHeight()
        && at.getWorld().isChunkLoaded(at.getBlockX() >> 4, at.getBlockZ() >> 4);
  }

  /** Refuses to ray trace into an unloaded chunk; visual simulation never generates terrain. */
  private static Location collision(Location from, Location to) {
    Vector delta = to.toVector().subtract(from.toVector());
    double distance = delta.length();
    if (distance < 1.0e-6 || !loaded(from) || !loaded(to)) return null;
    for (double s = 0; s < distance; s += 3) {
      if (!loaded(from.clone().add(delta.clone().multiply(s / distance)))) return null;
    }
    RayTraceResult hit =
        from.getWorld()
            .rayTraceBlocks(
                from, delta.clone().normalize(), distance, FluidCollisionMode.NEVER, true);
    return hit == null ? null : hit.getHitPosition().toLocation(from.getWorld());
  }

  private final class Flight {
    private final Location target, start;
    private Location position;
    private final float diameter;
    private final boolean shower;
    private final int duration;
    private int age;
    private final ItemDisplay shell, core, hotShell, haze;
    private final List<ItemDisplay> satellites = new ArrayList<>();
    private final ArrayDeque<Location> history = new ArrayDeque<>();
    private boolean fragmented;

    Flight(Disaster d, Location target, String size, boolean shower) {
      this.target = target.clone();
      this.shower = shower;
      diameter =
          switch (size) {
            case "small" -> 3f;
            case "large" -> 14f;
            case "colossal" -> 27f;
            default -> 7f;
          };
      String preset = d.text("trajectory", "diagonal").toLowerCase(java.util.Locale.ROOT);
      double height = Math.clamp(d.value("entry-height", 105), 20, 220);
      height = Math.min(height, target.getWorld().getMaxHeight() - target.getY() - diameter - 2);
      double range = Math.clamp(d.value("entry-distance", 64), 0, 180);
      if (preset.equals("vertical")) range = 0;
      if (preset.equals("shallow")) {
        range = Math.min(180, range * 1.8);
        height *= 0.6;
      }
      double heading = Math.toRadians(d.value("heading-degrees", 35));
      Location candidate =
          target
              .clone()
              .add(Math.cos(heading) * range, Math.max(8, height), Math.sin(heading) * range);
      while (range > 1 && !loaded(candidate)) {
        range *= .7;
        candidate =
            target
                .clone()
                .add(Math.cos(heading) * range, Math.max(8, height), Math.sin(heading) * range);
      }
      start = candidate;
      position = start.clone();
      duration =
          Math.clamp(
              (int) (d.value("travel-seconds", 10) * 20 / (preset.equals("high_speed") ? 1.8 : 1)),
              40,
              600);
      shell = d.vfx().model(d.id(), position, "meteor_" + size, diameter, false);
      core = d.vfx().model(d.id(), position, "molten_core", diameter * .84f, true);
      hotShell =
          diameter >= 14
              ? d.vfx().model(d.id(), position, "burning_shell", diameter * 1.01f, true)
              : null;
      haze =
          d.option("heat-haze", true)
              ? d.vfx().model(d.id(), position, "heat_haze", diameter * 1.16f, false)
              : null;
      int satelliteCount = diameter >= 20 ? 5 : diameter >= 10 ? 3 : 1;
      for (int i = 0; i < satelliteCount; i++)
        satellites.add(d.vfx().model(d.id(), position, "meteor_fragment", diameter * .16f, false));
    }

    boolean tick(Disaster d) {
      age++;
      double t = Math.min(1, (double) age / duration);
      // Increasing descent speed is gentle enough for display interpolation, with continuous path
      // curvature.
      Pose animation = ENTRY.sample(t * 100);
      double descent = animation.x();
      Location next =
          start.clone().add(target.toVector().subtract(start.toVector()).multiply(descent));
      double wobble = Math.sin(Math.PI * t) * Math.sin(t * 11) * diameter * .045;
      next.add(wobble, Math.sin(t * 17) * Math.sin(Math.PI * t) * .4, wobble * .7);
      Location hit = collision(position, next);
      if (hit != null || t >= 1) {
        impact(d, hit == null ? target : hit, diameter, !shower);
        finish(d);
        return true;
      }
      position = next;
      float yaw = (float) animation.yaw();
      float pitch = (float) (animation.pitch() + Math.sin(t * 9) * .09);
      d.vfx().pose(shell, position, diameter, yaw, pitch);
      float corePulse = (float) animation.scale();
      d.vfx().pose(core, position, diameter * corePulse, -yaw * .8f, pitch * .6f);
      d.vfx().pose(hotShell, position, diameter * 1.01f, yaw, pitch);
      d.vfx()
          .pose(
              haze,
              position,
              diameter * (1.16f + (float) Math.sin(age * .13) * .05f),
              -yaw * .4f,
              -pitch);
      for (int i = 0; i < satellites.size(); i++) {
        double orbit = age * .04 + i * Math.PI * 2 / satellites.size();
        Location at =
            position
                .clone()
                .add(
                    Math.cos(orbit) * diameter * .48,
                    Math.sin(orbit * 1.4) * diameter * .24,
                    Math.sin(orbit) * diameter * .48);
        d.vfx().pose(satellites.get(i), at, diameter * .16f, -yaw * 1.4f, pitch * 2);
      }
      history.addFirst(position.clone());
      while (history.size() > 32) history.removeLast();
      if (d.option("trail", true)) renderTrail(d, animation.emissionRate());
      ENTRY.soundCuesBetween(
          (age - 1) * 100.0 / duration,
          t * 100,
          cue ->
              d.vfx().sound(d, position, cue.key(), (float) (.3 + t * 1.3), (float) (.7 + t * .4)));
      boolean fragmenting = d.text("trajectory", "diagonal").equalsIgnoreCase("fragmenting");
      if (!fragmented
          && t > .57
          && (fragmenting || diameter >= 7)
          && d.option("fragmentation", true)) {
        fragmented = true;
        d.vfx().sound(d, position, "meteor_crack", 1.2f, .8f);
        int count = Math.clamp((int) d.value("fragments", diameter >= 20 ? 12 : 6), 0, 18);
        Vector forward = target.toVector().subtract(position.toVector()).normalize();
        for (int i = 0; i < count; i++) {
          Vector velocity =
              forward
                  .clone()
                  .multiply(.5 + random.nextDouble() * .5)
                  .add(
                      new Vector(
                          random.nextDouble(-.3, .3),
                          random.nextDouble(-.05, .25),
                          random.nextDouble(-.3, .3)));
          addFragment(d, position, velocity, (float) random.nextDouble(.4, 1.4), true);
        }
      }
      return false;
    }

    void renderTrail(Disaster d, double t) {
      d.vfx().particle(d, Particle.FLAME, position, 6, diameter * .2);
      d.vfx().dust(d, position, Color.fromRGB(255, 216, 95), 2.1f, 4, diameter * .22);
      int i = 0;
      for (Location point : history) {
        if (i++ % 3 != 0) continue;
        double fade = 1 - (double) i / 36;
        double spread = diameter * (.15 + i * .012);
        if (i < 12) {
          d.vfx()
              .dust(
                  d,
                  point,
                  Color.fromRGB(255, 90 + (int) (90 * fade), 16),
                  (float) (1.4 + fade),
                  3,
                  spread);
          d.vfx().particle(d, Particle.FLAME, point, 3, spread);
        }
        d.vfx()
            .particle(
                d, Particle.LARGE_SMOKE, point, Math.max(1, (int) (4 * fade * t)), spread * 1.2);
        if (i % 6 == 1) d.vfx().particle(d, Particle.LAVA, point, 1, spread);
      }
    }

    void finish(Disaster d) {
      d.vfx().remove(shell);
      d.vfx().remove(core);
      d.vfx().remove(hotShell);
      d.vfx().remove(haze);
      satellites.forEach(d.vfx()::remove);
      history.clear();
    }
  }

  private void addFragment(
      Disaster d, Location at, Vector velocity, float size, boolean secondary) {
    int cap = Math.clamp(d.plugin().getConfig().getInt("limits.max-fragments", 80), 0, 160);
    if (fragments.size() >= cap) return;
    fragments.add(new Fragment(d, at, velocity, size, secondary));
  }

  private final class Fragment {
    private Location at;
    private final Vector velocity;
    private final ItemDisplay display;
    private final float size;
    private final boolean secondary;
    private int age;

    Fragment(Disaster d, Location at, Vector velocity, float size, boolean secondary) {
      this.at = at.clone();
      this.velocity = velocity;
      this.size = size;
      this.secondary = secondary;
      display =
          d.vfx().model(d.id(), at, secondary ? "meteor_fragment" : "meteorite_debris", size, true);
    }

    boolean tick(Disaster d) {
      age++;
      velocity.multiply(.99).add(new Vector(0, -.027, 0));
      Location next = at.clone().add(velocity);
      Location hit = collision(at, next);
      if (hit != null || age > 140 || next.getY() < next.getWorld().getMinHeight() + 1) {
        if (hit != null) {
          d.vfx().particle(d, Particle.LARGE_SMOKE, hit, 7, size);
          d.vfx().particle(d, Particle.FLAME, hit, 4, size);
          if (secondary && d.option("secondary-impacts", true) && impacts.size() < 20)
            impact(d, hit, Math.min(2.4f, size * 1.8f), false);
        }
        d.vfx().remove(display);
        return true;
      }
      at = next;
      d.vfx().pose(display, at, size * (age > 115 ? (140 - age) / 25f : 1), age * .12f, age * .09f);
      if (age % 3 == 0) {
        d.vfx().particle(d, Particle.SMOKE, at, 2, .2);
        d.vfx().particle(d, Particle.FLAME, at, 1, .1);
      }
      return false;
    }
  }

  private void impact(Disaster d, Location at, float diameter, boolean primary) {
    if (!loaded(at)) return;
    DisasterImpactEvent event = new DisasterImpactEvent(d.id(), at);
    Bukkit.getPluginManager().callEvent(event);
    if (event.isCancelled()) return;
    Impact impact = new Impact(d, at, diameter, primary);
    impacts.add(impact);
    d.vfx().sound(d, at, "meteor_impact", primary ? 2 : .8f, primary ? .65f : 1.2f);
    if (d.option("flash", false)
        && !d.plugin().settings().file("visuals").getBoolean("reduced-flash", true))
      d.vfx().particle(d, Particle.FLASH, at.clone().add(0, 1, 0), 1, 0);
    d.vfx().particle(d, Particle.EXPLOSION, at, primary ? 6 : 2, diameter * .3);
    if (primary) {
      int count = Math.clamp((int) d.value("debris-density", 16), 0, 30);
      for (int i = 0; i < count; i++) {
        double angle = random.nextDouble(Math.PI * 2);
        double speed = random.nextDouble(.25, .85);
        addFragment(
            d,
            at.clone().add(0, 1, 0),
            new Vector(
                Math.cos(angle) * speed, random.nextDouble(.4, 1.2), Math.sin(angle) * speed),
            (float) random.nextDouble(.3, 1.2),
            false);
      }
    }
  }

  private final class Impact {
    private final Location center;
    private final float diameter;
    private final double radius;
    private final boolean primary;
    private final ItemDisplay fireball, wave;
    private final Set<UUID> shocked = new HashSet<>();
    private final ArrayDeque<Edit> edits = new ArrayDeque<>();
    private final int extent;
    private final double seed;
    private int age, scan, changed;
    private boolean scanDone;

    Impact(Disaster d, Location at, float diameter, boolean primary) {
      center = at.clone();
      this.diameter = diameter;
      this.primary = primary;
      radius =
          Math.clamp(
              primary ? d.value("crater-radius", diameter * .95) : diameter * .7,
              1,
              Math.min(40, d.radius()));
      extent =
          (int) Math.ceil(Math.clamp(d.value("scorch-radius", radius * 1.6), radius, radius * 2));
      seed = random.nextDouble(100);
      fireball = d.vfx().model(d.id(), center, "burning_shell", .3f, true);
      wave =
          d.option("shockwave", true)
              ? d.vfx().model(d.id(), center.clone().add(0, .2, 0), "shockwave", .1f, true)
              : null;
    }

    void tick(Disaster d) {
      age++;
      if (age < 45) {
        double t = age / 45.0;
        double r = Math.sin(t * Math.PI * .8) * Math.max(2, diameter * .9);
        d.vfx()
            .pose(
                fireball,
                center.clone().add(0, r * .25, 0),
                (float) (r * 2 * (1 - t * .3)),
                age * .04f,
                age * .02f);
        // Golden-angle spherical sampling gives volumetric layers rather than a single flat circle.
        for (int i = 0; i < 24; i++) {
          double y = 1 - 2 * (i + .5) / 24;
          double angle = i * 2.399963229728653 + age * .09;
          double ring = Math.sqrt(1 - y * y);
          Location shell =
              center
                  .clone()
                  .add(
                      Math.cos(angle) * ring * r,
                      Math.max(.2, y * r + r * .3),
                      Math.sin(angle) * ring * r);
          d.vfx()
              .dust(
                  d,
                  shell,
                  age < 15 ? Color.fromRGB(255, 205, 90) : Color.fromRGB(232, 83, 22),
                  2.5f,
                  1,
                  .3);
          if (i % 3 == 0) d.vfx().particle(d, Particle.LARGE_SMOKE, shell, 1, .4);
        }
      } else if (age == 45) d.vfx().remove(fireball);
      if (age <= 65 && d.option("shockwave", true)) shockwave(d);
      if (age == 66) d.vfx().remove(wave);
      if (age % 8 == 0 && d.option("aftermath", true) && d.option("lingering-smoke", true)) {
        double fade = Math.max(.05, 1 - age / 800.0);
        for (int i = 0; i < (primary ? 4 : 1); i++) {
          Location smoke =
              center
                  .clone()
                  .add(
                      random.nextDouble(-radius * .7, radius * .7),
                      .5,
                      random.nextDouble(-radius * .7, radius * .7));
          d.vfx().particle(d, Particle.LARGE_SMOKE, smoke, (int) (3 * fade) + 1, 1.5);
          d.vfx().particle(d, Particle.LAVA, smoke, 1, .4);
        }
      }
      if (age % 80 == 0) d.vfx().sound(d, center, "fire_crackle", .4f, .8f);
      terrain(d);
    }

    void shockwave(Disaster d) {
      double edge = age * Math.max(.35, Math.min(1.2, d.radius() / 55));
      if (edge > d.radius()) return;
      d.vfx().pose(wave, center.clone().add(0, .15, 0), (float) (edge * 2), 0, 0);
      for (int i = 0; i < 32; i++) {
        double a = i * Math.PI * 2 / 32;
        Location point = center.clone().add(Math.cos(a) * edge, 0, Math.sin(a) * edge);
        if (!loaded(point)) continue;
        int ground = point.getWorld().getHighestBlockYAt(point);
        if (Math.abs(ground - center.getY()) < 12) point.setY(ground + 1);
        d.vfx().dust(d, point, Color.fromRGB(131, 110, 88), 1.8f, 1, .7);
      }
      if (age % 4 == 0) {
        for (Entity entity :
            center
                .getWorld()
                .getNearbyEntities(
                    center, Math.min(d.radius(), edge + 2), 12, Math.min(d.radius(), edge + 2))) {
          if (!(entity instanceof LivingEntity living) || shocked.contains(entity.getUniqueId()))
            continue;
          double distance = entity.getLocation().distance(center);
          if (Math.abs(distance - edge) > 3) continue;
          shocked.add(entity.getUniqueId());
          double power = Math.max(0, 1 - distance / Math.max(1, d.radius()));
          Vector away = entity.getLocation().toVector().subtract(center.toVector()).setY(0);
          if (away.lengthSquared() < .001) away.setX(.1);
          Vector push =
              away.normalize()
                  .multiply(power * Math.clamp(d.value("shockwave-force", .8), 0, 1.5))
                  .setY(.15 + power * .22);
          if (d.option("screen-shake", false))
            push.add(new Vector(random.nextDouble(-.04, .04), 0, random.nextDouble(-.04, .04)));
          d.force(living, push);
          d.damage(
              living,
              power * Math.clamp(d.value("shockwave-damage", Math.min(16, diameter)), 0, 20));
        }
      }
      if (age == 8) d.vfx().sound(d, center, "rumble", 1.3f, .6f);
    }

    void terrain(Disaster d) {
      if (d.mode() == DestructionMode.VISUAL_ONLY
          || !d.option("crater", true)
          || !d.option("block-damage", false)) return;
      int budget = Math.clamp((int) d.value("crater-edits-per-tick", 32), 1, 128);
      int globalLimit =
          Math.max(1, d.plugin().getConfig().getInt("limits.max-changed-blocks-per-tick", 64));
      int used =
          ((Number) d.plugin().terrain().stats().getOrDefault("edits-this-tick", 0)).intValue();
      budget = Math.min(budget, Math.max(0, globalLimit - used));
      if (budget == 0) return;
      int maximum = Math.clamp((int) d.value("crater-max-blocks", 4000), 0, 12000);
      int columns = 0;
      while (edits.size() < budget && !scanDone && columns++ < 8 && changed < maximum) {
        int width = extent * 2 + 1;
        int dx = scan % width - extent, dz = scan / width - extent;
        if (++scan >= width * width) scanDone = true;
        planColumn(d, dx, dz);
      }
      for (int i = 0; i < budget && !edits.isEmpty() && changed < maximum; i++) {
        Edit edit = edits.removeFirst();
        if (!loaded(edit.at)) continue;
        if (d.plugin()
            .terrain()
            .edit(
                d.id(), edit.at.getBlock(), edit.material.createBlockData(), d.mode(), edit.effect))
          changed++;
      }
      if (changed >= maximum) {
        edits.clear();
        scanDone = true;
      }
    }

    void planColumn(Disaster d, int dx, int dz) {
      double distance = Math.hypot(dx, dz);
      if (distance > extent) return;
      Location col = center.clone().add(dx, 0, dz);
      if (!loaded(col) || !d.plugin().protection().allowed(col)) return;
      int surface = col.getWorld().getHighestBlockYAt(col);
      if (Math.abs(surface - center.getY()) > radius * 1.5 + 4) return;
      double depth =
          MeteorMath.craterDepth(
              dx,
              dz,
              radius,
              Math.clamp(d.value("crater-depth", radius * .45), 1, 20),
              d.value("crater-irregularity", .2),
              seed);
      int floor =
          Math.max(col.getWorld().getMinHeight() + 2, (int) Math.floor(center.getY() - depth));
      if (depth > .2) {
        for (int y = surface; y > floor; y--) {
          if (edits.size() > 256) break;
          Location pos = new Location(col.getWorld(), col.getBlockX(), y, col.getBlockZ());
          edits.add(new Edit(pos, Material.AIR, "craters"));
        }
        if (d.option("rock-conversion", true)) {
          Material material =
              random.nextDouble() < .08
                  ? Material.MAGMA_BLOCK
                  : random.nextBoolean() ? Material.BASALT : Material.BLACKSTONE;
          edits.add(
              new Edit(
                  new Location(col.getWorld(), col.getBlockX(), floor, col.getBlockZ()),
                  material,
                  "rock-conversion"));
        }
      } else if (distance < radius * 1.25) {
        double irregular = 1 + .18 * MeteorMath.rimNoise(Math.atan2(dz, dx), seed);
        int rim =
            Math.clamp(
                (int)
                    Math.round(
                        d.value("crater-rim-height", 2)
                            * irregular
                            * Math.max(0, 1 - Math.abs(distance / radius - 1) * 4)),
                0,
                5);
        if (d.option("rock-conversion", true)) {
          for (int y = 0; y < rim; y++)
            edits.add(
                new Edit(
                    new Location(col.getWorld(), col.getBlockX(), surface + y, col.getBlockZ()),
                    random.nextBoolean() ? Material.BASALT : Material.COBBLESTONE,
                    "rock-conversion"));
        }
      } else if (d.option("rock-conversion", true) && random.nextDouble() < .23) {
        edits.add(
            new Edit(
                new Location(col.getWorld(), col.getBlockX(), surface, col.getBlockZ()),
                random.nextBoolean() ? Material.TUFF : Material.BLACKSTONE,
                "rock-conversion"));
      }
      if (d.option("fire", false) && random.nextDouble() < .02 && distance < radius * 1.35) {
        Location fire = new Location(col.getWorld(), col.getBlockX(), surface + 1, col.getBlockZ());
        edits.add(new Edit(fire, Material.FIRE, "fire"));
      }
    }
  }

  private record Edit(Location at, Material material, String effect) {}

  @Override
  public void close(Disaster d) {
    flights.forEach(f -> f.finish(d));
    flights.clear();
    fragments.clear();
    impacts.clear();
    d.vfx().cleanup(d.id());
  }
}
