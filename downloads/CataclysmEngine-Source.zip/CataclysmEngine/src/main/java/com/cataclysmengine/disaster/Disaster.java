package com.cataclysmengine.disaster;

import com.cataclysmengine.CataclysmEnginePlugin;
import com.cataclysmengine.terrain.DestructionMode;
import com.cataclysmengine.vfx.VfxEngine;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.util.Vector;

public final class Disaster {
  private final UUID id = UUID.randomUUID();
  private final DisasterType type;
  private final Location origin;
  private final CataclysmEnginePlugin plugin;
  private final boolean preview;
  private final DestructionMode mode;
  private Phase phase = Phase.WARNING;
  private int age, phaseAge, intensity;
  private final int[] durations;
  private double radius;
  private final DisasterBehavior behavior;

  public Disaster(
      CataclysmEnginePlugin p,
      DisasterType t,
      Location at,
      boolean preview,
      boolean instant,
      DestructionMode mode) {
    this.plugin = p;
    type = t;
    origin = at.clone();
    this.preview = preview;
    this.mode = preview ? DestructionMode.VISUAL_ONLY : mode;
    intensity = Math.clamp(p.settings().integer(t, "intensity", 2), 1, 5);
    radius = p.settings().number(t, "radius", 32);
    if (!Double.isFinite(radius)) radius = 32;
    radius = Math.clamp(radius, 4, 80);
    durations =
        new int[] {
          Math.clamp(p.settings().integer(t, "warning-duration", 15), 0, 3600) * 20,
          Math.clamp(p.settings().integer(t, "formation-duration", 8), 0, 3600) * 20,
          Math.clamp(p.settings().integer(t, "active-duration", 40), 0, 3600) * 20,
          Math.clamp(p.settings().integer(t, "dissipation-duration", 8), 0, 3600) * 20,
          Math.clamp(p.settings().integer(t, "aftermath-duration", 10), 0, 3600) * 20
        };
    if (instant) durations[0] = 0;
    behavior = p.createBehavior(t);
  }

  public void tick() {
    age++;
    phaseAge++;
    while (phase != Phase.ENDED && phaseAge > Math.max(1, durations[phase.ordinal()])) {
      phase = Phase.values()[phase.ordinal() + 1];
      phaseAge = 1;
    }
    if (phase != Phase.ENDED) behavior.tick(this);
  }

  public UUID id() {
    return id;
  }

  public DisasterType type() {
    return type;
  }

  public Location origin() {
    return origin.clone();
  }

  public CataclysmEnginePlugin plugin() {
    return plugin;
  }

  public VfxEngine vfx() {
    return plugin.vfx();
  }

  public Phase phase() {
    return phase;
  }

  public int age() {
    return age;
  }

  public int phaseAge() {
    return phaseAge;
  }

  public int intensity() {
    return intensity;
  }

  public void intensity(int i) {
    int next = Math.clamp(i, 1, 5);
    var event = new com.cataclysmengine.api.DisasterIntensityChangeEvent(id, this, intensity, next);
    org.bukkit.Bukkit.getPluginManager().callEvent(event);
    if (!event.isCancelled()) intensity = next;
  }

  public double radius() {
    return Math.min(radius, plugin.getConfig().getDouble("limits.max-radius", 80));
  }

  public void radius(double r) {
    radius = Math.clamp(r, 4, plugin.getConfig().getDouble("limits.max-radius", 80));
  }

  public boolean preview() {
    return preview;
  }

  public DestructionMode mode() {
    return mode;
  }

  public double progress() {
    return phase == Phase.ENDED
        ? 1
        : Math.clamp((double) phaseAge / Math.max(1, durations[phase.ordinal()]), 0, 1);
  }

  public double strength() {
    return switch (phase) {
      case WARNING -> 0.05;
      case FORMATION -> progress();
      case ACTIVE -> 1;
      case DISSIPATION -> 1 - progress();
      case AFTERMATH -> 0.1 * (1 - progress());
      case ENDED -> 0;
    };
  }

  public boolean option(String key, boolean fallback) {
    return plugin.settings().bool(type, key, fallback);
  }

  public double value(String key, double fallback) {
    return plugin.settings().number(type, key, fallback);
  }

  public String text(String key, String fallback) {
    return plugin.settings().text(type, key, fallback);
  }

  public void damage(LivingEntity e, double amount) {
    plugin.damage(this, e, amount);
  }

  public void force(LivingEntity e, Vector v) {
    plugin.force(this, e, v);
  }

  public void close() {
    behavior.close(this);
    phase = Phase.ENDED;
  }
}
