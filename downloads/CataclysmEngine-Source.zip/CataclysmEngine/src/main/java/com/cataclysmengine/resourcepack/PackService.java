package com.cataclysmengine.resourcepack;

import com.cataclysmengine.CataclysmEnginePlugin;
import java.net.URI;
import java.util.*;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.*;

public final class PackService implements Listener {
  private final CataclysmEnginePlugin plugin;
  private final Map<UUID, Integer> retries = new HashMap<>();

  public PackService(CataclysmEnginePlugin p) {
    plugin = p;
  }

  public String info() {
    String url = plugin.getConfig().getString("resource-pack.url", "");
    return url.isBlank()
        ? "Pack not hosted yet. Upload dist/CataclysmEngine-ResourcePack.zip to an HTTPS"
              + " direct-download URL, then set resource-pack.url and sha1."
        : "Pack URL: "
            + url
            + " | SHA-1: "
            + plugin.getConfig().getString("resource-pack.sha1", "")
            + " | required: "
            + plugin.getConfig().getBoolean("resource-pack.required");
  }

  public void send(Player p) {
    String url = plugin.getConfig().getString("resource-pack.url", "");
    if (url.isBlank()) return;
    try {
      URI uri = URI.create(url);
      if (!"https".equalsIgnoreCase(uri.getScheme())
          || uri.getHost() == null
          || uri.getUserInfo() != null)
        throw new IllegalArgumentException(
            "Resource pack requires an HTTPS URL without embedded credentials");
      String sha = plugin.getConfig().getString("resource-pack.sha1", "");
      if (!sha.matches("[0-9a-fA-F]{40}"))
        throw new IllegalArgumentException("Resource-pack SHA-1 must have 40 hex characters");
      p.setResourcePack(
          url,
          HexFormat.of().parseHex(sha),
          MiniMessage.miniMessage()
              .deserialize(
                  plugin.getConfig().getString("resource-pack.prompt", "Cataclysm Engine")),
          plugin.getConfig().getBoolean("resource-pack.required", false));
    } catch (IllegalArgumentException ex) {
      plugin.getLogger().warning(ex.getMessage());
    }
  }

  @EventHandler
  public void join(PlayerJoinEvent e) {
    send(e.getPlayer());
  }

  @EventHandler
  public void quit(PlayerQuitEvent e) {
    retries.remove(e.getPlayer().getUniqueId());
  }

  @EventHandler
  public void status(PlayerResourcePackStatusEvent e) {
    var status = e.getStatus();
    if (status == PlayerResourcePackStatusEvent.Status.SUCCESSFULLY_LOADED) {
      retries.remove(e.getPlayer().getUniqueId());
      return;
    }
    if (status == PlayerResourcePackStatusEvent.Status.DECLINED) {
      if (plugin.getConfig().getBoolean("resource-pack.required")
          || plugin.getConfig().getBoolean("resource-pack.kick-on-decline"))
        e.getPlayer()
            .kick(
                MiniMessage.miniMessage()
                    .deserialize("<gold>This server requires the Cataclysm resource pack.</gold>"));
      else
        e.getPlayer()
            .sendMessage(
                "Cataclysm models and custom sounds need the optional resource pack. /disaster"
                    + " pack");
      return;
    }
    if (status == PlayerResourcePackStatusEvent.Status.FAILED_DOWNLOAD
        || status == PlayerResourcePackStatusEvent.Status.FAILED_RELOAD
        || status == PlayerResourcePackStatusEvent.Status.INVALID_URL) {
      UUID id = e.getPlayer().getUniqueId();
      int n = retries.merge(id, 1, Integer::sum);
      if (n <= Math.clamp(plugin.getConfig().getInt("resource-pack.retries", 1), 0, 5))
        plugin
            .getServer()
            .getScheduler()
            .runTaskLater(
                plugin,
                () -> {
                  Player p = plugin.getServer().getPlayer(id);
                  if (p != null) send(p);
                },
                Math.max(
                    20, plugin.getConfig().getInt("resource-pack.retry-delay-seconds", 10) * 20L));
    }
  }
}
