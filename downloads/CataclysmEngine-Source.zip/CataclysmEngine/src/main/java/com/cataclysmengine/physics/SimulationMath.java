package com.cataclysmengine.physics;

/** Pure math shared by simulations and tests. Time units are server ticks. */
public final class SimulationMath {
  private SimulationMath() {}

  public static double smoothStep(double t) {
    t = Math.clamp(t, 0, 1);
    return t * t * (3 - 2 * t);
  }

  public static double easeIn(double t) {
    return Math.pow(Math.clamp(t, 0, 1), 2);
  }

  public static double easeOut(double t) {
    return 1 - Math.pow(1 - Math.clamp(t, 0, 1), 2);
  }

  public static double easeInOut(double t) {
    return smoothStep(t);
  }

  public static double noisyRadius(double angle, double radius, double irregularity) {
    return radius
        * (1
            + irregularity
                * (.5 * Math.sin(angle * 3 + .8)
                    + .3 * Math.sin(angle * 7 + 2)
                    + .2 * Math.sin(angle * 13)));
  }

  public static double shockwaveStrength(double distance, double radius) {
    return Math.max(0, 1 - distance / Math.max(1, radius));
  }
}
