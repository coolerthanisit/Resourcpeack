# Cataclysm Engine

A standalone Java plugin project targeting **Paper 1.21.11**, **Java 25**, and unmodified Minecraft Java 1.21.11 clients. It includes ten disaster simulations, custom ItemDisplay models, original procedural textures and sounds, an administration GUI, and bounded terrain edits with persistent rollback journals.

This project has a much smaller implementation than the full premium simulator described in the development brief. The resource pack and simulation code are real files, but visual polish, client rendering, large multiplayer performance, protection integrations, and crash recovery need the acceptance checks described in [requirements coverage](docs/REQUIREMENTS.md). Consult [test results](docs/TEST_RESULTS.md) for the actual build and runtime evidence; source compilation does not establish that a JAR loads on Paper or that the effects look correct.

## Installation

1. Use a separate **Paper 1.21.11** test server running **Java 25**. Back up its worlds before enabling terrain edits.
2. Build the plugin using the instructions below. Copy `dist/CataclysmEngine.jar` into the server's `plugins/` directory when a successful build has produced it.
3. Start the server to generate `plugins/CataclysmEngine/` configuration files.
4. Host `dist/CataclysmEngine-ResourcePack.zip` at a public **HTTPS direct-download URL**. The URL must return the ZIP itself, without a login page.
5. Put that URL and the contents of `dist/CataclysmEngine-ResourcePack.sha1` in `plugins/CataclysmEngine/config.yml`:

   ```yaml
   resource-pack:
     url: 'https://your-host.example/CataclysmEngine-ResourcePack.zip'
     sha1: 'REPLACE_WITH_THE_GENERATED_40_CHARACTER_SHA1'
     required: false
     prompt: '<gold>Cataclysm Engine cinematic models and audio'
     retries: 1
     retry-delay-seconds: 10
     kick-on-decline: false
   ```

6. Run `/disaster reload`, reconnect or run `/disaster pack send`, and accept the pack. Placing the ZIP in a server folder does not make it downloadable.
7. As an operator, move outside spawn protection and run `/disaster gui` or `/disaster preview meteor`.

Custom models and sounds require the pack. Clients that reject an optional pack can stay connected but will not see the intended artwork or hear custom audio. Required mode can disconnect clients who decline. No ModelEngine, ItemsAdder, Oraxen, MythicMobs, ProtocolLib, or client mods are required. This is a conventional Paper plugin; Folia is not supported.

## Build and regenerate assets

Requirements: a Java 25 JDK, Python 3.10+ with Pillow, and FFmpeg with `libvorbis`. The Gradle wrapper pins Gradle 9.2.1 and verifies its distribution SHA-256. Gradle resolves Paper API `1.21.11-R0.1-SNAPSHOT` and JUnit from their repositories; first builds need network access.

```bash
export JAVA_HOME=/path/to/jdk-25
export PATH="$JAVA_HOME/bin:$PATH"
python3 -m pip install Pillow
./tools/build.sh
```

Equivalent separate steps:

```bash
./gradlew --no-daemon clean build
python3 tools/generate_assets.py
python3 tools/validate_assets.py
mkdir -p dist
cp build/libs/CataclysmEngine.jar dist/CataclysmEngine.jar
```

On Windows, use `gradlew.bat clean build`, then the two Python commands and copy the JAR manually. FFmpeg must be on `PATH`. Generated artwork is already included under `resource-pack/`; `artwork/` contains editable Blockbench projects. Regeneration overwrites those generated files, so keep manual changes elsewhere or update the generator.

The validator parses JSON and animation metadata, resolves item/model/texture references, verifies PNGs, fully decodes OGG sounds, checks ZIP root structure, and checks the ZIP's SHA-1. It cannot validate appearance in a Minecraft client. The pack uses namespace `cataclysm`, modern `items/*.json` definitions and the item-model component, separate item-atlas sources, and `min_format`/`max_format` **75.0**.

## Disaster simulations

Every event has a UUID and runs through warning, formation, active, dissipation, and aftermath stages under one main-thread controller. Preview mode disables terrain edits, damage, and forces.

| Type | Implemented mechanics |
| --- | --- |
| `meteor` | Four distinct rock-model variants, independently animated core/shell/components, angled entry presets, rotating flight, layered trail history, fragments and secondary impacts, volumetric sampled fireball, timed shockwave, bounded irregular craters/rims/scorch, lingering smoke |
| `tornado` | Travelling rotating cloud bank/funnel, independent debris orbits, five intensity levels, capped pull/lift, dropped-item motion, optional leaves/vegetation edits |
| `earthquake` | Seeded branching fault paths, tremor forces, ceiling dust, optional cracks/cave-ins, finite randomized aftershocks |
| `tsunami` | Segmented curved water models with animated crest/foam, advancing front, terrain attenuation, push/damage, optional bounded temporary water |
| `volcano` | Selected vent, pressure smoke, ash plume, repeated projectile bombs, impact/cooling rock effects, bounded downhill lava simulation |
| `blizzard` | Player-local directional snow curtains, moving ice fragments, optional freezing and snow layers |
| `sandstorm` | Travelling dust banks/devils, directional player-local grit, flying debris, optional brief slowness and sand accumulation |
| `wildfire` | Finite wind-biased fuel cells, aging/cooling smoke, rain-reduced spread, optional controlled fire and scorching |
| `supercell` | Moving rotating cloud deck, rain curtains/mist, gusts, branched lightning VFX, optional vanilla visual lightning |
| `flood` | Elevation-ordered bounded flood frontier, rising/receding visual water level, floating debris, optional temporary physical water |

These are stylized game simulations. Vanilla resource packs cannot provide true dynamic lighting, shader distortion, arbitrary camera control, genuinely volumetric fluids, or new native particle types. Brightness makes displays appear lit; it does not illuminate surrounding blocks. Heated-air geometry is a cutout illusion. The `real-lightning` option currently uses vanilla **visual-only lightning**, with gameplay damage handled separately; it does not enable uncontrolled vanilla fire/damage.

## Commands and permissions

`cataclysm.admin` grants all administrative operations and defaults to operators. Individual permissions also default to operators. Console can use commands that do not need a player's location; provide world coordinates for starts/previews.

| Command | Permission | Purpose |
| --- | --- | --- |
| `/disaster help` | `cataclysm.gui` | Command help |
| `/disaster gui` | `cataclysm.gui` | Administration inventory |
| `/disaster start <type>` | `cataclysm.start` | Start at your location with warning |
| `/disaster start <type> <world> <x> <y> <z> [--instant]` | `cataclysm.start` | Start in an already loaded chunk; optional warning bypass |
| `/disaster preview <type> [<world> <x> <y> <z>]` | `cataclysm.preview` | Non-destructive visual preview |
| `/disaster stop <id>` / `stopall` | `cataclysm.stop` | Stop events and clean up visuals |
| `/disaster list` | `cataclysm.gui` | Active UUIDs, phases, intensity and targets |
| `/disaster reload` | `cataclysm.reload` | Stop active events and reload settings |
| `/disaster toggle <type>` | `cataclysm.admin` | Persist enabled state |
| `/disaster intensity <id> <1-5>` | `cataclysm.start` | Change active intensity |
| `/disaster random` | `cataclysm.start` | Start an eligible biome-appropriate event |
| `/disaster rollback <id>` | `cataclysm.rollback` | Stop the event and queue recorded restoration |
| `/disaster pack [send]` | `cataclysm.gui` | Show configuration or request the pack |
| `/disaster debug` / `performance` | `cataclysm.debug` | Runtime/resource counters |
| `/disaster protect pos1` / `pos2` | `cataclysm.admin` | Select safe-zone corners at your block |
| `/disaster protect create <name>` / `remove <name>` / `list` | `cataclysm.admin` | Persistent safe zones |
| `/disaster quality low\|medium\|high` | No additional permission | Persist personal particle reduction |

Use complete UUIDs from `/disaster list`; rollback tab completion includes retained journals. Tab completion filters administrative operations by permission. The GUI supports target selection at your location or the block under your crosshair, intensity, radius, active duration, enabled/destruction/sound/VFX toggles, active-event controls, and destructive-start confirmation. GUI setting changes are shared server configuration, not a private per-player event preset.

## Configuration and terrain safety

| File | Settings |
| --- | --- |
| `config.yml` | Enable state, natural scheduling, global cooldown, default destruction mode, limits, resource-pack URL/hash/retries |
| `disasters.yml` | Per-type stage durations, biome filters, intensity/radius/speed, damage/terrain/VFX/audio switches and effect options |
| `messages.yml` | MiniMessage titles/subtitles, colors, action bar and boss bar settings |
| `sounds.yml` | Custom sound-layer switches, volume and hearing range |
| `visuals.yml` | LOW/MEDIUM/HIGH quality, visible range, reduced flashes and particle-layer switches |
| `worlds.yml` | World whitelist/blacklist, per-world scheduling frequency/difficulty, volcano sources |
| `protection.yml` | Spawn/WorldGuard checks, unsupported claim-plugin policy, per-effect CUSTOM terrain permissions |
| `protection-zones.yml` | Safe zones created using commands; generated when needed |
| `rollback/*.journal` | Durable event terrain history; do not delete while restoration is pending |

Natural events are disabled by default. To enable them, set `automatic-disasters: true`. Selection uses loaded chunks near players, biome/surface rules, event overlap, cooldowns, configured world rules, protection, and TPS. Natural volcano sources use `worlds.yml` entries like `world,120,90,-350`; manual starts use the chosen target. The scheduler is heuristic rather than a geographic or ocean-current simulation.

Terrain changes require both a nonvisual `default-destruction-mode` and the type's `block-damage: true`:

- `VISUAL_ONLY`: no block changes. Gameplay effects remain separately configurable.
- `TEMPORARY`: original block data is journaled before each edit and restoration is queued after the configured post-event deadline.
- `PERMANENT`: requires `destruction.allow-permanent: true`; records remain available for manual rollback.
- `CUSTOM`: effects must be explicitly enabled under `custom-effects` in `protection.yml`; accepted changes are restored on the temporary schedule.

For example, use `TEMPORARY`, enable `meteor.block-damage`, and preview the target before a real test. In `CUSTOM`, set `custom-effects.craters: true` and/or `custom-effects.rock-conversion: true` in `protection.yml` to permit those meteor edits; all listed custom effects default to false. Damage (`damage`) and movement (`forces`) are separate switches. Actual water/fire/lava also require their disaster-specific options. Physical flooding is bounded and temporary; mixed fluid edits conservatively promote the entire event journal to temporary, including other terrain changes. Visual recession and block restoration have separate timelines.

Restoration compares current block data with the engine's last applied data and tracks common player edits. Later matching edits made outside observed events cannot always be distinguished. Block entities (chests, signs, inventories, spawners and other `TileState` blocks) are deliberately excluded from editing rather than partially serialized. Thus their contents stay untouched, but the requested destructive block-entity restoration feature is not implemented. Unloaded or newly protected restoration targets remain pending until they become eligible. Persistent journals provide recovery input; that is not a substitute for a world backup or a tested crash-recovery scenario.

WorldGuard is optional and queried through its public region API. Missing/failed adapters deny changes. Common unsupported claim plugins such as Lands, Towny, Residence and GriefPrevention cause conservative denial instead of bypassing claims; their individual claim APIs are not implemented. Test your exact protection-plugin versions before enabling edits.

## Performance tuning

Start with visual-only previews and one event at a time. Caps limit work; they do not establish a player-count guarantee. No 10–100 player capacity claim has been measured.

- Lower `visuals.yml: quality` from HIGH to MEDIUM or LOW and reduce `max-range` for fewer per-player particles.
- Players can additionally use `/disaster quality low`; world, distance, particle-layer and global budgets still apply. Minor debris models are also reduced for LOW and distant MEDIUM viewers.
- Tune `limits.max-concurrent`, `max-display-entities`, `max-particles-per-tick`, `max-fragments`, `max-radius`, `max-changed-blocks-per-tick` and `max-terrain-edits-per-event` in `config.yml`.
- Per-type `maximum-particles` and `maximum-displays` bound individual effects. Caps may omit minor or distant geometry and particles.
- TPS below 18 reduces particle detail; below 15 reduces it further. Natural generation pauses below 18 TPS.
- Simulations and Bukkit world/entity operations run on the server thread. Durable terrain writes and world saves can add latency; measure them on your storage. Do not increase edit caps aggressively.
- Events do not intentionally load/generate remote chunks. They can stop or omit effects at chunk boundaries, including when the origin chunk unloads.
- `simulation-interval` throttles particle emission while event age and collision timelines advance every server tick. Several regional behaviors also use fixed small update intervals. LOW personal quality hides minor fragment/debris models, and MEDIUM suppresses them at distance.

## Developer API

Obtain the enabled `CataclysmEnginePlugin` instance from Bukkit's plugin manager. Invoke its API on the server thread:

```java
Disaster d = engine.manager().start(DisasterType.METEOR, target, true, false);
engine.manager().get(d.id());
engine.manager().active();
engine.manager().inRegion(target);
engine.manager().stop(d.id());
```

`Disaster` exposes `id()`, `type()`, `phase()`, `origin()`, `intensity()`, `radius()`, `progress()` and `preview()`. Public Bukkit events are in `com.cataclysmengine.api`: `DisasterStartEvent`, `DisasterWarningEvent`, `DisasterIntensityChangeEvent`, `DisasterImpactEvent`, `DisasterDamageEvent`, `DisasterBlockChangeEvent`, `DisasterEndEvent`, and `DisasterRollbackEvent`. All carry `getDisasterId()`; cancellable operations expose Bukkit's `Cancellable`. Cancellation only has meaning at the operation's dispatch point; the end notification is noncancellable. See event sources for read-only payload getters.

## Validation before production

Run the build/tests and asset validator, then load the resulting JAR on Paper 1.21.11/Java 25. With a real 1.21.11 client, accept the pack, test each disaster's stages, inspect model centering/scale/rotation and texture reload logs, listen to sound layers, and exercise GUI permissions. Then verify protected targets, temporary/explicit permanent/custom modes, later player edits, chunk/world unloading, rejection/retry of the pack, shutdown/restart during restoration, multiple worlds, concurrent events, and reduced effects under load. Record actual results in [test results](docs/TEST_RESULTS.md).
